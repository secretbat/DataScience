import logging
import traceback
import time
import logging
import threading

logging.basicConfig(filename='/dbfs/mnt/pegasusdatalake/MLOps/LoggingDE.log', 
level=logging.INFO,  filemode='w',
format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')  # For DataBricks

# logging.basicConfig(filename='Logging_File.log', 
# level=logging.DEBUG,  filemode='w',
     #  format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')


class RootFilter(logging.Filter):
    def filter(self, record):
        return record.name == 'root'
# Set up a handler that uses the filter
handler = logging.StreamHandler()
handler.addFilter(RootFilter())
# Set up the logger with the handler
logger = logging.getLogger('my_logger')
logger.addHandler(handler)

start_time = time.time()
from DataPipeline.main import *
final_granulation()

# import pandas as pd
# import pyspark
# from pyspark.sql import SparkSession
# from DataPipeline import Schemas
# df = pd.read_csv("/dbfs/mnt/pegasusdatalake/MLOps/FlatFile.csv")
# print("-------------------------------PRINTING--------------------------------------")
# df = df.iloc[: , 1:]
# import numpy as np
# from datetime import datetime

# df['LINE'] = 1
# df['CURRENT_DATETIME'] = pd.to_datetime(df["CURRENT_DATETIME"])

# df['PREPROCESSED_LAYER_DATE'] = datetime.now().strftime("%d/%m/%Y %H:%M:%S") 
# df['PREPROCESSED_LAYER_DATE'] = pd.to_datetime(df["PREPROCESSED_LAYER_DATE"])

# df['BATCH_START_DATE'] = datetime.now().strftime("%d/%m/%Y %H:%M:%S") 
# df['BATCH_START_DATE'] = pd.to_datetime(df["BATCH_START_DATE"])

# df['PRE_COMPR_FORCE_MV_KN_STATION_2'] = 0
# df['MAIN_COMPR_FORCE_MV_KN_STATION_2'] = 0
# df['TABL_CYL_HT_MAIN_CO_MM_STATION_2'] = 0
# df['TABL_CYL_HT_PRE_CO_MM_STATION_2'] = 0
# df['TABL_FILLING_DEPTH_MM_STATION_2'] = 0
# df['FILLING_DEVICE_SPEED_STATION_2'] = 0
# df['FILL_O_MATIC_SPEED_RPM_STATION_2'] = 0
# df['FILLING_DEVICE_SPEED_STATION_1'] = 0
# df['FILL_O_MATIC_SPEED_RPM_STATION_1'] = 0
# df['TABLETS_PER_HOUR_STATION_2'] = 0
# df['TABLETS_PER_HOUR_STATION_1'] = 0
# df['FINES_STATION_2'] = 0
# df['BULK_DENSITY_STATION_2'] = 0
# df['LOSS_ON_DRYING_STATION_2'] = 0
# df['TAPPED_DENSITY_STATION_2'] = 0
# df['FINAL_DURATIONS_IN_MINS'] = 0

# cols = ['BATCH_SIZE','MAIN_COMPR_FORCE_MV_KN_STATION_1', 'MAIN_COMPR_FORCE_MV_KN_STATION_2',
#                 'PRE_COMPR_FORCE_MV_KN_STATION_1', 'PRE_COMPR_FORCE_MV_KN_STATION_2',
#                 'TABL_CYL_HT_MAIN_CO_MM_STATION_1', 'TABL_CYL_HT_MAIN_CO_MM_STATION_2',
#                 'TABL_CYL_HT_PRE_CO_MM_STATION_1', 'TABL_CYL_HT_PRE_CO_MM_STATION_2',
#                 'TABL_FILLING_DEPTH_MM_STATION_1', 'TABL_FILLING_DEPTH_MM_STATION_2',
#                 'FILLING_DEVICE_SPEED_STATION_1', 'FILL_O_MATIC_SPEED_RPM_STATION_1',
#                 'TABLETS_PER_HOUR_STATION_1', 'FILLING_DEVICE_SPEED_STATION_2',
#                 'FILL_O_MATIC_SPEED_RPM_STATION_2', 'TABLETS_PER_HOUR_STATION_2',
#                 'FINES_STATION_1', 'BULK_DENSITY_STATION_1', 'LOSS_ON_DRYING_STATION_1',
#                 'TAPPED_DENSITY_STATION_1', 'FINES_STATION_2', 'BULK_DENSITY_STATION_2',
#                 'LOSS_ON_DRYING_STATION_2', 'TAPPED_DENSITY_STATION_2']
                
            
# for i in cols:
#     df[i]=pd.to_numeric(df[i],errors='coerce')
    
# for col in df.columns:
#     if col not in ['BATCH_ID', 'PRODUCTCODE', 'MACHINE_CODE', 'LINE', 'UNIT', 'SITE',
#                 'BATCH_SIZE', 'CURRENT_DATETIME', 'PRODUCTNAME','DATASOURCE','PREPROCESSED_LAYER_DATE',
#                 'BATCH_START_DATE']:
#         df[col]=df[col].astype(float)
    
# column_order = ['BATCH_ID', 'PRODUCTCODE', 'MACHINE_CODE', 'LINE', 'UNIT', 'SITE',
#                 'BATCH_SIZE', 'CURRENT_DATETIME', 'PRODUCTNAME','DATASOURCE',
#                 'PREPROCESSED_LAYER_DATE','BATCH_START_DATE',
#                 'MAIN_COMPR_FORCE_MV_KN_STATION_1', 'MAIN_COMPR_FORCE_MV_KN_STATION_2',
#                 'PRE_COMPR_FORCE_MV_KN_STATION_1', 'PRE_COMPR_FORCE_MV_KN_STATION_2',
#                 'TABL_CYL_HT_MAIN_CO_MM_STATION_1', 'TABL_CYL_HT_MAIN_CO_MM_STATION_2',
#                 'TABL_CYL_HT_PRE_CO_MM_STATION_1', 'TABL_CYL_HT_PRE_CO_MM_STATION_2',
#                 'TABL_FILLING_DEPTH_MM_STATION_1', 'TABL_FILLING_DEPTH_MM_STATION_2',
#                 'FILLING_DEVICE_SPEED_STATION_1', 'FILL_O_MATIC_SPEED_RPM_STATION_1',
#                 'TABLETS_PER_HOUR_STATION_1', 'FILLING_DEVICE_SPEED_STATION_2',
#                 'FILL_O_MATIC_SPEED_RPM_STATION_2', 'TABLETS_PER_HOUR_STATION_2',
#                 'FINES_STATION_1', 'BULK_DENSITY_STATION_1', 'LOSS_ON_DRYING_STATION_1',
#                 'TAPPED_DENSITY_STATION_1', 'FINES_STATION_2', 'BULK_DENSITY_STATION_2',
#                 'LOSS_ON_DRYING_STATION_2', 'TAPPED_DENSITY_STATION_2',
#                 'COMPRESSION_YIELD_PERCENT','FINAL_DURATIONS_IN_MINS']
# df = df[column_order]
# print(df['PRE_COMPR_FORCE_MV_KN_STATION_2'])
# spark = SparkSession.builder.appName("SparkSql").getOrCreate()

# sparkdf=spark.createDataFrame(df,schema = Schemas.compression_schemas)
# print(sparkdf)
# print(sparkdf.select('PRE_COMPR_FORCE_MV_KN_STATION_2').show())
# from DataPipeline.SQLConnection import SQLConnection
# from DataPipeline import Schemas
# sql_connect = SQLConnection()
# sql_connect.write_spark_to_table(sparkdf, "dbo.MLOPS_PIPELINE_COMPRESSION")
# logging.info("SUCCESSFULLY DONE")

end_time = time.time()
print("Duration is : " , end_time - start_time)
timetaken = end_time - start_time
logging.info('(Pegasus.py) --> (pegasus_model) --> { TimeTaken By the Library is : %s }',timetaken)
# historical_pipeline_data/Test/YAML_File/Yml_file.yml
print("Done !!!")
print("")

    


