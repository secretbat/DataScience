import pandas as pd
from DataPipeline.SQLConnection import SQLConnection 
import random
import string
from DataPipeline import Schemas
from datetime import datetime
import logging

import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark.sql.functions import col
from pyspark.sql.types import *
from pyspark.sql import SparkSession


class TransactionLog:
    def __init__(self , TRANSACTION_ID = None, LOG_FILE_NAME = None, DATETIME = None, SITE = None,UNIT=None, PRODUCTCODE = None,PRODUCTNAME = None,LAYER = None,SUBLAYER = None,STATUS = None,FAILURE_REASON = None,FAILURE_DESCRIPTION = None,NO_OF_BATCHES = None,COMMENTS = None):
        self.TRANSACTION_ID = TRANSACTION_ID
        self.LOG_FILE_NAME = LOG_FILE_NAME
        self.DATETIME = DATETIME
        self.SITE = SITE
        self.UNIT = UNIT
        self.PRODUCTCODE = PRODUCTCODE
        self.PRODUCTNAME = PRODUCTNAME
        self.LAYER = LAYER
        self.SUBLAYER = SUBLAYER
        self.STATUS = STATUS
        self.FAILURE_REASON = FAILURE_REASON
        self.FAILURE_DESCRIPTION = FAILURE_DESCRIPTION
        self.NO_OF_BATCHES = NO_OF_BATCHES
        self.COMMENTS = COMMENTS
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()

    def create_SQL_DataFrame(self):
        sql_df = pd.DataFrame(columns=['TRANSACTION_ID','LOG_FILE_NAME','DATETIME','SITE','UNIT','PRODUCTCODE','PRODUCTNAME','LAYER','SUBLAYER','STATUS','FAILURE_REASON','FAILURE_DESCRIPTION','NO_OF_BATCHES','COMMENTS'])
        return sql_df

    def insert_SQL_DataFrame(self,sql_df):
        sql_dictionary = {  'TRANSACTION_ID': [self.TRANSACTION_ID],
                            'LOG_FILE_NAME': [self.LOG_FILE_NAME],
                            'DATETIME': [self.DATETIME],
                            'SITE': [self.SITE],
                            'UNIT': [self.UNIT],
                            'PRODUCTCODE': [self.PRODUCTCODE],
                            'PRODUCTNAME': [self.PRODUCTNAME],
                            'LAYER': [self.LAYER],
                            'SUBLAYER': [self.SUBLAYER],
                            'STATUS': [self.STATUS],
                            'FAILURE_REASON': [self.FAILURE_REASON],
                            'FAILURE_DESCRIPTION': [self.FAILURE_DESCRIPTION],
                            'NO_OF_BATCHES': [self.NO_OF_BATCHES],
                            'COMMENTS': [self.COMMENTS]
                        }
        
        print(sql_dictionary)
        df_insert_sql = pd.DataFrame(sql_dictionary)
        new_df = pd.concat([sql_df , df_insert_sql])
        return new_df
    

    def insert_data(self,Layer,Sublayer,apqr_df , productcode , productname , batch_id ):
        sql_df = self.create_SQL_DataFrame()
        self.TRANSACTION_ID = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
        self.LOG_FILE_NAME = str(self.TRANSACTION_ID) + '_logging.log'
        self.DATETIME = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        self.LAYER = Layer
        self.SUBLAYER = Sublayer
        logging.info("Inside Insert Data")
        print(apqr_df)
        logging.info("--------------------------------")
        logging.info(apqr_df.columns)
        logging.info(apqr_df.head())
        for code in apqr_df[productcode].unique() :
            logging.info("Product code: %s",code)
            self.PRODUCTCODE = code
            self.PRODUCTNAME = apqr_df[apqr_df[productcode] == int(code)][productname].iloc[0]
            self.NO_OF_BATCHES = apqr_df.groupby(productcode)[batch_id].nunique()[int(code)]
            self.SITE = "Will Get from Plant Name"
            self.UNIT = "Will Get from Plant Name"
            self.STATUS = "SUCCESS"

            sql_df = self.insert_SQL_DataFrame(sql_df)

        # convert new_df into Spark
        logging.info("SQL_DF shape has been printed")
        logging.info(sql_df.shape)
        for i in sql_df.columns:
            if i != 'DATETIME':
                sql_df[i] = sql_df[i].astype(str)
        sql_df['DATETIME'] = pd.to_datetime(sql_df['DATETIME'])
        logging.info("-----------------------------------------------")
        logging.info(sql_df.shape)
        spark_log_df = self.spark.createDataFrame(sql_df,schema=Schemas.logging_schemas)

        return spark_log_df
    
    def insert_data_spark(self,Layer,Sublayer,apqr_df , productcode , productname , batch_id ):
        sql_df = self.create_SQL_DataFrame()
        self.TRANSACTION_ID = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
        self.LOG_FILE_NAME = str(self.TRANSACTION_ID) + '_logging.log'
        self.DATETIME = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        self.LAYER = Layer
        self.SUBLAYER = Sublayer
        logging.info("Inside Insert Data")

        self.SITE = "Will Get from Plant Name"
        self.UNIT = "Will Get from Plant Name"
        self.STATUS = "SUCCESS"

        temp_df = apqr_df.groupby([productcode, productname]).agg(F.countDistinct(batch_id).alias("NO_OF_BATCHES"))
        temp_df = temp_df.withColumn("TRANSACTION_ID", F.lit(self.TRANSACTION_ID))
        temp_df = temp_df.withColumn("LOG_FILE_NAME", F.lit(self.LOG_FILE_NAME))
        temp_df = temp_df.withColumn("DATETIME", F.current_timestamp())
        temp_df = temp_df.withColumn("LAYER", F.lit(self.LAYER))
        temp_df = temp_df.withColumn("SUBLAYER", F.lit(self.SUBLAYER))
        temp_df = temp_df.withColumn("SITE", F.lit(self.SITE))
        temp_df = temp_df.withColumn("UNIT", F.lit(self.UNIT))
        temp_df = temp_df.withColumn("STATUS", F.lit(self.STATUS))
        temp_df = temp_df.withColumn("FAILURE_REASON", F.lit(self.FAILURE_REASON))
        temp_df = temp_df.withColumn("FAILURE_DESCRIPTION", F.lit(self.FAILURE_DESCRIPTION))
        temp_df = temp_df.withColumn("COMMENTS", F.lit(self.COMMENTS))

        # temp_df = temp_df.withColumn("DATETIME", F.cast(temp_df["DATETIME"], F.DataTypes.DatetimeType()))
        # convert new_df into Spark
        logging.info("SQL_DF shape has been printed")
        temp_df = temp_df[Schemas.logging_schemas.fieldNames()]
        spark_log_df = self.spark.createDataFrame(temp_df.rdd,schema=Schemas.logging_schemas)

        return spark_log_df

    def failure_into_sql(self ,Layer , Sublayer, failure_reason , failure_description):

        sql_df = self.create_SQL_DataFrame()
        self.TRANSACTION_ID = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
        self.LOG_FILE_NAME = str(self.TRANSACTION_ID) + '_logging.log'
        self.DATETIME = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        self.LAYER = Layer
        self.SUBLAYER = Sublayer
        self.PRODUCTCODE = 'NA'
        self.PRODUCTNAME = 'NA'
        self.SITE = "Will Get from Plant Name"
        self.UNIT = "Will Get from Plant Name"
        self.STATUS = "FAILURE"
        self.FAILURE_REASON = failure_reason
        self.FAILURE_DESCRIPTION = failure_description

        new_df = self.insert_SQL_DataFrame(sql_df)
        for i in new_df.columns:
            if i != 'DATETIME':
                new_df[i] = new_df[i].astype(str)
        new_df['DATETIME'] = pd.to_datetime(new_df['DATETIME'])
        print(new_df.shape)
        print(new_df.columns)
        logging.info("----------------------------------------------------")
        logging.info(new_df.columns)
        # convert new_df into Spark
        spark_log = self.spark.createDataFrame(new_df,schema=Schemas.logging_schemas)

        return spark_log

    def push_DataFrame_to_sql(self,sparkdf):
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf,"dbo.MLOPS_PIPELINE_LOGGING")

        print(" !!!!!!! DATA PUSHED SUCCESSFULLY FOR LOGGING!!!!!!!")