import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import traceback
import logging
import pyspark
from pyspark.sql import SparkSession
from DataPipeline import TableColumn
from datetime import datetime
from DataPipeline import Schemas
from DataPipeline.SQLConnection import SQLConnection
from datetime import datetime
from tqdm import tqdm
from DataPipeline.TransactionLog import TransactionLog


class Granulation:
    def __init__(self) -> None:
        self.df = self.fetch_granulation_data()
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.transaction_log = TransactionLog()

    def fetch_granulation_data(self):
        # Filtering the Data Based on Product code, machine code , batch size and preprocessed DateTime
        """
        THis method fetch Data From PreProcessed Table based on Product code, machine code
        , batch size and preprocessed DateTime which is not there in FinalLayer Table
        """
        # query need to be changed
        sql_query = """SELECT IIF((SCADA.LOTNUMBER = NULL) OR (TRIM(SCADA.LOTNUMBER) = ''), substring(trim(SCADA.BATCH_ID),0,8),CONCAT(substring(trim(SCADA.BATCH_ID),0,8),'_',SCADA.LOTNUMBER)) as BATCH_ID ,
            APQR.PRODUCTCODE AS PRODUCTCODE,
            SCADA.MACHINECODE as MACHINECODE,
            APQR.LINE AS LINE,
            APQR.UNIT AS UNIT,
            APQR.SITE AS SITE,
            APQR.BATCH_SIZE AS BATCH_SIZE,
            SCADA.PRODUCTNAME AS PRODUCTNAME,
            IIF(trim(substring(trim(SCADA.BATCH_ID),8,len(trim(SCADA.BATCH_ID)))) = '','PART A', trim(substring(trim(SCADA.BATCH_ID),8,len(trim(SCADA.BATCH_ID))))) AS PRODUCT_PART,
            SCADA.CURRENT_DATETIME AS CURRENT_DATETIME,
            SCADA.SUBSTAGE AS SUBSTAGE,
            SCADA.EXHAUST_FLAP_SET AS EXHAUST_FLAP_SET,
            SCADA.EXHAUST_FLAP_ACT AS EXHAUST_FLAP_ACT,
            SCADA.INLET_TEMP_SET AS INLET_TEMP_SET,
            SCADA.INLET_TEMP_ACT AS INLET_TEMP_ACT,
            SCADA.PRODUCT_TEMP_SET AS PRODUCT_TEMP_SET,
            SCADA.PRODUCT_TEMP_ACT AS PRODUCT_TEMP_ACT,
            SCADA.EXHAUST_TEMP_SET AS EXHAUST_TEMP_SET,
            SCADA.EXHAUST_TEMP_ACT AS EXHAUST_TEMP_ACT,
            SCADA.AIR_FLOW_INLET_M_S_ACT AS AIR_FLOW_INLET_M_S_ACT,
            SCADA.AIR_FLOW_CFM_ACT AS AIR_FLOW_CFM_ACT,
            SCADA.ATOMIZATION_AIR_SET AS ATOMIZATION_AIR_SET,
            SCADA.ATOMIZATION_AIR_ACT AS ATOMIZATION_AIR_ACT,
            SCADA.SPRAY_RATE_ACT AS SPRAY_RATE_ACT,
            SCADA.DRIVE_SPEED_ACT AS DRIVE_SPEED_ACT,
            SCADA.DRIVE_SPEED_SET AS DRIVE_SPEED_SET,
            SCADA.PAN_SPEED_ACT AS PAN_SPEED_ACT,
            SCADA.PAN_SPEED_SET AS PAN_SPEED_SET,
            SCADA.SPRAY_PUMP_RPM_ACT AS SPRAY_PUMP_RPM_ACT,
            SCADA.BLOWER_DRIVE_ACT AS BLOWER_DRIVE_ACT,
            SCADA.BLOWER_DRIVE_SET AS BLOWER_DRIVE_SET,
            APQR.GRANULATION_YIELD_PERCENT AS GRANULATION_YIELD_PERCENT,
            SCADA.FINAL_DURATIONS_IN_MINS AS FINAL_DURATIONS_IN_MINS,
            SCADA.DATETIME AS DATETIME
            FROM [dbo].[MLOPS_PIPELINE_PROCESSED_APQR] AS APQR
            INNER JOIN [dbo].[MLOPS_PIPELINE_PROCESSED_SCADA] AS SCADA
            ON APQR.BATCH_ID=SCADA.BATCH_ID WHERE upper(SCADA.STAGE) = 'GRANULATION'

            UNION

            SELECT CONCAT(BMR.BATCH_ID,'_',BMR.LOT) AS BATCH_ID,
            BMR.MATERIAL_CODE AS PRODUCTCODE,
            NULL AS MACHINECODE,
            APQR.LINE AS LINE,
            APQR.UNIT AS UNIT,
            APQR.SITE AS SITE,
            APQR.BATCH_SIZE AS BATCH_SIZE,
            BMR. PRODUCT_NAME AS PRODUCTNAME,
            BMR.PART AS PRODUCT_PART,
            BMR.CURRENT_DATETIME AS CURRENT_DATETIME,
            BMR.SUB_STAGE AS SUBSTAGE,
            NULL AS EXHAUST_FLAP_SET,
            NULL AS EXHAUST_FLAP_ACT,
            BMR.INLET_TEMPARATURE_SET AS INLET_TEMP_SET,
            BMR.INLET_TEMPARATURE_ACT AS INLET_TEMP_ACT,
            BMR.PRODUCT_TEMPARATURE_SET AS PRODUCT_TEMP_SET,
            BMR.PRODUCT_TEMPARATURE_ACT AS PRODUCT_TEMP_ACT,
            BMR.EXHAUST_TEMPARATURE_SET AS EXHAUST_TEMP_SET,
            BMR.EXHAUST_TEMPARATURE_ACT AS EXHAUST_TEMP_ACT,
            BMR.INLET_AIR_FLOW_ACT AS AIR_FLOW_INLET_M_S_ACT,
            NULL AS AIR_FLOW_CFM_ACT ,
            BMR.ATOMIZATION_PRESSURE_SET AS ATOMIZATION_AIR_SET,
            BMR.ATOMIZATION_PRESSURE_ACT AS ATOMIZATION_AIR_ACT,
            BMR.SPRAY_RATE AS SPRAY_RATE_ACT,
            NULL AS DRIVE_SPEED_ACT,
            NULL AS DRIVE_SPEED_SET,
            BMR.PAN_SPEED_ACT AS PAN_SPEED_ACT,
            BMR.PAN_SPEED_SET AS PAN_SPEED_SET,
            NULL AS SPRAY_PUMP_RPM_ACT,
            NULL AS BLOWER_DRIVE_ACT,
            NULL AS BLOWER_DRIVE_SET,
            BMR.GRANULATION_YIELD AS GRANULATION_YIELD_PERCENT,
            BMR.FINAL_DURATION_IN_MINS AS FINAL_DURATIONS_IN_MINS,
            BMR.DATETIME AS DATETIME from [dbo].[MLOPS_PIPELINE_PROCESSED_GRANULATION_BMR] as BMR

            INNER JOIN (SELECT DISTINCT BATCH_ID, LINE,UNIT,SITE, BATCH_SIZE from [dbo].[MLOPS_PIPELINE_PROCESSED_APQR]) AS APQR
            on APQR.BATCH_ID=BMR.BATCH_ID

            WHERE BMR.BATCH_ID NOT IN(SELECT DISTINCT BATCH_ID FROM [DBO].[MLOPS_PIPELINE_PROCESSED_SCADA] WHERE BATCH_ID IN (SELECT DISTINCT BATCH_ID FROM [dbo].[MLOPS_PIPELINE_PROCESSED_APQR]) AND upper(STAGE) = 'GRANULATION') AND upper(BMR.STAGE) = 'GRANULATION'
            """
        sql = SQLConnection()
        df = sql.read_table_data_with_query(sql_query)

        print(df.shape)
        print("--------------------------------")
        print(df.head())

        return df

    def final_processed_layer(self):
        try:
            df = self.df.copy()

            cols = [
                "BATCH_SIZE",
                "EXHAUST_FLAP_SET",
                "EXHAUST_FLAP_ACT",
                "INLET_TEMP_SET",
                "INLET_TEMP_ACT",
                "PRODUCT_TEMP_SET",
                "PRODUCT_TEMP_ACT",
                "EXHAUST_TEMP_SET",
                "EXHAUST_TEMP_ACT",
                "AIR_FLOW_INLET_M_S_ACT",
                "AIR_FLOW_CFM_ACT",
                "ATOMIZATION_AIR_SET",
                "ATOMIZATION_AIR_ACT",
                "SPRAY_RATE_ACT",
                "DRIVE_SPEED_ACT",
                "DRIVE_SPEED_SET",
                "PAN_SPEED_ACT",
                "PAN_SPEED_SET",
                "SPRAY_PUMP_RPM_ACT",
                "BLOWER_DRIVE_ACT",
                "BLOWER_DRIVE_SET",
            ]

            for i in cols:
                df[i] = pd.to_numeric(df[i], errors="coerce")

            df["PREPROCESSED_LAYER_DATE"] = df["CURRENT_DATETIME"]
            df["CURRENT_DATETIME"] = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
            df["CURRENT_DATETIME"] = pd.to_datetime(df["CURRENT_DATETIME"])

            df["DATASOURCE"] = ""
            df["BATCH_START_DATE"] = pd.to_datetime("", errors="coerce")

            def substage_mapping(x):
                if x.lower().find("drying") != -1:
                    return "Drying"
                elif x.lower().find("spraying") != -1:
                    return "Spraying"
                elif x.lower().find("pre") != -1:
                    return "Preheating"
                else:
                    return x

            df["SUBSTAGE"] = df["SUBSTAGE"].apply(substage_mapping)
            print("----------Unique SUBSTAGE")
            print(df["SUBSTAGE"].unique())
            # df['LINE']=1
            # df['MACHINECODE'] = 'TM-002'
            # df['UNIT'] = '7B'
            # df['SITE'] = 'GOA'

            for col in df.columns:
                if col not in [
                    "BATCH_ID",
                    "PRODUCTCODE",
                    "MACHINECODE",
                    "LINE",
                    "UNIT",
                    "SITE",
                    "BATCH_SIZE",
                    "SUBSTAGE",
                    "CURRENT_DATETIME",
                    "PRODUCT_PART",
                    "PRODUCTNAME",
                    "DATASOURCE",
                    "PREPROCESSED_LAYER_DATE",
                    "BATCH_START_DATE",
                    "DATETIME",
                ]:
                    # print(col)
                    df[col] = df[col].astype(np.float64)

            column_order = [
                "BATCH_ID",
                "PRODUCTCODE",
                "MACHINECODE",
                "LINE",
                "UNIT",
                "SITE",
                "BATCH_SIZE",
                "PRODUCTNAME",
                "PRODUCT_PART",
                "DATASOURCE",
                "BATCH_START_DATE",
                "PREPROCESSED_LAYER_DATE",
                "CURRENT_DATETIME",
                "SUBSTAGE",
                "EXHAUST_FLAP_SET",
                "EXHAUST_FLAP_ACT",
                "INLET_TEMP_SET",
                "INLET_TEMP_ACT",
                "PRODUCT_TEMP_SET",
                "PRODUCT_TEMP_ACT",
                "EXHAUST_TEMP_SET",
                "EXHAUST_TEMP_ACT",
                "AIR_FLOW_INLET_M_S_ACT",
                "AIR_FLOW_CFM_ACT",
                "ATOMIZATION_AIR_SET",
                "ATOMIZATION_AIR_ACT",
                "SPRAY_RATE_ACT",
                "DRIVE_SPEED_ACT",
                "DRIVE_SPEED_SET",
                "PAN_SPEED_ACT",
                "PAN_SPEED_SET",
                "SPRAY_PUMP_RPM_ACT",
                "BLOWER_DRIVE_ACT",
                "BLOWER_DRIVE_SET",
                "GRANULATION_YIELD_PERCENT",
                "FINAL_DURATIONS_IN_MINS",
                "DATETIME",
            ]

            df = df[column_order]

            dict_1 = {
                "BATCH_ID": str,
                "PRODUCTCODE": int,
                "MACHINECODE": str,
                "LINE": str,
                "UNIT": str,
                "SITE": str,
                "BATCH_SIZE": float,
                "PRODUCTNAME": str,
                "PRODUCT_PART": str,
                "DATASOURCE": str,
                "SUBSTAGE": str,
                "EXHAUST_FLAP_SET": float,
                "EXHAUST_FLAP_ACT": float,
                "INLET_TEMP_SET": float,
                "INLET_TEMP_ACT": float,
                "PRODUCT_TEMP_SET": float,
                "PRODUCT_TEMP_ACT": float,
                "EXHAUST_TEMP_SET": float,
                "EXHAUST_TEMP_ACT": float,
                "AIR_FLOW_INLET_M_S_ACT": float,
                "AIR_FLOW_CFM_ACT": float,
                "ATOMIZATION_AIR_SET": float,
                "ATOMIZATION_AIR_ACT": float,
                "SPRAY_RATE_ACT": float,
                "DRIVE_SPEED_ACT": float,
                "DRIVE_SPEED_SET": float,
                "PAN_SPEED_ACT": float,
                "PAN_SPEED_SET": float,
                "SPRAY_PUMP_RPM_ACT": float,
                "BLOWER_DRIVE_ACT": float,
                "BLOWER_DRIVE_SET": float,
                "GRANULATION_YIELD_PERCENT": float,
                "FINAL_DURATIONS_IN_MINS": float,
            }

            print(df.head())
            df = df.astype(dict_1)
            print("--------------PRINTING DF------------------")
            print(df.head())
            sparkdf = self.spark.createDataFrame(df, schema=Schemas.granulation_schema)
            # Logging function
            spark_log_df = self.transaction_log.insert_data(
                "FINAL", "GRANULATION", df, "PRODUCTCODE", "PRODUCTNAME", "BATCH_ID"
            )

            return sparkdf, spark_log_df

        except Exception as e:
            print(e)
            logging.info("Error in Processing FINAL LAYER GRANULATION")
            spark_log = self.transaction_log.failure_into_sql(
                "FINAL",
                "GRANULATION",
                "Error in Processing FINAL LAYER GRANULATION",
                "Error",
            )
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()

    def push_Data_in_final_coating(self, sparkdf, spark_log_df):
        # Push the DataFrame Into SQL Table
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf, "dbo.MLOPS_PIPELINE_GRANULATION")

        print("DATA IS SUCCESSFUL PUSHED IN FINAL LAYER GRANULATION")
        logging.info("DATA IS SUCCESSFUL PUSHED IN FINAL GRANULATION LAYER")

        self.transaction_log.push_DataFrame_to_sql(spark_log_df)
        print("!!!!!!!!! DATA PUSHED SUCCESSFULLY IN FINAL LAYER GRANULATION !!!!!!!!")
