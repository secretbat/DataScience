import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import traceback
import logging
import pyspark
from pyspark.sql import SparkSession
from DataPipeline import TableColumn
from datetime import datetime
from DataPipeline import Schemas
from DataPipeline.SQLConnection import SQLConnection 
from datetime import datetime
from tqdm import tqdm
from DataPipeline.TransactionLog import TransactionLog

class Coating:
    def __init__(self) -> None:
        self.df = self.fetch_coating_data()
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.transaction_log = TransactionLog()
        


    def fetch_coating_data(self):
        # Filtering the Data Based on Product code, machine code , batch size and preprocessed DateTime
        '''
        THis method fetch Data From PreProcessed Table based on Product code, machine code
        , batch size and preprocessed DateTime which is not there in FinalLayer Table
        '''

        sql_query = '''SELECT IIF((SCADA.LOTNUMBER = NULL) OR (TRIM(SCADA.LOTNUMBER) = ''), IIF(upper(SCADA.BATCH_ID) LIKE '%PART%',SUBSTRING(TRIM(SCADA.BATCH_ID),1,7),TRIM(SCADA.BATCH_ID)),CONCAT(IIF(upper(SCADA.BATCH_ID) LIKE '%PART%',SUBSTRING(TRIM(SCADA.BATCH_ID),1,7),TRIM(SCADA.BATCH_ID)),'_',SCADA.LOTNUMBER)) as BATCH_ID ,
                APQR.PRODUCTCODE AS PRODUCTCODE,
                SCADA.MACHINECODE as MACHINECODE,
                APQR.LINE AS LINE,
                APQR.UNIT AS UNIT,
                APQR.SITE AS SITE,
                APQR.BATCH_SIZE AS BATCH_SIZE,
                SCADA.PRODUCTNAME AS PRODUCTNAME,
                IIF(upper(SCADA.BATCH_ID) like '%PART%', trim(SUBSTRING(upper(SCADA.BATCH_ID),PATINDEX('%PART%',upper(SCADA.BATCH_ID))+4,25)),'A') AS PRODUCT_PART,
                SCADA.CURRENT_DATETIME AS CURRENT_DATETIME,
                SCADA.SUBSTAGE AS SUBSTAGE,
                SCADA.EXHAUST_FLAP_SET AS EXHAUST_FLAP_SET,
                SCADA.EXHAUST_FLAP_ACT AS EXHAUST_FLAP_ACT,
                SCADA.INLET_TEMP_SET AS INLET_TEMP_SET,
                SCADA.INLET_TEMP_ACT AS INLET_TEMP_ACT,
                SCADA.PRODUCT_TEMP_SET AS PRODUCT_TEMP_SET,
                SCADA.PRODUCT_TEMP_ACT AS PRODUCT_TEMP_ACT,
                SCADA.EXHAUST_TEMP_SET AS EXHAUST_TEMP_SET,
                SCADA.EXHAUST_TEMP_ACT AS EXHAUST_TEMP_ACT,
                SCADA.AIR_FLOW_INLET_M_S_ACT AS AIR_FLOW_INLET_M_S_ACT,
                SCADA.AIR_FLOW_CFM_ACT AS AIR_FLOW_CFM_ACT,
                SCADA.ATOMIZATION_AIR_SET AS ATOMIZATION_AIR_SET,
                SCADA.ATOMIZATION_AIR_ACT AS ATOMIZATION_AIR_ACT,
                SCADA.SPRAY_RATE_ACT AS SPRAY_RATE_ACT,
                SCADA.DRIVE_SPEED_ACT AS DRIVE_SPEED_ACT,
                SCADA.DRIVE_SPEED_SET AS DRIVE_SPEED_SET,
                SCADA.PAN_SPEED_ACT AS PAN_SPEED_ACT,
                SCADA.PAN_SPEED_SET AS PAN_SPEED_SET,
                SCADA.SPRAY_PUMP_RPM_ACT AS SPRAY_PUMP_RPM_ACT,
                SCADA.BLOWER_DRIVE_ACT AS BLOWER_DRIVE_ACT,
                SCADA.BLOWER_DRIVE_SET AS BLOWER_DRIVE_SET,
                APQR.COATING_YIELD_PERCENT AS COATING_YIELD_PERCENT,
                SCADA.FINAL_DURATIONS_IN_MINS AS FINAL_DURATIONS_IN_MINS,
                SCADA.DATETIME AS DATETIME
                FROM [dbo].[MLOPS_PIPELINE_PROCESSED_APQR] AS APQR

                INNER JOIN [dbo].[MLOPS_PIPELINE_PROCESSED_SCADA] AS SCADA

                ON APQR.BATCH_ID=SCADA.BATCH_ID WHERE upper(SCADA.STAGE) = 'COATING' 
                AND SCADA.BATCH_ID NOT IN (SELECT DISTINCT BATCH_ID FROM [dbo].[MLOPS_PIPELINE_COATING])
                '''

        sql = SQLConnection()
        df = sql.read_table_data_with_query(sql_query)

        print(df.shape)

        return df

    def final_processed_layer(self):
        try:

            df = self.df.copy()
            df['PREPROCESSED_LAYER_DATE'] = datetime.now()
            
            def substage_mapping(x):
                if x.lower().find('drying') != -1:
                    return 'Drying'
                elif x.lower().find('spraying') != -1:
                    return 'Spraying'
                elif x.lower().find('pre') != -1:
                    return 'Preheating'
                else:
                    return x

            
            df['SUBSTAGE'] = df['SUBSTAGE'].apply(substage_mapping)
            sparkdf = self.spark.createDataFrame(df, schema = Schemas.coating_schema)

            # Logging function
            spark_log_df = self.transaction_log.insert_data("FINAL", "COATING", df, "PRODUCTCODE",
                                                            "PRODUCTNAME", "BATCH_ID")
            return sparkdf,spark_log_df

        except Exception as e:
            print(e)
            logging.info("Error in Processing FINAL LAYER COATING")
            spark_log = self.transaction_log.failure_into_sql( "FINAL", "COATING" , "Error in Processing FINAL LAYER COATING" , "Error")
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()
        
    def push_Data_in_final_coating(self,sparkdf,spark_log_df):
        #Push the DataFrame Into SQL Table
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf,"dbo.MLOPS_PIPELINE_COATING")

        print("DATA IS SUCCESSFUL PUSHED IN FINAL LAYER COATING")
        logging.info("DATA IS SUCCESSFUL PUSHED IN FINAL COATING LAYER")

        self.transaction_log.push_DataFrame_to_sql(spark_log_df)
        print("!!!!!!!!! DATA PUSHED SUCCESSFULLY IN FINAL LAYER COATING !!!!!!!!")
