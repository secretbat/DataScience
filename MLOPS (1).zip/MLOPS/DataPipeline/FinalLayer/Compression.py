import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import traceback
import logging
import pyspark
from pyspark.sql import SparkSession
from DataPipeline import TableColumn
from datetime import datetime
from DataPipeline import Schemas
from DataPipeline.SQLConnection import SQLConnection 
from datetime import datetime
from tqdm import tqdm
from DataPipeline.TransactionLog import TransactionLog
class Compression:
    def __init__(self) -> None:
        self.df = self.fetch_compression_data()
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.transaction_log = TransactionLog()


    def fetch_compression_data(self):
        # Filtering the Data Based on Product code, machine code , batch size and preprocessed DateTime
        '''
        THis method fetch Data From PreProcessed Table based on Product code, machine code
        , batch size and preprocessed DateTime which is not there in FinalLayer Table
        '''

        sql_query = """
                SELECT DISTINCT APQR.BATCH_ID as BATCH_ID ,
                APQR.PRODUCTCODE as PRODUCTCODE,
                HMI.MACHINE_CODE as MACHINE_CODE ,
                APQR.LINE as LINE ,
                APQR.UNIT as UNIT ,
                APQR.SITE as 'SITE' ,
                APQR.BATCH_SIZE as BATCH_SIZE,
                APQR.CURRENT_DATETIME as CURRENT_DATETIME ,
                APQR.PRODUCTNAME as PRODUCTNAME , 
                HMI.MAIN_COMPR_FORCE_MV_KN_STATION_1 as MAIN_COMPR_FORCE_MV_KN_STATION_1,
                HMI.MAIN_COMPR_FORCE_MV_KN_STATION_2 as MAIN_COMPR_FORCE_MV_KN_STATION_2, 
                HMI.PRE_COMPR_FORCE_MV_KN_STATION_1 as PRE_COMPR_FORCE_MV_KN_STATION_1 ,
                HMI.PRE_COMPR_FORCE_MV_KN_STATION_2 as PRE_COMPR_FORCE_MV_KN_STATION_2 ,
                HMI.TABL_CYL_HT_MAIN_CO_MM_STATION_1 as TABL_CYL_HT_MAIN_CO_MM_STATION_1, 
                HMI.TABL_CYL_HT_MAIN_CO_MM_STATION_2 as TABL_CYL_HT_MAIN_CO_MM_STATION_2 ,
                HMI.TABL_CYL_HT_PRE_CO_MM_STATION_1 as TABL_CYL_HT_PRE_CO_MM_STATION_1 ,
                HMI.TABL_CYL_HT_PRE_CO_MM_STATION_2 as TABL_CYL_HT_PRE_CO_MM_STATION_2, 
                HMI.TABL_FILLING_DEPTH_MM_STATION_1 as TABL_FILLING_DEPTH_MM_STATION_1 ,
                HMI.TABL_FILLING_DEPTH_MM_STATION_2 as TABL_FILLING_DEPTH_MM_STATION_2 , 
                HMI.FILLING_DEVICE_SPEED_STATION_1 as FILLING_DEVICE_SPEED_STATION_1 ,
                HMI.[FILL-O-MATIC_SPEED_RPM_STATION_1] as FILL_O_MATIC_SPEED_RPM_STATION_1,
                HMI.TABLETS_PER_HOUR_STATION_1 as TABLETS_PER_HOUR_STATION_1 ,
                HMI.FILLING_DEVICE_SPEED_STATION_2 as FILLING_DEVICE_SPEED_STATION_2,
                HMI.[FILL-O-MATIC_SPEED_RPM_STATION_2] as FILL_O_MATIC_SPEED_RPM_STATION_2,
                HMI.TABLETS_PER_HOUR_STATION_2 as TABLETS_PER_HOUR_STATION_2 , 
                APQR.FINES_STATION_1 as FINES_STATION_1,
                APQR.BULK_DENSITY_STATION_1 as  BULK_DENSITY_STATION_1,
                APQR.LOSS_ON_DRYING_STATION_1 as LOSS_ON_DRYING_STATION_1,
                APQR.TAPPED_DENSITY_STATION_1 as TAPPED_DENSITY_STATION_1,
                APQR.FINES_STATION_2 as FINES_STATION_2,
                APQR.BULK_DENSITY_STATION_2 as BULK_DENSITY_STATION_2 ,
                APQR.LOSS_ON_DRYING_STATION_2 as LOSS_ON_DRYING_STATION_2,
                APQR.TAPPED_DENSITY_STATION_2 as TAPPED_DENSITY_STATION_2,
                APQR.COMPRESSION_YIELD_PERCENT as COMPRESSION_YIELD_PERCENT
                FROM [dbo].[MLOPS_PIPELINE_PROCESSED_APQR] AS APQR
                INNER JOIN [dbo].[MLOPS_PIPELINE_RAW_HMI] AS HMI
                ON APQR.BATCH_ID=HMI.BATCH_ID WHERE HMI.BATCH_ID NOT IN (SELECT BATCH_ID FROM [dbo].[MLOPS_PIPELINE_COMPRESSION]) """
        
        sql = SQLConnection()
        df = sql.read_table_data_with_query(sql_query)

        print(df.shape)

        return df

    def final_processed_layer(self):
        try:
            sparkAPQR = self.df
            cols = ['BATCH_SIZE','MAIN_COMPR_FORCE_MV_KN_STATION_1', 'MAIN_COMPR_FORCE_MV_KN_STATION_2',
                'PRE_COMPR_FORCE_MV_KN_STATION_1', 'PRE_COMPR_FORCE_MV_KN_STATION_2',
                'TABL_CYL_HT_MAIN_CO_MM_STATION_1', 'TABL_CYL_HT_MAIN_CO_MM_STATION_2',
                'TABL_CYL_HT_PRE_CO_MM_STATION_1', 'TABL_CYL_HT_PRE_CO_MM_STATION_2',
                'TABL_FILLING_DEPTH_MM_STATION_1', 'TABL_FILLING_DEPTH_MM_STATION_2',
                'FILLING_DEVICE_SPEED_STATION_1', 'FILL_O_MATIC_SPEED_RPM_STATION_1',
                'TABLETS_PER_HOUR_STATION_1', 'FILLING_DEVICE_SPEED_STATION_2',
                'FILL_O_MATIC_SPEED_RPM_STATION_2', 'TABLETS_PER_HOUR_STATION_2',
                'FINES_STATION_1', 'BULK_DENSITY_STATION_1', 'LOSS_ON_DRYING_STATION_1',
                'TAPPED_DENSITY_STATION_1', 'FINES_STATION_2', 'BULK_DENSITY_STATION_2',
                'LOSS_ON_DRYING_STATION_2', 'TAPPED_DENSITY_STATION_2']
                
            
            for i in cols:
                sparkAPQR[i]=pd.to_numeric(sparkAPQR[i],errors='coerce')


            sparkAPQR['PREPROCESSED_LAYER_DATE'] = sparkAPQR["CURRENT_DATETIME"]
            sparkAPQR['PREPROCESSED_LAYER_DATE'] = pd.to_datetime(sparkAPQR['PREPROCESSED_LAYER_DATE'])

            sparkAPQR["CURRENT_DATETIME"] = datetime.now().strftime("%d/%m/%Y %H:%M:%S") 
            sparkAPQR["CURRENT_DATETIME"] = pd.to_datetime(sparkAPQR["CURRENT_DATETIME"])
            
            sparkAPQR['DATASOURCE'] = 'HMI,APQR'
            # sparkAPQR['PREPROCESSED_LAYER_DATE'] = pd.to_datetime('',errors='coerce')
            sparkAPQR['BATCH_START_DATE'] = pd.to_datetime('',errors='coerce')
            sparkAPQR['FINAL_DURATIONS_IN_MINS'] = np.nan
            sparkAPQR['LINE']=1

            for col in sparkAPQR.columns:
                if col not in ['BATCH_ID', 'PRODUCTCODE', 'MACHINE_CODE', 'LINE', 'UNIT', 'SITE',
                            'BATCH_SIZE', 'CURRENT_DATETIME', 'PRODUCTNAME','DATASOURCE','PREPROCESSED_LAYER_DATE',
                            'BATCH_START_DATE']:
                    sparkAPQR[col]=sparkAPQR[col].astype(np.float64)

            column_order = ['BATCH_ID', 'PRODUCTCODE', 'MACHINE_CODE', 'LINE', 'UNIT', 'SITE',
                'BATCH_SIZE', 'CURRENT_DATETIME', 'PRODUCTNAME','DATASOURCE',
                'PREPROCESSED_LAYER_DATE','BATCH_START_DATE',
                'MAIN_COMPR_FORCE_MV_KN_STATION_1', 'MAIN_COMPR_FORCE_MV_KN_STATION_2',
                'PRE_COMPR_FORCE_MV_KN_STATION_1', 'PRE_COMPR_FORCE_MV_KN_STATION_2',
                'TABL_CYL_HT_MAIN_CO_MM_STATION_1', 'TABL_CYL_HT_MAIN_CO_MM_STATION_2',
                'TABL_CYL_HT_PRE_CO_MM_STATION_1', 'TABL_CYL_HT_PRE_CO_MM_STATION_2',
                'TABL_FILLING_DEPTH_MM_STATION_1', 'TABL_FILLING_DEPTH_MM_STATION_2',
                'FILLING_DEVICE_SPEED_STATION_1', 'FILL_O_MATIC_SPEED_RPM_STATION_1',
                'TABLETS_PER_HOUR_STATION_1', 'FILLING_DEVICE_SPEED_STATION_2',
                'FILL_O_MATIC_SPEED_RPM_STATION_2', 'TABLETS_PER_HOUR_STATION_2',
                'FINES_STATION_1', 'BULK_DENSITY_STATION_1', 'LOSS_ON_DRYING_STATION_1',
                'TAPPED_DENSITY_STATION_1', 'FINES_STATION_2', 'BULK_DENSITY_STATION_2',
                'LOSS_ON_DRYING_STATION_2', 'TAPPED_DENSITY_STATION_2',
                'COMPRESSION_YIELD_PERCENT','FINAL_DURATIONS_IN_MINS']
            sparkAPQR = sparkAPQR[column_order]

            sparkDF=self.spark.createDataFrame(sparkAPQR,schema = Schemas.compression_schemas) 
            # Logging function
            spark_log_df = self.transaction_log.insert_data("FINAL", "COMPRESSION", sparkAPQR, "PRODUCTCODE",
                                                            "PRODUCTNAME", "BATCH_ID")
            
            return sparkDF,spark_log_df

        except Exception as e:
            print(e)
            logging.info("Error in Processing FINAL LAYER COMPRESSION")
            spark_log = self.transaction_log.failure_into_sql( "FINAL", "COMPRESSION" , "Error in Processing FINAL LAYER COMPRESSION" , "Error")
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()

        
    def push_Data_in_final_compression(self,sparkdf,spark_log_df):
        #Push the DataFrame Into SQL Table
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf,"dbo.MLOPS_PIPELINE_COMPRESSION")

        print("DATA IS SUCCESSFUL PUSHED IN FINAL LAYER COMPRESSION")
        logging.info("DATA IS SUCCESSFUL PUSHED IN FINAL COMPRESSION LAYER")

        self.transaction_log.push_DataFrame_to_sql(spark_log_df)
        print("!!!!!!!!! DATA PUSHED SUCCESSFULLY IN FINAL LAYER COMPRESSION !!!!!!!!")
