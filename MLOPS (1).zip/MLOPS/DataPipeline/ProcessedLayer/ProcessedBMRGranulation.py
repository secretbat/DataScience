
import pandas as pd 
import numpy as np
import glob
import os
import re
from DataPipeline import Schemas
from datetime import datetime
from DataPipeline.SQLConnection import SQLConnection 
import logging
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark.sql.functions import col
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from DataPipeline.TransactionLog import TransactionLog

import traceback
import logging

class Processed_BMR_Granulation:
    def __init__(self):
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.transaction_log = TransactionLog()

    def get_Raw_Data_from_SQL(self):
        sql_connection = SQLConnection()
        df = sql_connection.read_table_data("dbo.MLOPS_PIPELINE_RAW_GRANULATION_BMR")
        sparkdf = self.spark.createDataFrame(df, schema = Schemas.raw_bmr_granulation)
        return sparkdf
    
    def raw_processed_extraction_bmr_granulation(self,sparkdf):

        try:
            mapped_df = sparkdf.withColumn("Parameter_Value", F.from_json("Parameter_Value", Schemas.raw_bmr_intermediate_processing))
            parsed_df = mapped_df.select(F.col("BATCH_ID"),F.col("MATERIAL_CODE"),F.col("PRODUCT_NAME"),F.col("CURRENT_DATETIME"),F.col("DATETIME"),F.col("Parameter_Value.*"))
            out_df = parsed_df.toPandas()

            out_df.columns = [col.upper() for col in out_df.columns]

            for col in out_df.columns:
                if col not in ['BATCH_ID','PRODUCT_NAME','CURRENT_DATETIME','DATETIME','LOT','PART','STAGE','SUB_STAGE']:
                    out_df[col] = pd.to_numeric(out_df[col], errors="coerce")

            out_df['CURRENT_DATETIME'] = datetime.now()
            df = out_df.copy()
            # ----Newly Added
            break_duration = {}
            from tqdm import tqdm

            df['BATCH_ID'] = df['BATCH_ID']+'_'+df['LOT']
            for batch in tqdm(df['BATCH_ID'].unique()):
                temp_df = df[df['BATCH_ID']==batch].sort_values('DATETIME').reset_index(drop=True)
                temp_df['Time_shifted']=temp_df['DATETIME'].shift(1)
                temp_df['break_duration']=(temp_df['DATETIME']-temp_df['Time_shifted'])/np.timedelta64(1,'m')
                temp_df.drop('Time_shifted',axis=1,inplace=True)
                total_break = temp_df[temp_df['break_duration']>5]['break_duration'].sum()
                total_duration = ((temp_df['DATETIME'].max()-temp_df['DATETIME'].min()).total_seconds()/60)-total_break
                break_duration[batch] = total_duration
                
            break_df=pd.DataFrame(break_duration,index=range(0,30,1)).T[0].reset_index()
            break_df.columns=['BATCH_ID','final_duration_in_mins']
            break_df.sort_values('BATCH_ID')

            
            break_df.columns = [col.upper() for col in break_df.columns]

            df = df.merge(break_df, left_on = ['BATCH_ID'], right_on = ['BATCH_ID'],how="left")
            df['LOT'] = df['BATCH_ID'].apply(lambda x: x.split("_")[-1])
            df['BATCH_ID'] = df['BATCH_ID'].apply(lambda x: x.split("_")[0])

            df['FINAL_DURATION_IN_MINS'] = df['FINAL_DURATION_IN_MINS'].astype(float)
            print(df.head())
            logging.info("Current ********************************")
            logging.info(df.head())
            logging.info(df.dtypes)
            sparkdf = self.spark.createDataFrame(df, schema = Schemas.processed_bmr_granulation_schema)

            # Logging function
            spark_log_df = self.transaction_log.insert_data( "PROCESSED", "BMR GRANULATION" , df,"MATERIAL_CODE" , "PRODUCT_NAME" ,"BATCH_ID")
        
            return sparkdf , spark_log_df
        except Exception as e:
            print(e)
            logging.info("Error in Processing Processed BMR Granulations")
            spark_log = self.transaction_log.failure_into_sql( "PROCESSED", "BMR GRANULATION" , "Error In Processing PROCESSED BMR Granulation" , "Error")
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc() 

        
    
    def push_processed_bmr_granulation(self,sparkdf,spark_log_df):
        sql_connection = SQLConnection()
        sql_connection.write_spark_to_table(sparkdf,"dbo.MLOPS_PIPELINE_PROCESSED_GRANULATION_BMR")

        print("DATA IS SUCCESSFUL PUSHED IN PROCESSED BMR GRANULATION")
        logging.info("DATA IS SUCCESSFUL PUSHED IN PROCESSED BMR GRANULATION")

        self.transaction_log.push_DataFrame_to_sql(spark_log_df)

        print("!!!!!!!!! DATA IS SUCCESSFULLY PUSHed IN LOGGING FOR PROCESSED BMR GRANULATION")





    
    
    

        