
import pandas as pd 
import numpy as np
import glob
import os
import re
from DataPipeline import Schemas
from datetime import datetime
from DataPipeline.SQLConnection import SQLConnection 

import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark.sql.functions import col
from pyspark.sql.types import *
from pyspark.sql import SparkSession

from DataPipeline.TransactionLog import TransactionLog

import traceback
import logging

class Processed_BMR_Compression:
    def __init__(self):
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.transaction_log = TransactionLog()

    def get_Raw_Data_from_SQL(self):
        sql_connection = SQLConnection()
        df = sql_connection.read_table_data("dbo.MLOPS_PIPELINE_RAW_COMPRESSION_BMR")
        sparkdf = self.spark.createDataFrame(df, schema = Schemas.raw_bmr_compression)
        return sparkdf
    
    def raw_processed_extraction_bmr_compression(self,sparkdf):

        try:
            mapped_df = sparkdf.withColumn("Parameter_Value", F.from_json("Parameter_Value", Schemas.raw_bmr_intermediate_processing_compression))
            parsed_df = mapped_df.select(F.col("BATCH_ID"),F.col("MATERIAL_CODE"),F.col("PRODUCT_NAME"),F.col("CURRENT_DATETIME"),F.col("Parameter_Value.*"))
            out_df = parsed_df.toPandas()

            out_df.columns = [col.upper() for col in out_df.columns]

            for col in out_df.columns:
                if col not in ['BATCH_ID','PRODUCT_NAME','CURRENT_DATETIME']:
                    out_df[col] = pd.to_numeric(out_df[col].astype(str), errors="coerce")

            out_df['CURRENT_DATETIME'] = datetime.now()

            sparkdf = self.spark.createDataFrame(out_df, schema = Schemas.processed_bmr_compression_schema)
            
            spark_log_df = self.transaction_log.insert_data( "PROCESSED", "BMR COMPRESSION" , out_df,"MATERIAL_CODE" , "PRODUCT_NAME" ,"BATCH_ID")

            return sparkdf,spark_log_df
        
        except Exception as e:
            print(e)
            logging.info("Error in Processing Processed BMR Granulations")
            spark_log = self.transaction_log.failure_into_sql( "PROCESSED", "BMR COMPRESSION" , "Error In Processing PROCESSED BMR COMPRESSION" , "Error")
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()

    
    def push_processed_bmr_compression(self,sparkdf,spark_log_df):
        sql_connection = SQLConnection()
        sql_connection.write_spark_to_table(sparkdf,"dbo.MLOPS_PIPELINE_PROCESSED_COMPRESSION_BMR")

        print(" !!!!!!!  DATA IS SUCCESSFULLY PUSHED IN PROCESSED BMR COmpression  !!!!!!!")
        self.transaction_log.push_DataFrame_to_sql(spark_log_df)
        print("!!!!!!!!! DATA IS SUCCESSFULLY PUSHed IN LOGGING FOR PROCESSED BMR COmpression")



    
    
    

        