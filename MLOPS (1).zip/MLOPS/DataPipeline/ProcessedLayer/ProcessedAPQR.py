import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import traceback
import logging
import pyspark
from pyspark.sql import SparkSession
from DataPipeline import TableColumn
from datetime import datetime
from DataPipeline import Schemas
from DataPipeline.SQLConnection import SQLConnection 
from datetime import datetime
from DataPipeline.TransactionLog import TransactionLog
import random
import string
from DataPipeline.utils import *

class APQR:
    def __init__(self) -> None:
        self.df = self.fetch_RAW_APQR()
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.transaction_log = TransactionLog()

    def fetch_RAW_APQR(self):
        # Filtering the Data Based on Product code, machine code , batch size and preprocessed DateTime
        '''
        THis method fetch Data From PreProcessed Table based on Product code, machine code
        , batch size and preprocessed DateTime which is not there in FinalLayer Table
        
        '''
        sql = SQLConnection()
        df = sql.read_table_data('dbo.MLOPS_PIPELINE_RAW_APQR')
        return df

    def convert_Raw_APQR_Indore4(self):
        try:
            df1 = self.df.copy()
            df1 = df1[df1['PLANT'] == 1028]
            
            batchno =  [31004737,31007552,31002162,31000009,31000471,31000137,31000071,31000087,31003578,31006159,31006043,31000626,31000731,31000732,
                        31004467,31004468,31006891,31001500,31001501,
                        31004737,31001637,31007031,31002214,31002718,31002710,31002717,31002727,31002846,31003057,31003059,31004274,
                        31003732,31000631,31003103,31004735,31003917,31002180,31005128,
                        31004736,31002178,32008420,31001398,31006003]

            # df1 = df1[df1['PLANT'] == 1028]
            col = ["% FINES","LOSS ON DRYING","BULK DENSITY","TAPPED DENSITY","GRANULATION YIELD","COMPRESSION YIELD","COATING YIELD","MANUFACTURING YIELD"]
            df1 = df1[df1["MIC_DESCRIPTION"].isin(col)]
            df1 = df1[df1["PRODUCTCODE"].isin(batchno)]


            df1 = df1[((df1["MIC_DESCRIPTION"] == 'COMPRESSION YIELD') & (df1['UOM'] == '%')) | 
                    ((df1["MIC_DESCRIPTION"] == 'LOSS ON DRYING') & (df1['UOM'].isin(['%','%W/W']))) |
                    ((df1["MIC_DESCRIPTION"] == 'BULK DENSITY') & (df1['UOM'].isin(['%','gm/ml']))) |
                    ((df1["MIC_DESCRIPTION"] == 'TAPPED DENSITY') & (df1['UOM'].isin(['%','gm/ml']))) |
                    ((df1["MIC_DESCRIPTION"] == '% FINES') & (df1['UOM'].isin(['%','%W/W']))) |
                    ((df1["MIC_DESCRIPTION"] == 'COATING YIELD') & (df1['UOM'] == '%')) |
                    ((df1["MIC_DESCRIPTION"] == 'GRANULATION YIELD') & (df1['UOM'] == '%'))
                    ]

            test = pd.DataFrame(df1.groupby(['PRODUCTCODE','BATCH_ID', 'MIC_DESCRIPTION']).size()).reset_index()
            not_included_batch = set(test[test[0]>1]['PRODUCTCODE'])

            df2 = df1[~df1['PRODUCTCODE'].isin(not_included_batch)]
            df2 = df2[['BATCH_ID','PRODUCTCODE','MATERIAL_DESCRIPTION','PLANT','PLANTNAME','MIC_DESCRIPTION' , 'RESULT']]

            times_2 = df1[df1['PRODUCTCODE'].isin(list(test[(test[0] == 2) | (test[0] == 3)]['PRODUCTCODE'].unique()))]
            for i in list(times_2['PRODUCTCODE'].unique()):
                temp = times_2[times_2['PRODUCTCODE'] == i]
                temp2 = temp.groupby(['PRODUCTCODE','BATCH_ID', 'MIC_DESCRIPTION']).size().reset_index()
                if temp2[(temp2[0] == 2) | (temp2[0] == 3)]['MIC_DESCRIPTION'].iloc[0] == 'COMPRESSION YIELD':
                    print(temp2[(temp2[0] == 2) | (temp2[0] == 3)]['MIC_DESCRIPTION'].iloc[0])
                    temp_final = temp.groupby(['PLANT' , 'PLANTNAME', 'MATERIAL_DESCRIPTION','PRODUCTCODE','BATCH_ID', 'MIC_DESCRIPTION'])['RESULT'].last().reset_index()
                    df2 = df2.append(temp_final)
                
                if temp2[(temp2[0] == 2) | (temp2[0] == 3)]['MIC_DESCRIPTION'].iloc[0] == '% FINES':
                    print(temp2[(temp2[0] == 2) | (temp2[0] == 3)]['MIC_DESCRIPTION'].iloc[0])
                    temp_final = temp.sort_values(['CHAR_SR_NO'],ascending=True).groupby(['PLANT' , 'PLANTNAME', 'MATERIAL_DESCRIPTION','PRODUCTCODE','BATCH_ID', 'MIC_DESCRIPTION'])['RESULT'].last().reset_index()
                    df2 = df2.append(temp_final)


            df_pivot = pd.pivot(df2,index = ['BATCH_ID','PRODUCTCODE','MATERIAL_DESCRIPTION','PLANT','PLANTNAME'], columns = ["MIC_DESCRIPTION"], values = ['RESULT'])
            df_pivot = df_pivot['RESULT'].reset_index()

            print("UNIQUE PLANT CODE" , df_pivot['PLANT'].unique())

            df_pivot = df_pivot.rename(columns = {'MATERIAL_DESCRIPTION' : 'PRODUCTNAME' , '% FINES' : 'FINES_STATION_1' , 'BULK DENSITY' : 'BULK_DENSITY_STATION_1' , 'LOSS ON DRYING' : 'LOSS_ON_DRYING_STATION_1' , 'TAPPED DENSITY' :  'TAPPED_DENSITY_STATION_1' ,  'COATING YIELD' : 'COATING_YIELD_PERCENT' , 'COMPRESSION YIELD' : 'COMPRESSION_YIELD_PERCENT' , 'GRANULATION YIELD' :  'GRANULATION_YIELD_PERCENT'})
            site_dict = {1028 : {'SITE' : 'INDORE' , 'UNIT' : '4'}
            }

            df_pivot['SITE'] = df_pivot['PLANT'].apply(lambda x : site_dict[x]['SITE'])
            df_pivot['UNIT'] = df_pivot['PLANT'].apply(lambda x : site_dict[x]['UNIT'])

            df_pivot['CURRENT_DATETIME'] = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
            df_pivot["CURRENT_DATETIME"] = pd.to_datetime(df_pivot["CURRENT_DATETIME"])

            # Adding BatchSize from Batch_ID using RYIELD table
            df_pivot = add_BatchSize_From_BatchID(df_pivot)

            df_pivot = df_pivot.drop(['PLANT' , 'PLANTNAME'] , axis=1)

            df_pivot['LINE'] = np.nan
            df_pivot['FINES_STATION_2'] = np.nan 
            df_pivot['BULK_DENSITY_STATION_2']= np.nan
            df_pivot['LOSS_ON_DRYING_STATION_2']= np.nan
            df_pivot['TAPPED_DENSITY_STATION_2']= np.nan
            df_pivot['MANUFACTURING_YIELD_PERCENT']= np.nan
            df_pivot['MACHINECODE'] = np.nan

            #df_pivot.columns
            col = ['BATCH_ID', 'PRODUCTCODE', 'PRODUCTNAME', 'CURRENT_DATETIME',
                'SITE', 'UNIT','LINE','BATCH_SIZE','FINES_STATION_1',
                'BULK_DENSITY_STATION_1', 'LOSS_ON_DRYING_STATION_1', 'TAPPED_DENSITY_STATION_1',  'FINES_STATION_2',
                'BULK_DENSITY_STATION_2', 'LOSS_ON_DRYING_STATION_2',
                'TAPPED_DENSITY_STATION_2', 'COMPRESSION_YIELD_PERCENT', 'GRANULATION_YIELD_PERCENT',
                'COATING_YIELD_PERCENT','MANUFACTURING_YIELD_PERCENT' ]

            df_pivot = df_pivot[col]

            for i in ['FINES_STATION_1','BULK_DENSITY_STATION_1', 'LOSS_ON_DRYING_STATION_1', 'TAPPED_DENSITY_STATION_1',  'FINES_STATION_2',
                'BULK_DENSITY_STATION_2', 'LOSS_ON_DRYING_STATION_2','TAPPED_DENSITY_STATION_2', 'COMPRESSION_YIELD_PERCENT', 'GRANULATION_YIELD_PERCENT',
                'COATING_YIELD_PERCENT','MANUFACTURING_YIELD_PERCENT' ]:
                
                df_pivot[i] = df_pivot[i].astype(np.float64)

            sparkdf=self.spark.createDataFrame(df_pivot,Schemas.processed_apqr_schema)
            spark_log_df = self.transaction_log.insert_data( "PROCESSED", "APQR" , df_pivot,"PRODUCTCODE" , "PRODUCTNAME" ,"BATCH_ID")

            return sparkdf,spark_log_df
        
        except Exception as e:
            print(e)
            logging.info("Error in Processing Processed APQR")
            spark_log = self.transaction_log.failure_into_sql( "PROCESSED", "APQR" , "Error In Processing PROCESSED APQR" , "Error")
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()
        

    def convert_Raw_APQR_Goa7B(self):
        self.transaction_log.TRANSACTION_ID = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
        self.transaction_log.LOG_FILE_NAME = str(self.transaction_log.TRANSACTION_ID) + '_logging.log'
        self.transaction_log.DATETIME = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        self.transaction_log.LAYER = "PROCESSED"
        self.transaction_log.SUBLAYER = "APQR"
        print(self.df.shape)
        df1 = self.df.copy()
        sql_df = self.transaction_log.create_SQL_DataFrame()
        try:
            df1= df1[df1['PLANT'] == 1047]
            df1 = df1[~(df1['MIC_DESCRIPTION'] == 'NaN')]

            df1 = df1[df1['PRODUCTCODE'].isin([31006667,31009452,31012456])]

            df1['LONG_TEXT_DESCRIPTION'] = df1['LONG_TEXT_DESCRIPTION'].apply(lambda x : x.upper())
            df1['MIC_DESCRIPTION'] = df1['MIC_DESCRIPTION'].apply(lambda x : x.upper())

            col = ["% FINES","LOSS ON DRYING","BULK DENSITY","TAPPED DENSITY","GRANULATION YIELD","COMPRESSION YIELD","COATING YIELD","MANUFACTURING YIELD"]
            df1 = df1[df1["MIC_DESCRIPTION"].isin(col)]

            df1 = df1[((df1["MIC_DESCRIPTION"] == 'COMPRESSION YIELD') & (df1['UOM'] == '%')) | 
                ((df1["MIC_DESCRIPTION"] == 'LOSS ON DRYING') & (df1['UOM'].isin(['%W/W']))) |
                ((df1["MIC_DESCRIPTION"] == 'BULK DENSITY') & (df1['UOM'].isin(['gm/ml']))) |
                ((df1["MIC_DESCRIPTION"] == 'TAPPED DENSITY') & (df1['UOM'].isin(['gm/ml']))) |
                ((df1["MIC_DESCRIPTION"] == '% FINES') & (df1['UOM'].isin(['%']))) |
                ((df1["MIC_DESCRIPTION"] == 'COATING YIELD') & (df1['UOM'] == '%')) |
                ((df1["MIC_DESCRIPTION"] == 'GRANULATION YIELD') & (df1['UOM'] == '%'))
                ]

            # FIltering the %FInes for Goa7B
            df1 = df1[~((df1['MIC_DESCRIPTION'] == '% FINES') & (df1['LONG_TEXT_DESCRIPTION'].str.contains('MESH')))]
            df1 = df1[~ ((df1['MIC_DESCRIPTION'] == '% FINES') & (df1['LONG_TEXT_DESCRIPTION'].str.contains('COMPACTION')))]
            # # df1 = df1[~df1['LONG_TEXT_DESCRIPTION'].str.contains('compaction')]
            # df1 = df1[(df1['MIC_DESCRIPTION'] != '% FINES') | ( (df1['MIC_DESCRIPTION'] == '% FINES') & (df1['LONG_TEXT_DESCRIPTION'].str.contains('stabilization')))]        
            
            df_pivot = pd.pivot(df1,index = ['BATCH_ID','PRODUCTCODE','MATERIAL_DESCRIPTION','PLANT','PLANTNAME'], columns = ["MIC_DESCRIPTION"], values = ['RESULT' ])
            df_pivot = df_pivot['RESULT'].reset_index()

            df_pivot = df_pivot.rename(columns = {'MATERIAL_DESCRIPTION' : 'PRODUCTNAME' , '% FINES' : 'FINES_STATION_1' , 'BULK DENSITY' : 'BULK_DENSITY_STATION_1' , 'LOSS ON DRYING' : 'LOSS_ON_DRYING_STATION_1' , 'TAPPED DENSITY' :  'TAPPED_DENSITY_STATION_1' ,  'COATING YIELD' : 'COATING_YIELD_PERCENT' , 'COMPRESSION YIELD' : 'COMPRESSION_YIELD_PERCENT' , 'GRANULATION YIELD' :  'GRANULATION_YIELD_PERCENT'})
            site_dict = {1047 : {'SITE' : 'GOA' , 'UNIT' : '7B'}}
            
            df_pivot['SITE'] = df_pivot['PLANT'].apply(lambda x : site_dict[x]['SITE'])
            df_pivot['UNIT'] = df_pivot['PLANT'].apply(lambda x : site_dict[x]['UNIT'])

            
            df_pivot['CURRENT_DATETIME'] = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
            df_pivot["CURRENT_DATETIME"] = pd.to_datetime(df_pivot["CURRENT_DATETIME"])

            # Adding BatchSize from Batch_ID using RYIELD table
            df_pivot = add_BatchSize_From_BatchID(df_pivot)

            df_pivot = df_pivot.drop(['PLANT' , 'PLANTNAME'] , axis=1)

            df_pivot['LINE'] = np.nan
            df_pivot['FINES_STATION_2'] = np.nan 
            df_pivot['BULK_DENSITY_STATION_2']= np.nan
            df_pivot['LOSS_ON_DRYING_STATION_2']= np.nan
            df_pivot['TAPPED_DENSITY_STATION_2']= np.nan
            df_pivot['MANUFACTURING_YIELD_PERCENT']= np.nan
            df_pivot['MACHINECODE'] = np.nan


            #df_pivot.columns
            col = ['BATCH_ID', 'PRODUCTCODE', 'PRODUCTNAME', 'CURRENT_DATETIME',
                'SITE', 'UNIT','LINE','BATCH_SIZE','FINES_STATION_1',
                'BULK_DENSITY_STATION_1', 'LOSS_ON_DRYING_STATION_1', 'TAPPED_DENSITY_STATION_1',  'FINES_STATION_2',
                'BULK_DENSITY_STATION_2', 'LOSS_ON_DRYING_STATION_2',
                'TAPPED_DENSITY_STATION_2', 'COMPRESSION_YIELD_PERCENT', 'GRANULATION_YIELD_PERCENT',
                'COATING_YIELD_PERCENT','MANUFACTURING_YIELD_PERCENT' ]

            df_pivot = df_pivot[col]

            for i in ['FINES_STATION_1','BULK_DENSITY_STATION_1', 'LOSS_ON_DRYING_STATION_1', 'TAPPED_DENSITY_STATION_1',  'FINES_STATION_2',
                'BULK_DENSITY_STATION_2', 'LOSS_ON_DRYING_STATION_2','TAPPED_DENSITY_STATION_2', 'COMPRESSION_YIELD_PERCENT', 'GRANULATION_YIELD_PERCENT',
                'COATING_YIELD_PERCENT','MANUFACTURING_YIELD_PERCENT' ]:
                
                df_pivot[i] = df_pivot[i].astype(np.float64)

            sparkdf=self.spark.createDataFrame(df_pivot,Schemas.processed_apqr_schema)

            #-----------------------------------LOgging START-------------------------------
            for productcode in df_pivot['PRODUCTCODE'].unique() :
                logging.info("Product code: %s",productcode)
                self.transaction_log.PRODUCTCODE = productcode
                self.transaction_log.PRODUCTNAME = df_pivot[df_pivot['PRODUCTCODE'] == int(productcode)]['PRODUCTNAME'].iloc[0]
                self.transaction_log.NO_OF_BATCHES = df_pivot.groupby('PRODUCTCODE')['BATCH_ID'].nunique()[int(productcode)]
                self.transaction_log.SITE = "Will Get from Plant Name"
                self.transaction_log.UNIT = "Will Get from Plant Name"
                self.transaction_log.STATUS = "SUCCESS"

                sql_df = self.transaction_log.insert_SQL_DataFrame(sql_df)

            # convert new_df into Spark
            logging.info("SQL_DF shape has been printed")
            logging.info(sql_df.shape)
            for i in sql_df.columns:
                if i != 'DATETIME':
                    sql_df[i] = sql_df[i].astype(str)
            sql_df['DATETIME'] = pd.to_datetime(sql_df['DATETIME'])
            logging.info("-----------------------------------------------")
            logging.info(sql_df.shape)
            spark_log_df = self.spark.createDataFrame(sql_df,schema=Schemas.logging_schemas)
            
            #-----------------------------------LOgging END-------------------------------

            return sparkdf , spark_log_df
        except Exception as e:
            sql_df = self.transaction_log.create_SQL_DataFrame()
            print(e)
            print(" Inside Exception --> Error In Processing APQR Of ALL the Sites")
            logging.info("Inside Exception --> Error In Processing APQR Of ALL the Sites")
            logging.info(e)
            logging.exception(e)
            self.transaction_log.PRODUCTCODE = 'NA'
            self.transaction_log.PRODUCTNAME = 'NA'
            self.transaction_log.SITE = "Will Get from Plant Name"
            self.transaction_log.UNIT = "Will Get from Plant Name"
            self.transaction_log.STATUS = "FAILURE"
            self.transaction_log.FAILURE_REASON = "Error In Processing APQR Of ALL the Sites from Excel"
            self.transaction_log.FAILURE_DESCRIPTION = str(e)

            new_df = self.transaction_log.insert_SQL_DataFrame(sql_df)
            for i in new_df.columns:
                if i != 'DATETIME':
                    new_df[i] = new_df[i].astype(str)
            new_df['DATETIME'] = pd.to_datetime(new_df['DATETIME'])
            print(new_df.shape)
            print(new_df.columns)
            logging.info("----------------------------------------------------")
            logging.info(new_df.columns)
            # convert new_df into Spark
            spark_log = self.spark.createDataFrame(new_df,schema=Schemas.logging_schemas)
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            traceback.print_exc() 
            print(e)

    def push_Data_in_processed_apqr(self,sparkdf,spark_log_df):
        #Push the DataFrame Into SQL Table
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf,"dbo.MLOPS_PIPELINE_PROCESSED_APQR")
        print("DATA PUSHED SUCCESSFULLY FOR PROCESSED APQR")
        self.transaction_log.push_DataFrame_to_sql(spark_log_df)
        print("DATA PUSHED SUCCESSFULLY FOR LOGGING FOR PROCESSED APQR")


    
            
       
        
