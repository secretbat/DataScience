import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import traceback
import logging
import pyspark
from pyspark.sql import SparkSession
from DataPipeline import TableColumn
from datetime import datetime
from DataPipeline import Schemas
from DataPipeline.SQLConnection import SQLConnection
from datetime import datetime
from tqdm import tqdm
from DataPipeline.TransactionLog import TransactionLog

import traceback
import logging


class Scada_Manual:
    def __init__(self) -> None:
        self.df = self.fetch_scada_data()
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.transaction_log = TransactionLog()

    def fetch_scada_data(self):
        # Filtering the Data Based on Product code, machine code , batch size and preprocessed DateTime
        """
        THis method fetch Data From PreProcessed Table based on Product code, machine code
        , batch size and preprocessed DateTime which is not there in FinalLayer Table
        """

        sql = SQLConnection()
        df = sql.read_table_data("dbo.MLOPS_PIPELINE_RAW_SCADA")

        return df

    def calculate_final_duration_in_mins(self):
        try:
            df = self.df
            start_time_df = df.groupby("BATCH_ID")["DATETIME"].min().reset_index()
            start_time_df.columns = ["BATCH_ID", "start_time"]
            end_time_df = df.groupby("BATCH_ID")["DATETIME"].max().reset_index()
            end_time_df.columns = ["BATCH_ID", "end_time"]
            duration_df = start_time_df.merge(
                end_time_df, on=["BATCH_ID"], validate="1:1"
            )
            final_df = duration_df
            final_df["duration_in_mins"] = (
                final_df["end_time"] - final_df["start_time"]
            ) / np.timedelta64(1, "m")

            break_duration = {}

            for batch in tqdm(df["BATCH_ID"].unique()):
                temp_df = (
                    df[df.BATCH_ID == batch]
                    .sort_values("DATETIME")
                    .reset_index(drop=True)
                )

                temp_df["Time_shifted"] = temp_df["DATETIME"].shift(1)
                temp_df["break_duration"] = (
                    temp_df["DATETIME"] - temp_df["Time_shifted"]
                ) / np.timedelta64(1, "m")
                temp_df.drop("Time_shifted", axis=1, inplace=True)
                duration = temp_df[temp_df["break_duration"] > 5][
                    "break_duration"
                ].sum()
                break_duration[batch] = duration

            break_df = (
                pd.DataFrame(break_duration, index=range(0, 30, 1)).T[0].reset_index()
            )
            break_df.columns = ["BATCH_ID", "break_5M_above"]
            break_df.sort_values("BATCH_ID").index

            final_df = final_df.merge(break_df, on="BATCH_ID", how="inner")
            final_df["FINAL_DURATION_IN_MINS"] = (
                final_df["duration_in_mins"] - final_df["break_5M_above"]
            )
            df = df.merge(final_df[["BATCH_ID", "FINAL_DURATION_IN_MINS"]])

            sparkDF = self.spark.createDataFrame(
                data=df, schema=Schemas.processed_scada_schema_manual
            )
            spark_log_df = self.transaction_log.insert_data(
                "PROCESSED",
                "SCADA MANUAL",
                df,
                "PRODUCTCODE",
                "PRODUCTNAME",
                "BATCH_ID",
            )
            return sparkDF, spark_log_df

        except Exception as e:
            print(e)
            logging.info("Error in Processing SCADA file")
            spark_log = self.transaction_log.failure_into_sql(
                "PROCESSED", "SCADA", "Error In Processing PROCESSED SCADA", "Error"
            )
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()

    def push_Data_in_processed_scada(self, sparkdf, spark_log_df):
        # Push the DataFrame Into SQL Table
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf, "dbo.MLOPS_PIPELINE_PROCESSED_SCADA")
        logging.info("DATA IS SUCCESSFUL PUSHED IN PROCESSED SCADA")

        self.transaction_log.push_DataFrame_to_sql(spark_log_df)

        print("!!!!!!!!! DATA IS SUCCESSFULLY PUSHed IN LOGGING FOR PROCESSED SCADA")
