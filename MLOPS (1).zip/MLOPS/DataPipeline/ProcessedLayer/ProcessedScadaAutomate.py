import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import traceback
import logging
import pyspark
from pyspark.sql import SparkSession
from DataPipeline import TableColumn
from datetime import datetime
from DataPipeline import Schemas
from DataPipeline.SQLConnection import SQLConnection
from datetime import datetime
from tqdm import tqdm
from DataPipeline.TransactionLog import TransactionLog
from pyspark.sql.functions import lit
import traceback
import logging


class Processed_Scada_Automate:
    def __init__(self) -> None:
        self.df = self.fetch_scada_data()
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.transaction_log = TransactionLog()

    def fetch_scada_data(self):
        # Filtering the Data Based on Product code, machine code , batch size and preprocessed DateTime
        """
        THis method fetch Data From PreProcessed Table based on Product code, machine code
        , batch size and preprocessed DateTime which is not there in FinalLayer Table
        """
        table = "[dbo].[MLOPS_PIPELINE_AUTOMATED_SCADA]"

        query = f"""SELECT a.*,cast(b.TOTAL_DURATION as FLOAT) AS FINAL_DURATIONS_IN_MINS FROM {table} a
          LEFT JOIN
          (SELECT distinct BATCH_ID,STAGE,SUBSTAGE,LOTNUMBER,(DATEDIFF(minute,MIN(DATETIME) OVER(PARTITION BY BATCH_ID,STAGE,SUBSTAGE,LOTNUMBER),MAX(DATETIME) OVER(PARTITION BY BATCH_ID,STAGE,SUBSTAGE,LOTNUMBER))-sum(BREAK_DURATION) OVER(PARTITION BY BATCH_ID,STAGE,SUBSTAGE,LOTNUMBER)) TOTAL_DURATION FROM
          (SELECT BATCH_ID,STAGE,SUBSTAGE,LOTNUMBER,DATETIME,IIF(BREAK_DURATION>5,0,BREAK_DURATION) BREAK_DURATION FROM
          (SELECT *, DATEDIFF(minute,(LAG(DATETIME) OVER(PARTITION BY BATCH_ID,STAGE,SUBSTAGE,LOTNUMBER ORDER BY DATETIME)),DATETIME) AS BREAK_DURATION FROM 
          (select BATCH_ID,STAGE,SUBSTAGE,LOTNUMBER,convert(DATETIME2,DATETIME,126) DATETIME FROM {table}) a) a) a)b
          on a.BATCH_ID = b.BATCH_ID
          and a.STAGE = b.STAGE
          and a.SUBSTAGE = b.SUBSTAGE
          and a.LOTNUMBER = b.LOTNUMBER
          WHERE a.BATCH_ID NOT IN (SELECT DISTINCT BATCH_ID from [dbo].[MLOPS_PIPELINE_PROCESSED_SCADA])
          """

        sql = SQLConnection()
        df = sql.read_tables_data_spark(query)

        return df

    def intermediate_processing(self):
        try:
            scada = self.df
            for col in Schemas.processed_scada_schema_manual.fieldNames():
                if col not in scada.columns:
                    scada = scada.withColumn(f"{col}", lit(None))

            scada = scada[Schemas.processed_scada_schema_manual.fieldNames()]

            scada = self.spark.createDataFrame(
                scada.rdd, schema=Schemas.processed_scada_schema_manual
            )

            

            spark_log_df = self.transaction_log.insert_data_spark(
                "PROCESSED",
                "AUTOMATE SCADA",
                scada,
                "PRODUCTCODE",
                "PRODUCTNAME",
                "BATCH_ID",
            )
            return scada, spark_log_df

        except Exception as e:
            print(e)
            logging.info("Error in Processing SCADA file")
            spark_log = self.transaction_log.failure_into_sql(
                "PROCESSED",
                "SCADA AUTOMATE",
                "Error In Processing PROCESSED SCADA AUTOMATE",
                "Error",
            )
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()

    def push_Data_in_processed_scada(self, sparkdf, spark_log_df):
        # Push the DataFrame Into SQL Table
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf, "dbo.MLOPS_PIPELINE_PROCESSED_SCADA")
        logging.info("DATA IS SUCCESSFUL PUSHED IN PROCESSED SCADA AUTOMATE ")

        self.transaction_log.push_DataFrame_to_sql(spark_log_df)

        print(
            "!!!!!!!!! DATA IS SUCCESSFULLY PUSHed IN LOGGING FOR PROCESSED SCADA AUTOMATE"
        )
