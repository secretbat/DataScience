import pandas as pd
import numpy as np
import logging
import traceback
from DataPipeline.SQLConnection import SQLConnection
import joblib
from box import ConfigBox
from box.exceptions import BoxValueError
from pathlib import Path
import yaml
import os

import logging
import pyspark
from pyspark.sql import SparkSession
from DataPipeline import TableColumn
from datetime import datetime
from DataPipeline import Schemas
from tqdm import tqdm
import glob
import re

import pdfplumber
import multiprocessing as mp
import shutil
import traceback
from DataPipeline.TransactionLog import TransactionLog


def add_ProductCode_From_BatchID(df):
    # get the unique BatchID
    if "PRODUCTCODE" in df.columns:
        df = df.drop("PRODUCTCODE", axis=1)

    print(df.head())
    list_of_batches = str(set(df["BATCH_ID"])).replace("{", "(").replace("}", ")")
    print(list_of_batches)
    logging.info("List of batches: %s", list_of_batches)
    logging.info("Initial DataFrame: %s", df.head())
    query = "SELECT distinct BATCH_ID ,PRODUCTCODE FROM dbo.MLOPS_PIPELINE_RAW_APQR  WHERE BATCH_ID IN {}".format(list_of_batches)
    print(query)
    sql = SQLConnection()
    apqr_df = sql.read_table_data_with_query(query)

    df = df.merge(apqr_df, on="BATCH_ID", how="left")
    logging.info("After  DataFrame: %s", df.columns)
    df["PRODUCTCODE"] = df["PRODUCTCODE"].replace([np.NAN, None], -99)
    df["PRODUCTCODE"] = df["PRODUCTCODE"].astype(int)

    return df


def add_BatchSize_From_BatchID(df):
    if "BATCH_SIZE" in df.columns:
        df = df.drop("BATCH_SIZE", axis=1)

    list_of_batches = str(set(df["BATCH_ID"])).replace("{", "(").replace("}", ")")
    logging.info("Initial DataFrame: %s", df.head())
    # query = "SELECT distinct BATCH_ID,BATCH_SIZE FROM dbo.MLOPS_PIPELINE_RAW_RYIELD  WHERE BATCH_ID IN {}".format(
    #     list_of_batches
    #     )

    query = "SELECT distinct Batch_Number as BATCH_ID, Batch_Size as BATCH_SIZE FROM dbo.ZPP_Ryield  WHERE Batch_Number IN {}".format(
        list_of_batches
    )

    sql = SQLConnection()
    apqr_df = sql.read_table_data_with_query(query)
    df = df.merge(apqr_df, on="BATCH_ID", how="left")
    df["BATCH_SIZE"] = df["BATCH_SIZE"].replace([np.NAN, None], -99)
    logging.info("After  DataFrame: %s", df.columns)
    # df.to_csv("/dbfs/mnt/pegasusdatalake/MLOps/Source/abc.csv")
    df["BATCH_SIZE"] = df["BATCH_SIZE"].astype(int)

    return df


def read_yaml_config(path_to_yaml: Path) -> ConfigBox:
    """reads yaml file and returns
    Args:
        path_to_yaml (str): path like input
    Raises:
        ValueError: if yaml file is empty
        e: empty file
    Returns:
        ConfigBox: ConfigBox type
    """
    try:
        with open(path_to_yaml) as yaml_file:
            content = yaml.safe_load(yaml_file)
            return ConfigBox(content)
    except BoxValueError:
        raise ValueError("yaml file is empty")
    except Exception as e:
        raise e


def get_batchid_from_file(file, equipment_id, batch_line):
    try:
        out_file = file.replace("Source", "Archive")
        out_dir = "/".join(out_file.split("/")[:-1])

        if os.path.exists(out_file):
            # File is already exists in the archive directory. FIles is already Processed. We have to delete the file
            os.remove(out_file)
            return False
        else:
            try:
                pdf = pdfplumber.open(file)
                page = pdf.pages[0]
                txt = page.extract_text()
                lines = txt.split("\n")

                if equipment_id in (["t046", "tm018", "t045"]):
                    batch_no = (
                        lines[batch_line].lower().split("batch:")[-1].strip().upper()
                    )

                elif equipment_id in (["t235", "t270"]):
                    for i in range(len(lines)):
                        if (
                            lines[i].strip() == "Batch-No.:"
                            or lines[i].strip() == "Batch-Name:"
                        ):
                            break
                    if i == len(lines)-1:
                        return False
                    else:
                        batch_no = lines[i + 1].strip().upper()
                                
                else:
                    print("New Equipment")
                    batch_no = None

                pdf.close()

                query = "SELECT * FROM dbo.MLOPS_PIPELINE_RAW_HMI WHERE BATCH_ID = '{}'".format(
                    batch_no
                )
                sql = SQLConnection()
                apqr_df = sql.read_table_data_with_query(query)
                if apqr_df.shape[0] != 0:
                    # it means the batch no is already in the database. We don't want to processed it. Remove the files
                    archive_files(file, "Archive")
                    return False
                elif apqr_df.shape[0] == 0:
                    # it means the batch is not present in the database. We have want to processed
                    return True
            except Exception as e:
                print(e)
                print("Error file : " + file)
                print(traceback.print_exc())
                if e.__class__.__name__ == "PDFSyntaxError":
                    print("COrrupt File")
                    print(
                        "Error processing PDF Due to PDF Syntax Error Either FIle is TXT or corrupt PDF file"
                    )
                    archive_files(file, "Corrupt")

                return False

    except:
        print(f"Error File: {file}")


def archive_files(file, destinationfolder):
    if destinationfolder == "Archive":
        out_file = file.replace("Source", "Archive")
    elif destinationfolder == "Corrupt":
        out_file = file.replace("Source", "Corrupt")

    out_dir = "/".join(out_file.split("/")[:-1])
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)
    shutil.move(file, out_file)
