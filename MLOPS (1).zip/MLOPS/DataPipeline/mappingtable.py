# Plant Code --> Site --> Machine Code -->Stage

mapping = { 1047 : { 'Goa' : {'7b' : { 't337' : 'granulation' , 't338' : 'coating' }}} ,
            1047 : { 'Goa' : {'7b' : { 't337' : 'granulation' , 't338' : 'coating' }}}
           }
