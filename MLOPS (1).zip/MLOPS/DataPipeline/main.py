import logging
import traceback
import time
from DataPipeline.utils import *
from DataPipeline.utils import read_yaml_config

global content
content = read_yaml_config("/dbfs/mnt/pegasusdatalake/MLOps/config.yml")


def raw_HMI():
    # It Worked
    print(content.stages.HMI.Source)
    print(content.stages.HMI.date_line)
    from DataPipeline.RawLayer.Raw_HMI import HMI

    folder_path = content.stages.HMI.Source
    destination_folder_path = content.stages.HMI.Destination
    date_line = content.stages.HMI.date_line
    product_line = content.stages.HMI.product_line
    batch_line = content.stages.HMI.batch_line

    

    hmi = HMI(folder_path, destination_folder_path, date_line, product_line, batch_line)
    spark_df, spark_log_df = hmi.fetch_HMI_Files()
    if spark_df != None:
        print((spark_df.count(), len(spark_df.columns)))
        hmi.push_to_raw_HMI(spark_df, spark_log_df)


def raw_BMR_granulation():
    #  It worked
    from DataPipeline.RawLayer.Raw_BMR_Granulation import Raw_BMR_Granulation

    raw_bmr = Raw_BMR_Granulation(
        "/dbfs/mnt/pegasusdatalake/MLOps/Source/BMR Granulation", ""
    )
    sparkdf, spark_log_df = raw_bmr.fetch_BMR_Granilation_File()

    print("------------------------------")
    print((sparkdf.count(), len(sparkdf.columns)))
    raw_bmr.push_to_raw_granulation_bmr(sparkdf, spark_log_df)


def processed_BMR_granulation():
    # It worked
    from DataPipeline.ProcessedLayer.ProcessedBMRGranulation import (
        Processed_BMR_Granulation,
    )

    processed_bmr_granulation = Processed_BMR_Granulation()
    spark_df = processed_bmr_granulation.get_Raw_Data_from_SQL()
    (
        spark_df,
        spark_log_df,
    ) = processed_bmr_granulation.raw_processed_extraction_bmr_granulation(spark_df)
    processed_bmr_granulation.push_processed_bmr_granulation(spark_df, spark_log_df)

    print("DATA IS SUCCESSFULLY Processed BMR Granulation")

def raw_ryield():
    from DataPipeline.RawLayer.Raw_Ryield import Raw_RYIELD
    folder_path = content.stages.RYIELD.Source
    raw_ryield = Raw_RYIELD(folder_path, "")
    sparkdf, spark_log_df = raw_ryield.fetch_RYIELD_Files()
    print((sparkdf.count(), len(sparkdf.columns)))
    raw_ryield.push_Data_in_raw_ryield(sparkdf, spark_log_df)



def raw_APQR():
    # It Worked
    from DataPipeline.RawLayer.Raw_APQR import Raw_APQR

    raw_apqr = Raw_APQR(
        "/dbfs/mnt/pegasusdatalake/historical_pipeline_data/APQR data for all sites/**.XLSX",
        "",
    )
    sparkdf, spark_log_df = raw_apqr.fetch_APQR_Files()
    raw_apqr.push_Data_in_raw_apqr(sparkdf, spark_log_df)


def processed_APQR():
    # It worked
    from DataPipeline.ProcessedLayer.ProcessedAPQR import APQR

    apqr = APQR()
    # sparkdf,spark_log_df = apqr.convert_Raw_APQR_Goa7B()
    sparkdf, spark_log_df = apqr.convert_Raw_APQR_Indore4()
    apqr.push_Data_in_processed_apqr(sparkdf, spark_log_df)
    print((sparkdf.count(), len(sparkdf.columns)))


def raw_bmr_compression():
    # It  worked
    from DataPipeline.RawLayer.Raw_BMR_Compression import Raw_BMR_Compression

    raw_bmr_compression = Raw_BMR_Compression(
        "/dbfs/mnt/pegasusdatalake/MLOps/Source/BMR Compression", ""
    )
    sparkdf, spark_log_df = raw_bmr_compression.fetch_BMR_Compression_File()
    print(type(sparkdf))
    print((sparkdf.count(), len(sparkdf.columns)))
    raw_bmr_compression.push_to_raw_compression_bmr(sparkdf, spark_log_df)


def processed_bmr_compression():
    # It Worked
    from DataPipeline.ProcessedLayer.ProcessedBMRCompression import (
        Processed_BMR_Compression,
    )

    processed_bmr_compression = Processed_BMR_Compression()
    spark_df = processed_bmr_compression.get_Raw_Data_from_SQL()
    print((spark_df.count(), len(spark_df.columns)))
    (
        spark_df,
        spark_log_df,
    ) = processed_bmr_compression.raw_processed_extraction_bmr_compression(spark_df)
    print((spark_df.count(), len(spark_df.columns)))
    processed_bmr_compression.push_processed_bmr_compression(spark_df, spark_log_df)


def raw_scada_manual():
    # It worked
    from DataPipeline.RawLayer.Scada_Manual import Scada

    scada = Scada("/dbfs/mnt/pegasusdatalake/MLOps/Source/Scada/goa7b/TM-022", "")
    sparkdf, spark_log_df = scada.fetch_Scada_PDF_File()
    print((sparkdf.count(), len(sparkdf.columns)))
    scada.push_to_scada_raw(sparkdf, spark_log_df)


def processed_scada_manual():
    from DataPipeline.ProcessedLayer.ProcessedScadaManual import Scada_Manual

    scada = Scada_Manual()
    sparkdf, spark_log_df = scada.calculate_final_duration_in_mins()
    print((sparkdf.count(), len(sparkdf.columns)))
    scada.push_Data_in_processed_scada(sparkdf, spark_log_df)


def raw_scada_automate():
    from DataPipeline.RawLayer.Scada_Automate import Scada_Auto
    logging.info("Inside raw_scada_automate()")
    scada = Scada_Auto()
    try:
        sparkdf, spark_log_df= scada.intermediate_processing()
        # print((sparkdf.count(), len(sparkdf.columns)))
        scada.push_Data_in_automated_scada(sparkdf,spark_log_df)
    except Exception as e:
        logging.info(e)
        logging.exception(e)
        logging.error(e,exc_info=True)
        traceback.print_exc()
        
    


def processed_scada_automate():
    from DataPipeline.ProcessedLayer.ProcessedScadaAutomate import (
        Processed_Scada_Automate,
    )

    scada = Processed_Scada_Automate()
    sparkdf,spark_log_df = scada.intermediate_processing()
    # print((sparkdf.count(), len(sparkdf.columns)))
    scada.push_Data_in_processed_scada(sparkdf,spark_log_df)


def final_compression():
    from DataPipeline.FinalLayer.Compression import Compression

    compression = Compression()
    print(compression.df)
    sparkdf, spark_log_df = compression.final_processed_layer()
    print("----------------------------------------")
    print((sparkdf.count(), len(sparkdf.columns)))
    compression.push_Data_in_final_compression(sparkdf, spark_log_df)


def final_coating():
    from DataPipeline.FinalLayer.Coating import Coating

    coating = Coating()
    sparkdf, spark_log_df = coating.final_processed_layer()
    print((sparkdf.count(), len(sparkdf.columns)))
    coating.push_Data_in_final_coating(sparkdf, spark_log_df)


def final_granulation():
    from DataPipeline.FinalLayer.Granulation import Granulation

    granulation = Granulation()
    sparkdf, spark_log_df = granulation.final_processed_layer()
    print((sparkdf.count(), len(sparkdf.columns)))
    granulation.push_Data_in_final_coating(sparkdf, spark_log_df)
