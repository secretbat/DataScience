 
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark.sql.functions import col


raw_hmi_schema = T.StructType(
    [
      T.StructField('BATCH_ID', T.StringType(), True),
      T.StructField('MACHINE_CODE', T.StringType(), True),
      T.StructField('PRODUCT_NAME', T.StringType(), True),
      T.StructField('BATCH_DATETIME', T.TimestampType(), True),
      T.StructField('CURRENT_DATETIME', T.TimestampType(), True),
      T.StructField('MAIN_COMPR_FORCE_MV_KN_STATION_1', T.LongType(), True),
      T.StructField('MAIN_COMPR_FORCE_MV_KN_STATION_2', T.LongType(), True),
      T.StructField('PRE_COMPR_FORCE_MV_KN_STATION_1', T.LongType(), True),
      T.StructField('PRE_COMPR_FORCE_MV_KN_STATION_2', T.LongType(), True),
      T.StructField('TABL_CYL_HT_MAIN_CO_MM_STATION_1', T.LongType(), True),
      T.StructField('TABL_CYL_HT_MAIN_CO_MM_STATION_2', T.LongType(), True),
      T.StructField('TABL_CYL_HT_PRE_CO_MM_STATION_1', T.LongType(), True),
      T.StructField('TABL_CYL_HT_PRE_CO_MM_STATION_2', T.LongType(), True),
      T.StructField('TABL_FILLING_DEPTH_MM_STATION_1', T.LongType(), True),
      T.StructField('TABL_FILLING_DEPTH_MM_STATION_2', T.LongType(), True),
      T.StructField('FILLING_DEVICE_SPEED_STATION_1', T.LongType(), True),
      T.StructField('FILL-O-MATIC_SPEED_RPM_STATION_1', T.LongType(), True),
      T.StructField('TABLETS_PER_HOUR_STATION_1', T.LongType(), True),
      T.StructField('FILLING_DEVICE_SPEED_STATION_2', T.LongType(), True),
      T.StructField('FILL-O-MATIC_SPEED_RPM_STATION_2', T.LongType(), True),
      T.StructField('TABLETS_PER_HOUR_STATION_2', T.LongType(), True),
      T.StructField('PRODUCTCODE', T.IntegerType(), True)  
    ]
  )

raw_apqr_schema = T.StructType(
  [
    T.StructField('BATCH_ID', T.StringType(), True),
    T.StructField('CURRENT_DATETIME', T.TimestampType(), True),
    T.StructField('PRODUCTCODE', T.IntegerType(), True),
    T.StructField('INSPECTION_LOT_NO', T.LongType(), True),
    T.StructField('MATERIAL_DESCRIPTION', T.StringType(), True),
    T.StructField('PLANT', T.IntegerType(), True),
    T.StructField('PLANTNAME', T.StringType(), True),
    T.StructField('RECIPE_NO', T.IntegerType(), True),
    T.StructField('PRODUCTION_VERSION', T.IntegerType(), True),  
    T.StructField('UD_STATUS', T.StringType(), True),
    T.StructField('OPERATION_NO', T.StringType(), True),
    T.StructField('CHAR_SR_NO', T.IntegerType(), True),
    T.StructField('MIC_NO', T.StringType(), True),
    T.StructField('MIC_DESCRIPTION', T.StringType(), True),
    T.StructField('TARGET_VALUE', T.StringType(), True),  
    T.StructField('LOWER_VALUE', T.StringType(), True),
    T.StructField('HIGHER_VALUE', T.StringType(), True),
    T.StructField('RESULT', T.StringType(), True),   
    T.StructField('UOM', T.StringType(), True),
    T.StructField('LONG_TEXT_DESCRIPTION', T.StringType(), True),
    T.StructField('ADDITIONAL_INFORMATION', T.StringType(), True)   
  ]
)

raw_ryield_schema = T.StructType(
  [
    T.StructField('BATCH_ID', T.StringType(), True),
    T.StructField('PRODUCTCODE', T.IntegerType(), True),
    T.StructField('PRODUCTNAME', T.StringType(), True),
    T.StructField('CURRENT_DATETIME', T.TimestampType(), True),
    T.StructField('BATCH_SIZE', T.IntegerType(), True),
    T.StructField('OVERALL_YIELD_PERCENT', T.DoubleType(), True)
  ]
)


scada_manual_schemas = T.StructType(
[
    T.StructField('BATCH_ID', T.StringType(), True),
    T.StructField('MACHINECODE', T.StringType(), True),
    T.StructField('PRODUCTCODE', T.IntegerType(), True),
    T.StructField('PRODUCTNAME', T.StringType(), True),
    T.StructField('USER_FULL_NAME', T.StringType(), True),
    T.StructField('STAGE', T.StringType(), True),
    T.StructField('SUBSTAGE', T.StringType(), True),
    T.StructField('DATETIME', T.TimestampType(), True),
    T.StructField('LOTNUMBER', T.StringType(), True),
    T.StructField('CURRENT_DATETIME', T.TimestampType(), True),
    T.StructField('PAN_SPEED_SET', T.DoubleType(), True),
    T.StructField('PAN_SPEED_ACT', T.DoubleType(), True),
    T.StructField('INLET_TEMP_ACT', T.DoubleType(), True),
    T.StructField('INLET_TEMP_SET', T.DoubleType(), True),
    T.StructField('SPRAY_RATE_ACT', T.DoubleType(), True),
    T.StructField('SPRAY_PUMP_RPM_ACT', T.DoubleType(), True),
    T.StructField('AIR_FLOW_CFM_ACT', T.DoubleType(), True),
    T.StructField('AIR_FLOW_INLET_M_S_ACT', T.DoubleType(), True),
    T.StructField('EXHAUST_TEMP_ACT', T.DoubleType(), True),
    T.StructField('EXHAUST_TEMP_SET', T.DoubleType(), True),
    T.StructField('EXHAUST_FLAP_SET', T.DoubleType(), True),
    T.StructField('EXHAUST_FLAP_ACT', T.DoubleType(), True),
    T.StructField('PRODUCT_TEMP_ACT', T.DoubleType(), True),
    T.StructField('PRODUCT_TEMP_SET', T.DoubleType(), True),
    T.StructField('DRIVE_SPEED_ACT', T.DoubleType(), True),
    T.StructField('DRIVE_SPEED_SET', T.DoubleType(), True),
    T.StructField('BLOWER_DRIVE_ACT', T.DoubleType(), True),
    T.StructField('BLOWER_DRIVE_SET', T.DoubleType(), True),
    T.StructField('ATOMIZATION_AIR_ACT', T.DoubleType(), True),
    T.StructField('ATOMIZATION_AIR_SET', T.DoubleType(), True),
    T.StructField('AIR_FLOW_CFM_SET', T.DoubleType(), True),
    T.StructField('DRUM_SPEED_RPM_SET', T.DoubleType(), True),
    T.StructField('DRUM_SPEED_RPM_ACT', T.DoubleType(), True),
    T.StructField('PD_DRUM_POINT_MMWC_SET', T.DoubleType(), True),
    T.StructField('PD_DRUM_POINT_MMWC_ACT', T.DoubleType(), True),
    T.StructField('DEW_POINT_C_ACT', T.DoubleType(), True)


]
)

processed_scada_schema_manual = T.StructType( 
[
    T.StructField('BATCH_ID', T.StringType(), True),
    T.StructField('MACHINECODE', T.StringType(), True),
    T.StructField('PRODUCTCODE', T.IntegerType(), True),
    T.StructField('PRODUCTNAME', T.StringType(), True),
    T.StructField('USER_FULL_NAME', T.StringType(), True),
    T.StructField('STAGE', T.StringType(), True),
    T.StructField('SUBSTAGE', T.StringType(), True),
    T.StructField('DATETIME', T.TimestampType(), True),
    T.StructField('LOTNUMBER', T.StringType(), True),
    T.StructField('CURRENT_DATETIME', T.TimestampType(), True),
    T.StructField('PAN_SPEED_SET', T.DoubleType(), True),
    T.StructField('PAN_SPEED_ACT', T.DoubleType(), True),
    T.StructField('INLET_TEMP_ACT', T.DoubleType(), True),
    T.StructField('INLET_TEMP_SET', T.DoubleType(), True),
    T.StructField('SPRAY_RATE_ACT', T.DoubleType(), True),
    T.StructField('SPRAY_PUMP_RPM_ACT', T.DoubleType(), True),
    T.StructField('AIR_FLOW_CFM_ACT', T.DoubleType(), True),
    T.StructField('AIR_FLOW_INLET_M_S_ACT', T.DoubleType(), True),
    T.StructField('EXHAUST_TEMP_ACT', T.DoubleType(), True),
    T.StructField('EXHAUST_TEMP_SET', T.DoubleType(), True),
    T.StructField('EXHAUST_FLAP_SET', T.DoubleType(), True),
    T.StructField('EXHAUST_FLAP_ACT', T.DoubleType(), True),
    T.StructField('PRODUCT_TEMP_ACT', T.DoubleType(), True),
    T.StructField('PRODUCT_TEMP_SET', T.DoubleType(), True),
    T.StructField('DRIVE_SPEED_ACT', T.DoubleType(), True),
    T.StructField('DRIVE_SPEED_SET', T.DoubleType(), True),
    T.StructField('BLOWER_DRIVE_ACT', T.DoubleType(), True),
    T.StructField('BLOWER_DRIVE_SET', T.DoubleType(), True),
    T.StructField('ATOMIZATION_AIR_ACT', T.DoubleType(), True),
    T.StructField('ATOMIZATION_AIR_SET', T.DoubleType(), True),
    T.StructField('AIR_FLOW_CFM_SET', T.DoubleType(), True),
    T.StructField('DRUM_SPEED_RPM_SET', T.DoubleType(), True),
    T.StructField('DRUM_SPEED_RPM_ACT', T.DoubleType(), True),
    T.StructField('PD_DRUM_POINT_MMWC_SET', T.DoubleType(), True),
    T.StructField('PD_DRUM_POINT_MMWC_ACT', T.DoubleType(), True),
    T.StructField('DEW_POINT_C_ACT', T.DoubleType(), True),
    T.StructField('FINAL_DURATIONS_IN_MINS', T.DoubleType(), True)
]

)

#schema to represent out json data
processed_apqr_schema = T.StructType(
  [
    T.StructField('BATCH_ID', T.StringType(), False),
    # T.StructField('MACHINECODE', T.StringType(), True),
    T.StructField('PRODUCTCODE', T.IntegerType(), False),
    T.StructField('PRODUCTNAME', T.StringType(), False),
    T.StructField('CURRENT_DATETIME', T.TimestampType(), False),
    T.StructField('SITE', T.StringType(), False),
    T.StructField('UNIT', T.StringType(), False),
    T.StructField('LINE', T.StringType(), True),
    T.StructField('BATCH_SIZE', T.IntegerType(), True),
    T.StructField('FINES_STATION_1', T.DoubleType(), True),  
    T.StructField('BULK_DENSITY_STATION_1', T.DoubleType(), True),
    T.StructField('LOSS_ON_DRYING_STATION_1', T.DoubleType(), True),
    T.StructField('TAPPED_DENSITY_STATION_1', T.DoubleType(), True),
    T.StructField('FINES_STATION_2', T.DoubleType(), True),
    T.StructField('BULK_DENSITY_STATION_2', T.DoubleType(), True),
    T.StructField('LOSS_ON_DRYING_STATION_2', T.DoubleType(), True),
    T.StructField('TAPPED_DENSITY_STATION_2', T.DoubleType(), True),
    T.StructField('COMPRESSION_YIELD_PERCENT', T.DoubleType(), True),
    T.StructField('GRANULATION_YIELD_PERCENT', T.DoubleType(), True),
    T.StructField('COATING_YIELD_PERCENT', T.DoubleType(), True),
    T.StructField('MANUFACTURING_YIELD_PERCENT', T.DoubleType(), True)   
  ]
)



raw_bmr_granulation = T.StructType(
    [
    T.StructField('BATCH_ID', T.StringType(), True),
    T.StructField('MATERIAL_CODE', T.StringType(), True),
    T.StructField('PRODUCT_NAME', T.StringType(), True),
    T.StructField('CURRENT_DATETIME', T.TimestampType(), True),
    T.StructField('PARAMETER_VALUE', T.StringType(), True),
    T.StructField('DATETIME', T.TimestampType(), True)
    ]
)

raw_bmr_compression = T.StructType(
    [
    T.StructField('BATCH_ID', T.StringType(), True),
    T.StructField('MATERIAL_CODE', T.StringType(), True),
    T.StructField('PRODUCT_NAME', T.StringType(), True),
    T.StructField('CURRENT_DATETIME', T.TimestampType(), True),
    T.StructField('PARAMETER_VALUE', T.StringType(), True)
    ]
)

raw_bmr_intermediate_processing  = T.StructType(
    [
      T.StructField("lot", T.StringType(), True),
      T.StructField("part", T.StringType(), True),
      T.StructField("weight", T.StringType(), True),
      T.StructField("stage", T.StringType(), True),
      T.StructField("sub_stage", T.StringType(), True),
      T.StructField("atomization_pressure_set", T.StringType(), True),
      T.StructField("atomization_pressure_act", T.StringType(), True),
      T.StructField("bed_temparature_set", T.StringType(), True),
      T.StructField("bed_temparature_act", T.StringType(), True),
      T.StructField("exhaust_temparature_set", T.StringType(), True),
      T.StructField("exhaust_temparature_act", T.StringType(), True),
      T.StructField("inlet_temparature_set", T.StringType(), True),
      T.StructField("inlet_temparature_act", T.StringType(), True),
      T.StructField("product_temparature_set", T.StringType(), True),
      T.StructField("product_temparature_act", T.StringType(), True),
      T.StructField("inlet_air_flow_set", T.StringType(), True),
      T.StructField("inlet_air_flow_act", T.StringType(), True),
      T.StructField("pan_speed_set", T.StringType(), True),
      T.StructField("pan_speed_act", T.StringType(), True),
      T.StructField("spray_rate", T.StringType(), True),
      T.StructField("net_weight", T.StringType(), True),
      T.StructField("granulation_yield", T.StringType(), True),
      
    ]
  )

raw_bmr_intermediate_processing_compression = T.StructType(
    [
      T.StructField("granulation_lod_part_a", T.StringType(), True),
      T.StructField("granulation_lod_part_b", T.StringType(), True),
      T.StructField("granulation_bd_part_a", T.StringType(), True),
      T.StructField("granulation_bd_part_b", T.StringType(), True),
      T.StructField("granulation_td_part_a", T.StringType(), True),
      T.StructField("granulation_td_part_b", T.StringType(), True),
      T.StructField("granulation_%fines_part_a", T.StringType(), True),
      T.StructField("granulation_%fines_part_b", T.StringType(), True),
      T.StructField("group_weight_lhs", T.StringType(), True),
      T.StructField("group_weight_rhs", T.StringType(), True),
      T.StructField("hardness_min_lhs", T.StringType(), True),
      T.StructField("hardness_max_lhs", T.StringType(), True),
      T.StructField("hardness_min_rhs", T.StringType(), True),
      T.StructField("hardness_max_rhs", T.StringType(), True),
      T.StructField("thickness_min_lhs", T.StringType(), True),
      T.StructField("thickness_max_lhs", T.StringType(), True),
      T.StructField("thickness_min_rhs", T.StringType(), True),
      T.StructField("thickness_max_rhs", T.StringType(), True),
      T.StructField("disintegration_time_lhs", T.StringType(), True),
      T.StructField("disintegration_time_rhs", T.StringType(), True),
      T.StructField("diameter_min_lhs", T.StringType(), True),
      T.StructField("diameter_max_lhs", T.StringType(), True),
      T.StructField("diameter_min_rhs", T.StringType(), True),
      T.StructField("diameter_max_rhs", T.StringType(), True),
      T.StructField("friability_lhs", T.StringType(), True),
      T.StructField("friability_rhs", T.StringType(), True),
      T.StructField("individual_weight_variation_min_lhs", T.StringType(), True),
      T.StructField("individual_weight_variation_max_lhs", T.StringType(), True),
      T.StructField("individual_weight_variation_min_rhs", T.StringType(), True),
      T.StructField("individual_weight_variation_max_rhs", T.StringType(), True),
      T.StructField("compaction_force", T.StringType(), True),
      T.StructField("machine_speed", T.StringType(), True),
      T.StructField("min_thickness_min_lhs", T.StringType(), True),
      T.StructField("max_thickness_min_lhs", T.StringType(), True),
      T.StructField("mean_thickness_min_lhs", T.StringType(), True),
      T.StructField("std_thickness_min_lhs", T.StringType(), True),
      T.StructField("min_thickness_max_lhs", T.StringType(), True),
      T.StructField("max_thickness_max_lhs", T.StringType(), True),
      T.StructField("mean_thickness_max_lhs", T.StringType(), True),
      T.StructField("std_thickness_max_lhs", T.StringType(), True),
      T.StructField("min_thickness_min_rhs", T.StringType(), True),
      T.StructField("max_thickness_min_rhs", T.StringType(), True),
      T.StructField("mean_thickness_min_rhs", T.StringType(), True),
      T.StructField("std_thickness_min_rhs", T.StringType(), True),
      T.StructField("min_thickness_max_rhs", T.StringType(), True),
      T.StructField("max_thickness_max_rhs", T.StringType(), True),
      T.StructField("mean_thickness_max_rhs", T.StringType(), True),
      T.StructField("std_thickness_max_rhs", T.StringType(), True),
      T.StructField("min_hardness_min_lhs", T.StringType(), True),
      T.StructField("max_hardness_min_lhs", T.StringType(), True),
      T.StructField("mean_hardness_min_lhs", T.StringType(), True),
      T.StructField("std_hardness_min_lhs", T.StringType(), True),
      T.StructField("min_hardness_max_lhs", T.StringType(), True),
      T.StructField("max_hardness_max_lhs", T.StringType(), True),
      T.StructField("mean_hardness_max_lhs", T.StringType(), True),
      T.StructField("std_hardness_max_lhs", T.StringType(), True),
      T.StructField("min_hardness_min_rhs", T.StringType(), True),
      T.StructField("max_hardness_min_rhs", T.StringType(), True),
      T.StructField("mean_hardness_min_rhs", T.StringType(), True),
      T.StructField("std_hardness_min_rhs", T.StringType(), True),
      T.StructField("min_hardness_max_rhs", T.StringType(), True),
      T.StructField("max_hardness_max_rhs", T.StringType(), True),
      T.StructField("mean_hardness_max_rhs", T.StringType(), True),
      T.StructField("std_hardness_max_rhs", T.StringType(), True),
      T.StructField("main_compression_force_lhs", T.StringType(), True),
      T.StructField("main_compression_force_rhs", T.StringType(), True),
      T.StructField("pre_compression_force_lhs", T.StringType(), True),
      T.StructField("pre_compression_force_rhs", T.StringType(), True),
      T.StructField("initial_friability_lhs", T.StringType(), True),
      T.StructField("inprocess_friability_lhs", T.StringType(), True),
      T.StructField("initial_friability_rhs", T.StringType(), True),
      T.StructField("inprocess_friability_rhs", T.StringType(), True),
      T.StructField("initial_disintegration_time_lhs", T.StringType(), True),
      T.StructField("inprocess_disintegration_time_lhs", T.StringType(), True),
      T.StructField("initial_disintegration_time_rhs", T.StringType(), True),
      T.StructField("inprocess_disintegration_time_rhs", T.StringType(), True),
      T.StructField("average_group_weight_lhs", T.StringType(), True),
      T.StructField("average_group_weight_rhs", T.StringType(), True),
      T.StructField("compressed_tablets_net_weight", T.StringType(), True),
      T.StructField("average_individual_average_weight", T.StringType(), True),
      T.StructField("compression_yield", T.StringType(), True)
      
    ]
  )

processed_bmr_granulation_schema = T.StructType(
    [
    T.StructField('BATCH_ID', T.StringType(), True),
    T.StructField('MATERIAL_CODE', T.IntegerType(), True),
    T.StructField('PRODUCT_NAME', T.StringType(), True),
    T.StructField('CURRENT_DATETIME', T.TimestampType(), True),
    T.StructField('DATETIME', T.TimestampType(), True),
    T.StructField("LOT", T.StringType(), True),
    T.StructField("PART", T.StringType(), True),
    T.StructField("WEIGHT", T.DoubleType(), True),
    T.StructField("STAGE", T.StringType(), True),
    T.StructField("SUB_STAGE", T.StringType(), True),
    T.StructField("ATOMIZATION_PRESSURE_SET", T.DoubleType(), True),
    T.StructField("ATOMIZATION_PRESSURE_ACT", T.DoubleType(), True),
    T.StructField("BED_TEMPARATURE_SET", T.DoubleType(), True),
    T.StructField("BED_TEMPARATURE_ACT", T.DoubleType(), True),
    T.StructField("EXHAUST_TEMPARATURE_SET", T.DoubleType(), True),
    T.StructField("EXHAUST_TEMPARATURE_ACT", T.DoubleType(), True),
    T.StructField("INLET_TEMPARATURE_SET", T.DoubleType(), True),
    T.StructField("INLET_TEMPARATURE_ACT", T.DoubleType(), True),
    T.StructField("PRODUCT_TEMPARATURE_SET", T.DoubleType(), True),
    T.StructField("PRODUCT_TEMPARATURE_ACT", T.DoubleType(), True),
    T.StructField("INLET_AIR_FLOW_SET", T.DoubleType(), True),
    T.StructField("INLET_AIR_FLOW_ACT", T.DoubleType(), True),
    T.StructField("PAN_SPEED_SET", T.DoubleType(), True),
    T.StructField("PAN_SPEED_ACT", T.DoubleType(), True),
    T.StructField("SPRAY_RATE", T.DoubleType(), True),
    T.StructField("NET_WEIGHT", T.DoubleType(), True),
    T.StructField("GRANULATION_YIELD", T.DoubleType(), True),
    T.StructField("FINAL_DURATION_IN_MINS", T.DoubleType(), True)
    ]
  )

processed_bmr_compression_schema = T.StructType(
  [
    T.StructField('BATCH_ID', T.StringType(), True),
    T.StructField('MATERIAL_CODE', T.IntegerType(), True),
    T.StructField('PRODUCT_NAME', T.StringType(), True),
    T.StructField('CURRENT_DATETIME', T.TimestampType(), True),
    T.StructField('GRANULATION_LOD_PART_A', T.DoubleType(),True),
    T.StructField('GRANULATION_LOD_PART_B', T.DoubleType(),True),
    T.StructField('GRANULATION_BD_PART_A', T.DoubleType(),True),
    T.StructField('GRANULATION_BD_PART_B', T.DoubleType(),True),
    T.StructField('GRANULATION_TD_PART_A', T.DoubleType(),True),
    T.StructField('GRANULATION_TD_PART_B', T.DoubleType(),True),
    T.StructField('GRANULATION_FINES_PART_A', T.DoubleType(),True),
    T.StructField('GRANULATION_FINES_PART_B', T.DoubleType(),True),
    T.StructField('GROUP_WEIGHT_LHS', T.DoubleType(),True),
    T.StructField('GROUP_WEIGHT_RHS', T.DoubleType(),True),
    T.StructField('HARDNESS_MIN_LHS', T.DoubleType(),True),
    T.StructField('HARDNESS_MAX_LHS', T.DoubleType(),True),
    T.StructField('HARDNESS_MIN_RHS', T.DoubleType(),True),
    T.StructField('HARDNESS_MAX_RHS', T.DoubleType(),True),
    T.StructField('THICKNESS_MIN_LHS', T.DoubleType(),True),
    T.StructField('THICKNESS_MAX_LHS', T.DoubleType(),True),
    T.StructField('THICKNESS_MIN_RHS', T.DoubleType(),True),
    T.StructField('THICKNESS_MAX_RHS', T.DoubleType(),True),
    T.StructField('DISINTEGRATION_TIME_LHS', T.DoubleType(),True),
    T.StructField('DISINTEGRATION_TIME_RHS', T.DoubleType(),True),
    T.StructField('DIAMETER_MIN_LHS', T.DoubleType(),True),
    T.StructField('DIAMETER_MAX_LHS', T.DoubleType(),True),
    T.StructField('DIAMETER_MIN_RHS', T.DoubleType(),True),
    T.StructField('DIAMETER_MAX_RHS', T.DoubleType(),True),
    T.StructField('FRIABILITY_LHS', T.DoubleType(),True),
    T.StructField('FRIABILITY_RHS', T.DoubleType(),True),
    T.StructField('INDIVIDUAL_WEIGHT_VARIATION_MIN_LHS', T.DoubleType(),True),
    T.StructField('INDIVIDUAL_WEIGHT_VARIATION_MAX_LHS', T.DoubleType(),True),
    T.StructField('INDIVIDUAL_WEIGHT_VARIATION_MIN_RHS', T.DoubleType(),True),
    T.StructField('INDIVIDUAL_WEIGHT_VARIATION_MAX_RHS', T.DoubleType(),True),
    T.StructField('COMPACTION_FORCE', T.DoubleType(),True),
    T.StructField('MACHINE_SPEED', T.DoubleType(),True),
    T.StructField('MIN_THICKNESS_MIN_LHS', T.DoubleType(),True),
    T.StructField('MAX_THICKNESS_MIN_LHS', T.DoubleType(),True),
    T.StructField('MEAN_THICKNESS_MIN_LHS', T.DoubleType(),True),
    T.StructField('STD_THICKNESS_MIN_LHS', T.DoubleType(),True),
    T.StructField('MIN_THICKNESS_MAX_LHS', T.DoubleType(),True),
    T.StructField('MAX_THICKNESS_MAX_LHS', T.DoubleType(),True),
    T.StructField('MEAN_THICKNESS_MAX_LHS', T.DoubleType(),True),
    T.StructField('STD_THICKNESS_MAX_LHS', T.DoubleType(),True),
    T.StructField('MIN_THICKNESS_MIN_RHS', T.DoubleType(),True),
    T.StructField('MAX_THICKNESS_MIN_RHS', T.DoubleType(),True),
    T.StructField('MEAN_THICKNESS_MIN_RHS', T.DoubleType(),True),
    T.StructField('STD_THICKNESS_MIN_RHS', T.DoubleType(),True),
    T.StructField('MIN_THICKNESS_MAX_RHS', T.DoubleType(),True),
    T.StructField('MAX_THICKNESS_MAX_RHS', T.DoubleType(),True),
    T.StructField('MEAN_THICKNESS_MAX_RHS', T.DoubleType(),True),
    T.StructField('STD_THICKNESS_MAX_RHS', T.DoubleType(),True),
    T.StructField('MIN_HARDNESS_MIN_LHS', T.DoubleType(),True),
    T.StructField('MAX_HARDNESS_MIN_LHS', T.DoubleType(),True),
    T.StructField('MEAN_HARDNESS_MIN_LHS', T.DoubleType(),True),
    T.StructField('STD_HARDNESS_MIN_LHS', T.DoubleType(),True),
    T.StructField('MIN_HARDNESS_MAX_LHS', T.DoubleType(),True),
    T.StructField('MAX_HARDNESS_MAX_LHS', T.DoubleType(),True),
    T.StructField('MEAN_HARDNESS_MAX_LHS', T.DoubleType(),True),
    T.StructField('STD_HARDNESS_MAX_LHS', T.DoubleType(),True),
    T.StructField('MIN_HARDNESS_MIN_RHS', T.DoubleType(),True),
    T.StructField('MAX_HARDNESS_MIN_RHS', T.DoubleType(),True),
    T.StructField('MEAN_HARDNESS_MIN_RHS', T.DoubleType(),True),
    T.StructField('STD_HARDNESS_MIN_RHS', T.DoubleType(),True),
    T.StructField('MIN_HARDNESS_MAX_RHS', T.DoubleType(),True),
    T.StructField('MAX_HARDNESS_MAX_RHS', T.DoubleType(),True),
    T.StructField('MEAN_HARDNESS_MAX_RHS', T.DoubleType(),True),
    T.StructField('STD_HARDNESS_MAX_RHS', T.DoubleType(),True),
    T.StructField('MAIN_COMPRESSION_FORCE_LHS', T.DoubleType(),True),
    T.StructField('MAIN_COMPRESSION_FORCE_RHS', T.DoubleType(),True),
    T.StructField('PRE_COMPRESSION_FORCE_LHS', T.DoubleType(),True),
    T.StructField('PRE_COMPRESSION_FORCE_RHS', T.DoubleType(),True),
    T.StructField('INITIAL_FRIABILITY_LHS', T.DoubleType(),True),
    T.StructField('INPROCESS_FRIABILITY_LHS', T.DoubleType(),True),
    T.StructField('INITIAL_FRIABILITY_RHS', T.DoubleType(),True),
    T.StructField('INPROCESS_FRIABILITY_RHS', T.DoubleType(),True),
    T.StructField('INITIAL_DISINTEGRATION_TIME_LHS', T.DoubleType(),True),
    T.StructField('INPROCESS_DISINTEGRATION_TIME_LHS', T.DoubleType(),True),
    T.StructField('INITIAL_DISINTEGRATION_TIME_RHS', T.DoubleType(),True),
    T.StructField('INPROCESS_DISINTEGRATION_TIME_RHS', T.DoubleType(),True),
    T.StructField('AVERAGE_GROUP_WEIGHT_LHS', T.DoubleType(),True),
    T.StructField('AVERAGE_GROUP_WEIGHT_RHS', T.DoubleType(),True),
    T.StructField('COMPRESSED_TABLETS_NET_WEIGHT', T.DoubleType(),True),
    T.StructField('AVERAGE_INDIVIDUAL_AVERAGE_WEIGHT', T.DoubleType(),True),
    T.StructField('COMPRESSION_YIELD', T.DoubleType(),True)

  ]
  )

compression_schemas = T.StructType(
  [
    T.StructField('BATCH_ID', T.StringType(), True ),
    T.StructField('PRODUCTCODE', T.IntegerType(),True),
    T.StructField('MACHINE_CODE', T.StringType(), True),
    T.StructField('LINE', T.IntegerType(), True),
    T.StructField('UNIT', T.StringType(),True),
    T.StructField('SITE', T.StringType(),True),
    T.StructField('BATCH_SIZE', T.IntegerType(), True),
    T.StructField('CURRENT_DATETIME', T.TimestampType(),True),
    T.StructField('PRODUCTNAME', T.StringType(),True),
    T.StructField('DATASOURCE', T.StringType(),True), 
    T.StructField('PREPROCESSED_LAYER_DATE', T.TimestampType(),True),
    T.StructField('BATCH_START_DATE', T.TimestampType(),True),
    T.StructField('MAIN_COMPR_FORCE_MV_KN_STATION_1', T.DoubleType(), True),  
    T.StructField('MAIN_COMPR_FORCE_MV_KN_STATION_2', T.DoubleType(), True),
    T.StructField('PRE_COMPR_FORCE_MV_KN_STATION_1', T.DoubleType(), True),
    T.StructField('PRE_COMPR_FORCE_MV_KN_STATION_2', T.DoubleType(), True),
    T.StructField('TABL_CYL_HT_MAIN_CO_MM_STATION_1', T.DoubleType(), True),
    T.StructField('TABL_CYL_HT_MAIN_CO_MM_STATION_2', T.DoubleType(), True),
    T.StructField('TABL_CYL_HT_PRE_CO_MM_STATION_1', T.DoubleType(), True),
    T.StructField('TABL_CYL_HT_PRE_CO_MM_STATION_2', T.DoubleType(), True),
    T.StructField('TABL_FILLING_DEPTH_MM_STATION_1', T.DoubleType(), True),
    T.StructField('TABL_FILLING_DEPTH_MM_STATION_2', T.DoubleType(), True),
    T.StructField('FILLING_DEVICE_SPEED_STATION_1', T.DoubleType(), True),
    T.StructField('FILL_O_MATIC_SPEED_RPM_STATION_1', T.DoubleType(), True),  
    T.StructField('TABLETS_PER_HOUR_STATION_1', T.DoubleType(), True),
    T.StructField('FILLING_DEVICE_SPEED_STATION_2', T.DoubleType(), True),
    T.StructField('FILL_O_MATIC_SPEED_RPM_STATION_2', T.DoubleType(), True),  
    T.StructField('TABLETS_PER_HOUR_STATION_2', T.DoubleType(), True),
    T.StructField('FINES_STATION_1', T.DoubleType(), True),  
    T.StructField('BULK_DENSITY_STATION_1', T.DoubleType(), True),
    T.StructField('LOSS_ON_DRYING_STATION_1', T.DoubleType(), True),
    T.StructField('TAPPED_DENSITY_STATION_1', T.DoubleType(), True),
    T.StructField('FINES_STATION_2', T.DoubleType(), True),
    T.StructField('BULK_DENSITY_STATION_2', T.DoubleType(), True),
    T.StructField('LOSS_ON_DRYING_STATION_2', T.DoubleType(), True),
    T.StructField('TAPPED_DENSITY_STATION_2', T.DoubleType(), True),
    T.StructField('COMPRESSION_YIELD_PERCENT', T.DoubleType(), True),
    T.StructField('FINAL_DURATIONS_IN_MINS', T.DoubleType(), True)  
  ]
)

coating_schema = T.StructType(
    [
      T.StructField('BATCH_ID', T.StringType(), True),
      T.StructField('PRODUCTCODE', T.IntegerType(), True),
      T.StructField('MACHINECODE', T.StringType(), True),
      T.StructField('LINE', T.StringType(), True),
      T.StructField('UNIT', T.StringType(), True),
      T.StructField('SITE', T.StringType(), True),
      T.StructField('BATCH_SIZE', T.DoubleType(), True),
      T.StructField('PRODUCTNAME', T.StringType(), True),
      T.StructField('DATASOURCE', T.StringType(), True),
      T.StructField('DATETIME', T.TimestampType(), True),
      T.StructField('PREPROCESSED_LAYER_DATE', T.TimestampType(), True),
      T.StructField('SUBSTAGE', T.StringType(), True),
      T.StructField('PAN_SPEED_SET', T.DoubleType(), True),
      T.StructField('PAN_SPEED_ACT', T.DoubleType(), True),
      T.StructField('INLET_TEMP_ACT', T.DoubleType(), True),
      T.StructField('INLET_TEMP_SET', T.DoubleType(), True),
      T.StructField('SPRAY_RATE_ACT', T.DoubleType(), True),
      T.StructField('SPRAY_PUMP_RPM_ACT', T.DoubleType(), True),
      T.StructField('AIR_FLOW_CFM_ACT', T.DoubleType(), True),
      T.StructField('AIR_FLOW_INLET_M_S_ACT', T.DoubleType(), True),
      T.StructField('EXHAUST_TEMP_ACT', T.DoubleType(), True),
      T.StructField('EXHAUST_TEMP_SET', T.DoubleType(), True),
      T.StructField('EXHAUST_FLAP_SET', T.DoubleType(), True),
      T.StructField('EXHAUST_FLAP_ACT', T.DoubleType(), True),
      T.StructField('PRODUCT_TEMP_ACT', T.DoubleType(), True),
      T.StructField('PRODUCT_TEMP_SET', T.DoubleType(), True),
      T.StructField('DRIVE_SPEED_ACT', T.DoubleType(), True),
      T.StructField('DRIVE_SPEED_SET', T.DoubleType(), True),
      T.StructField('BLOWER_DRIVE_ACT', T.DoubleType(), True),
      T.StructField('BLOWER_DRIVE_SET', T.DoubleType(), True),
      T.StructField('ATOMIZATION_AIR_ACT', T.DoubleType(), True),
      T.StructField('ATOMIZATION_AIR_SET', T.DoubleType(), True),
      T.StructField('AIR_FLOW_CFM_SET', T.DoubleType(), True),
      T.StructField('DRUM_SPEED_RPM_SET', T.DoubleType(), True),
      T.StructField('DRUM_SPEED_RPM_ACT', T.DoubleType(), True),
      T.StructField('PD_DRUM_POINT_MMWC_SET', T.DoubleType(), True),
      T.StructField('PD_DRUM_POINT_MMWC_ACT', T.DoubleType(), True),
      T.StructField('DEW_POINT_C_ACT', T.DoubleType(), True),
      T.StructField('FINAL_DURATIONS_IN_MINS', T.DoubleType(), True),
      T.StructField('COATING_YIELD_PERCENT', T.DoubleType(), True)
    ]
  )


sql_logs = T.StructType(
    [
    T.StructField('MACHINECODE', T.StringType(), True),
    T.StructField('PRODUCTCODE', T.StringType(), True),
    T.StructField('LINE', T.StringType(), True),
    T.StructField('UNIT', T.TimestampType(), True),
    T.StructField('SITE', T.StringType(), True),
    T.StructField('BATCH_SIZE', T.TimestampType(), True),
    T.StructField('PRODUCTNAME', T.StringType(), True),
    T.StructField('MIN_BATCHID', T.StringType(), True),
    T.StructField('MAX_BATCHID', T.StringType(), True),
    T.StructField('DATETIME', T.TimestampType(), True),
    T.StructField('USECASE', T.StringType(), True),
    T.StructField('STAGE', T.TimestampType(), True),
    T.StructField('SUBSTAGE', T.StringType(), True),
    T.StructField('DS_NAME', T.StringType(), True),
    T.StructField('DE_NAME', T.StringType(), True),
    T.StructField('ACCURACY_TRAIN', T.TimestampType(), True),
    T.StructField('ACCURACY_TEST', T.StringType(), True),
    T.StructField('RMSE_TRAIN', T.TimestampType(), True),
    T.StructField('RMSE_TEST', T.TimestampType(), True),
    T.StructField('REFINED_COUNT', T.StringType(), True),
    T.StructField('REFRESHED_DATE', T.StringType(), True),
    T.StructField('NO_BATCHES', T.StringType(), True),
    T.StructField('OUTPUT_DIR', T.TimestampType(), True),
    T.StructField('TIME_TAKEN', T.StringType(), True),
    T.StructField('MULTIOUTPUT', T.TimestampType(), True),
    ]
)       


granulation_schema = T.StructType(
  [
    T.StructField('BATCH_ID', T.StringType(),True),
    T.StructField('PRODUCTCODE', T.IntegerType(),True),
    T.StructField('MACHINECODE', T.StringType(), True),
    T.StructField('LINE', T.StringType(), True),
    T.StructField('UNIT', T.StringType(),True),
    T.StructField('SITE', T.StringType(),True),
    T.StructField('BATCH_SIZE', T.FloatType(), True),
    T.StructField('PRODUCTNAME', T.StringType(),True),
    T.StructField('PRODUCT_PART',T.StringType(),True),
    T.StructField('DATASOURCE', T.StringType(),True), 
    T.StructField('BATCH_START_DATE', T.TimestampType(),True),
    T.StructField('PREPROCESSED_LAYER_DATE', T.TimestampType(),True),
    T.StructField('CURRENT_DATETIME', T.TimestampType(),True),
    T.StructField('SUBSTAGE', T.StringType(),True),
    T.StructField('EXHAUST_FLAP_SET', T.DoubleType(), True),  
    T.StructField('EXHAUST_FLAP_ACT', T.DoubleType(), True),
    T.StructField('INLET_TEMP_SET', T.DoubleType(), True),
    T.StructField('INLET_TEMP_ACT', T.DoubleType(), True),
    T.StructField('PRODUCT_TEMP_SET', T.DoubleType(), True),
    T.StructField('PRODUCT_TEMP_ACT', T.DoubleType(), True),
    T.StructField('EXHAUST_TEMP_SET', T.DoubleType(), True),
    T.StructField('EXHAUST_TEMP_ACT', T.DoubleType(), True),
    T.StructField('AIR_FLOW_INLET_M_S_ACT', T.DoubleType(), True),
    T.StructField('AIR_FLOW_CFM_ACT', T.DoubleType(), True),
    T.StructField('ATOMIZATION_AIR_SET', T.DoubleType(), True),
    T.StructField('ATOMIZATION_AIR_ACT', T.DoubleType(), True),  
    T.StructField('SPRAY_RATE_ACT', T.DoubleType(), True),
    T.StructField('DRIVE_SPEED_ACT', T.DoubleType(), True),
    T.StructField('DRIVE_SPEED_SET', T.DoubleType(), True),  
    T.StructField('PAN_SPEED_ACT', T.DoubleType(), True),
    T.StructField('PAN_SPEED_SET', T.DoubleType(), True),  
    T.StructField('SPRAY_PUMP_RPM_ACT', T.DoubleType(), True),
    T.StructField('BLOWER_DRIVE_ACT', T.DoubleType(), True),
    T.StructField('BLOWER_DRIVE_SET', T.DoubleType(), True),
    T.StructField('GRANULATION_YIELD_PERCENT', T.DoubleType(), True),
    T.StructField('FINAL_DURATIONS_IN_MINS', T.DoubleType(), True),
    T.StructField('DATETIME', T.TimestampType(), True)  
  ]
)

logging_schemas = T.StructType(
  [
    T.StructField('TRANSACTION_ID', T.StringType(),True),
    T.StructField('LOG_FILE_NAME', T.StringType(),True),
    T.StructField('DATETIME', T.TimestampType(), True),
    T.StructField('SITE', T.StringType(), True),
    T.StructField('UNIT', T.StringType(),True),
    T.StructField('PRODUCTCODE', T.StringType(),True),
    T.StructField('PRODUCTNAME',T.StringType(),True),
    T.StructField('LAYER', T.StringType(),True), 
    T.StructField('SUBLAYER', T.StringType(),True),
    T.StructField('STATUS', T.StringType(),True),
    T.StructField('FAILURE_REASON', T.StringType(),True),
    T.StructField('FAILURE_DESCRIPTION', T.StringType(),True),
    T.StructField('NO_OF_BATCHES', T.StringType(),True),
    T.StructField('COMMENTS', T.StringType(), True)
  ]
)
  
        
        
        
        
        
        
        


