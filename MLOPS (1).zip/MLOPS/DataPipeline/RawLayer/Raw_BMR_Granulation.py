import pandas as pd 
import numpy as np
import glob
import os
import re
from DataPipeline import Schemas
from datetime import datetime
from DataPipeline.SQLConnection import SQLConnection 

import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark.sql.functions import col
from pyspark.sql.types import *
from pyspark.sql import SparkSession

from DataPipeline.TransactionLog import TransactionLog
import random
import string
import logging
import traceback

class Raw_BMR_Granulation:
    def __init__(self,source_folder_path,destination_folder_path) -> None:
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.source_folder_path = source_folder_path
        self.destination_folder_path = destination_folder_path
        self.transaction_log = TransactionLog()

    def fetch_BMR_Granilation_File(self):
        logging.info("Inside Fetch_BMR_Granilation")
        try:
            files = os.listdir(self.source_folder_path)
            final_df = pd.DataFrame()
            for file in files:
                try:
                    df = self.extract_granulation_data_from_bmr(file)
                    final_df = pd.concat([final_df, df], axis=0).reset_index(drop=True)
                except Exception as e:
                    print(e)
                    continue

            print(final_df.shape)
            sparkdf,out_df = self.intermediate_processing_bmr_granulation(final_df)
            logging.info("Finished intermediate processing")
            spark_log_df = self.transaction_log.insert_data( "RAW", "BMR GRANULATION" , out_df,"MATERIAL_CODE" , "PRODUCT_NAME" ,"BATCH_ID")

            return sparkdf,spark_log_df

        except Exception as e:
            logging.info("Error in Processing RAW BMR Granulations")
            spark_log = self.transaction_log.failure_into_sql( "RAW", "BMR GRANULATION" , "Error In Processing BMR Granulation" , "Error")
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()   




    def extract_granulation_data_from_bmr(self,file):
        print(file)

        source_file_path = os.path.join(self.source_folder_path, file)
        destination_file_path = os.path.join(self.destination_folder_path,file)

        final_cols = ['batch_no', 'material_code', 'product_name', 'lot', 'part', 'weight', 'datetime',
            'stage', 'sub_stage', 'atomization_pressure_set',
            'atomization_pressure_act', 'bed_temparature_set',
            'bed_temparature_act', 'exhaust_temparature_set',
            'exhaust_temparature_act', 'inlet_temparature_set',
            'inlet_temparature_act', 'pan_speed_set', 'pan_speed_act', 'spray_rate', 'net_weight', 'granulation_yield']
        final_df = pd.DataFrame([1], columns = ['id'])

        #batch_info_extraction
        df = pd.read_excel(source_file_path, sheet_name = "Batch Info").dropna(axis=0,how="all")
        df['id'] = 1
        final_df = final_df.merge(df, on = 'id',how="left")

        #pre_granulation_sheet
        df = pd.read_excel(source_file_path, sheet_name = "Pre Granulation").dropna(axis=0,how="all")
        if df.empty:
            df = pd.DataFrame([["A","A","NA"]], columns = ['part','lot','weight'])
        df['id'] = 1
        final_df = final_df.merge(df, on = 'id',how="left")

        #granulation_inprocess_sheet
        df = pd.read_excel(source_file_path, sheet_name = "Granulation Inprocess").dropna(axis=0,how="all")
        if not df.empty:
            df['part'] = df['part'].fillna(method = 'ffill')
            df['lot'] = df['lot'].fillna(method = 'ffill')
            df['stage'] = df['stage'].fillna(method = 'ffill')
            df['sub_stage'] = df['sub_stage'].fillna(method = 'ffill')

            for col in df.columns:
                if col not in ['part', 'lot', 'stage', 'sub_stage', 'date', 'time']:
                    df[col] = pd.to_numeric(df[col], errors = "coerce")

            df['datetime'] = pd.to_datetime(df['date']+' '+df['time'].astype(str), format = "%d.%m.%Y %H:%M:%S", errors="coerce")
            df.drop(columns = ['date', 'time'], inplace=True)
            
            final_df = final_df.merge(df, on = ['part','lot'], how="left")

        #post_granulation_sheet
        df = pd.read_excel(source_file_path, sheet_name = 'Post Granulation').dropna(axis=0,how="all")
        if not df.empty:
            final_df = final_df.merge(df, on = ['part','lot'], how="left")
        else:
            final_df['net_weight'] = np.nan
            
        #Yield
        df = pd.read_excel(source_file_path, sheet_name = 'Yield').dropna(axis=0,how="all")
        if not df.empty:
            df['id'] = 1
            final_df = final_df.merge(df, on='id',how='left').drop(columns = ['id'])
        else:
            final_df['graulation_yield'] = np.nan
            final_df.drop(columns = ['id'], inplace=True)

        # for col in final_cols:
        #   if col not in final_df.columns:
        #     final_df[col] = np.nan
        
        # final_df = final_df[final_cols]
        
        return final_df
    
    def intermediate_processing_bmr_granulation(self,df):
        out_df = df.copy()
        out_df['parameter_value'] = ''
        for index,row in df.iterrows():
            x = "{"+(",").join([f'"{col}"'+":"+f'"{str(row[col])}"' for col in df.columns if col not in ['batch_no', 'material_code','product_name', 'datetime']]) +"}"
            out_df['parameter_value'][index] = x

        out_df.drop(columns = [col for col in out_df.columns if col not in ['batch_no', 'material_code','product_name', 'datetime','parameter_value']], inplace=True)
        
        out_df['current_datetime'] = datetime.now()
        # out_df = out_df[out_df[out_df.columns.tolist()[:out_df.columns.tolist().index('datetime')]+['current_datetime']+out_df.columns.tolist()[out_df.columns.tolist().index('datetime'):-1]]]
        out_df.columns = [col.upper() for col in out_df.columns]
        out_df = out_df.rename(columns = {'BATCH_NO' : 'BATCH_ID'})
        seq_list = ['BATCH_ID','MATERIAL_CODE','PRODUCT_NAME','CURRENT_DATETIME','PARAMETER_VALUE','DATETIME']
        out_df = out_df[seq_list]
        sparkdf = self.spark.createDataFrame(out_df, schema = Schemas.raw_bmr_granulation)
        return sparkdf,out_df
    

    # push to raw table is pending
    def push_to_raw_granulation_bmr(self,sparkdf,spark_log_df):
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf,"dbo.MLOPS_PIPELINE_RAW_GRANULATION_BMR")
        print(" !!!!!!!  DATA IS SUCCESSFULLY PUSHED IN RAW BMR GRANULATION  !!!!!!!")
        self.transaction_log.push_DataFrame_to_sql(spark_log_df)
        print("!!!!!!!!! DATA IS SUCCESSFULLY PUSHed IN LOGGING FOR RAW BMR GRANULATION")


    


    
