import pandas as pd
import pdfplumber
import os
import re
import glob
import numpy as np

from DataPipeline import Schemas
from datetime import datetime
from DataPipeline.SQLConnection import SQLConnection
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark.sql.functions import col
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from DataPipeline.TransactionLog import TransactionLog

import logging
import traceback
from DataPipeline.utils import *
from DataPipeline.TableColumn import scada_manual


class Scada:
    def __init__(self, source_folder_path, destination_folder_path) -> None:
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.source_folder_path = source_folder_path
        self.destination_folder_path = destination_folder_path
        self.transaction_log = TransactionLog()

    def fetch_Scada_PDF_File(self):
        try:
            files = glob.glob(os.path.join(self.source_folder_path, "**"))

            final_df = pd.DataFrame()
            for file in files:
                df = self.extract_scada_coating_report_from_pdf_goa7b(file)
                final_df = pd.concat([final_df, df], axis=0).reset_index(drop=True)

            spark_df, df = self.intermediate_processing(final_df)
            spark_log_df = self.transaction_log.insert_data(
                "RAW", "SCADA MANUAL", df, "PRODUCTCODE", "PRODUCTNAME", "BATCH_ID"
            )
            return spark_df, spark_log_df

        except Exception as e:
            logging.info("Error in Processing RAW SCADA Manual Data")
            spark_log = self.transaction_log.failure_into_sql(
                "RAW", "SCADA MANUAL", "Error In Processing SCADA MANUAL", "Error"
            )
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()

    def extract_scada_coating_report_from_pdf_goa7b(self, file):
        print(file)
        pdf = pdfplumber.open(file)
        pages = pdf.pages

        info = pages[0].extract_text()
        info_lines = info.split("\n")

        batch = info_lines[7].split(":")[-1].strip()
        lot = info_lines[8].split(":")[-1].strip()
        product = info_lines[13].split(":")[-1].strip()
        equipment = file.split("/")[-2]

        final_columns = [
            "batch_no",
            "product_desc",
            "equipment",
            "lot_no",
            "datetime",
            "inlet_air_flow_set_point_cfm",
            "inlet_air_flow_actual_value_cfm",
            "inlet_air_temp_set_point_°C",
            "inlet_air_temp_actual_value_°C",
            "exhaust_air_temp_set_point_°C",
            "exhaust_air_temp_actual_value_°C",
            "pd_drum_set_point_mmWC",
            "pd_drum_actual_value_mmWC",
            "drum_speed_set_point_rpm",
            "drum_speed_actual_value_rpm",
            "atomising_air_pressure_set_point_kg/cm2",
            "atomising_air_pressure_actual_value_kg/cm2",
            "inlet_air_dewpoint_temp_°C",
            "spray_pump_speed_rpm",
            "spray_rate_film_g/min",
        ]
        final_df = pd.DataFrame(columns=final_columns)

        step = ""
        limit_dict = []
        for page in pages:
            txt = page.extract_text()
            lines = txt.split("\n")[:-1]
            if "Process Variables" in lines[1]:
                for i in range(len(lines)):
                    if lines[i].startswith("Step Counter"):
                        step1 = lines[i].split("Step Name:")[-1].strip()
                        if step1 == "Film Coating":
                            limit_dict.append((page, i))

        limit_dict = self.chunked_list(limit_dict, 2)

        df_list = []
        for comb in limit_dict:
            start = comb[0]
            end = comb[1]

            limit_pages = pages[pages.index(start[0]) : pages.index(end[0]) + 1]

            if start[0] != end[0]:
                for i in range(len(limit_pages)):
                    page = limit_pages[i]
                    txt = page.extract_text()
                    lines = txt.split("\n")[:-1]

                    if page == start[0]:
                        lines = lines[start[1] + 1 :]

                    elif page == end[0]:
                        lines = lines[4 : end[1]]

                    else:
                        lines = lines[4:]

                    for line in lines:
                        line_list = line.split(" ")
                        df_list.append(line_list)

            else:
                page = start[0]
                txt = page.extract_text()
                lines = txt.split("\n")[:-1]
                lines = lines[start[1] : end[1]]

                for line in lines:
                    line_list = line.split(" ")
                    df_list.append(line_list)

        df = pd.DataFrame(df_list)
        if not df.empty:
            df[0] = pd.to_datetime(
                df[0] + " " + df[1].astype(str),
                format="%d-%m-%y %H:%M:%S",
                errors="coerce",
            )
            df = df.drop(columns=1)
            df.columns = [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
            df[0] = batch
            df[1] = product
            df[2] = equipment
            df[3] = lot

            df = df[
                [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
            ]

            df.columns = final_columns

        return df

    def chunked_list(self, list1, chunk_size):
        chunked_list = list()

        for i in range(0, len(list1), chunk_size):
            chunked_list.append(list1[i : i + chunk_size])

        return chunked_list

    def intermediate_processing(self, df):
        cols_rename = {
            "batch_no": "BATCH_ID",
            "product_desc": "PRODUCTNAME",
            "equipment": "MACHINECODE",
            "lot_no": "LOTNUMBER",
            "datetime": "DATETIME",
            "inlet_air_flow_set_point_cfm": "AIR_FLOW_CFM_SET",
            "inlet_air_flow_actual_value_cfm": "AIR_FLOW_CFM_ACT",
            "inlet_air_temp_set_point_°C": "INLET_TEMP_SET",
            "inlet_air_temp_actual_value_°C": "INLET_TEMP_ACT",
            "exhaust_air_temp_set_point_°C": "EXHAUST_TEMP_SET",
            "exhaust_air_temp_actual_value_°C": "EXHAUST_TEMP_ACT",
            "pd_drum_set_point_mmWC": "PD_DRUM_POINT_MMWC_SET",
            "pd_drum_actual_value_mmWC": "PD_DRUM_POINT_MMWC_ACT",
            "drum_speed_set_point_rpm": "DRUM_SPEED_RPM_SET",
            "drum_speed_actual_value_rpm": "DRUM_SPEED_RPM_ACT",
            "atomising_air_pressure_set_point_kg/cm2": "ATOMIZATION_AIR_SET",
            "atomising_air_pressure_actual_value_kg/cm2": "ATOMIZATION_AIR_ACT",
            "inlet_air_dewpoint_temp_°C": "DEW_POINT_C_ACT",
            "spray_pump_speed_rpm": "SPRAY_PUMP_RPM_ACT",
            "spray_rate_film_g/min": "SPRAY_RATE_ACT",
        }

        df = df.rename(columns=cols_rename)
        final_cols = [
            "BATCH_ID",
            "MACHINECODE",
            "PRODUCTCODE",
            "PRODUCTNAME",
            "USER_FULL_NAME",
            "STAGE",
            "SUBSTAGE",
            "DATETIME",
            "LOTNUMBER",
            "CURRENT_DATETIME",
            "PAN_SPEED_SET",
            "PAN_SPEED_ACT",
            "INLET_TEMP_ACT",
            "INLET_TEMP_SET",
            "SPRAY_RATE_ACT",
            "SPRAY_PUMP_RPM_ACT",
            "AIR_FLOW_CFM_ACT",
            "AIR_FLOW_INLET_M_S_ACT",
            "EXHAUST_TEMP_ACT",
            "EXHAUST_TEMP_SET",
            "EXHAUST_FLAP_SET",
            "EXHAUST_FLAP_ACT",
            "PRODUCT_TEMP_ACT",
            "PRODUCT_TEMP_SET",
            "DRIVE_SPEED_ACT",
            "DRIVE_SPEED_SET",
            "BLOWER_DRIVE_ACT",
            "BLOWER_DRIVE_SET",
            "ATOMIZATION_AIR_ACT",
            "ATOMIZATION_AIR_SET",
            "AIR_FLOW_CFM_SET",
            "DRUM_SPEED_RPM_SET",
            "DRUM_SPEED_RPM_ACT",
            "PD_DRUM_POINT_MMWC_SET",
            "PD_DRUM_POINT_MMWC_ACT",
            "DEW_POINT_C_ACT",
        ]

        for col in final_cols:
            if col not in df.columns:
                df[col] = np.nan

        df["CURRENT_DATETIME"] = datetime.now()
        df["STAGE"] = "Coating"
        df["SUBSTAGE"] = "Film Coating"

        df = df[final_cols]

        for col in final_cols:
            if col not in [
                "BATCH_ID",
                "MACHINECODE",
                "PRODUCTCODE",
                "PRODUCTNAME",
                "USER_FULL_NAME",
                "STAGE",
                "SUBSTAGE",
                "DATETIME",
                "LOTNUMBER",
                "CURRENT_DATETIME",
            ]:
                df[col] = df[col].apply(
                    lambda x: pd.to_numeric(str(x).replace(",", "."), errors="coerce")
                )

        df = add_ProductCode_From_BatchID(df)
        # sequence columns of df before processing with spark
        df = df[scada_manual]
        sparkdf = self.spark.createDataFrame(df, schema=Schemas.scada_manual_schemas)

        return sparkdf, df

    def push_to_scada_raw(self, sparkdf, spark_log_df):
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf, "dbo.MLOPS_PIPELINE_RAW_SCADA")

        print(
            " !!!!!!!  DATA IS SUCCESSFULLY PUSHED IN RAW SCADA MANUAL LAYER  !!!!!!!"
        )
        self.transaction_log.push_DataFrame_to_sql(spark_log_df)
        print("!!!!!!!!! DATA IS SUCCESSFULLY PUSHED IN LOGGING FOR RAW SCADA MANUAL")
