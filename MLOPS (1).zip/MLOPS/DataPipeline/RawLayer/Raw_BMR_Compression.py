import pandas as pd 
import numpy as np
import glob
import os
import re
import datetime
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark.sql.functions import col
from pyspark.sql.types import *
from DataPipeline import Schemas
from DataPipeline.SQLConnection import SQLConnection 
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark.sql.functions import col
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from DataPipeline.TransactionLog import TransactionLog

import logging
import traceback

class Raw_BMR_Compression:
    def __init__(self,source_folder_path,destination_folder_path) -> None:
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.source_folder_path = source_folder_path
        self.destination_folder_path = destination_folder_path
        self.transaction_log = TransactionLog()

    def fetch_BMR_Compression_File(self):
        try:
            files = glob.glob(os.path.join(self.source_folder_path,"**"))
            files = [file for file in files if (file.strip().upper().endswith(".XLSX")) and ("$" not in file)]
            print(f'no of files: {len(files)}')

            final_df = pd.DataFrame()
            for file in files:
                df = self.extract_compression_data_from_bmr_file(file)
                final_df = pd.concat([final_df,df], axis=0).reset_index(drop=True)

            final_df, out_df = self.intermediate_processing_bmr_compression(final_df)
            spark_log_df = self.transaction_log.insert_data( "RAW", "BMR COMPRESSION" , out_df,"MATERIAL_CODE" , "PRODUCT_NAME" ,"BATCH_ID")
            return final_df,spark_log_df
        
        except Exception as e:
            logging.info("Error in Processing RAW BMR Compression")
            spark_log = self.transaction_log.failure_into_sql( "RAW", "BMR COmpression" , "Error In Processing BMR Compression" , "Error")
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()   


    def extract_compression_data_from_bmr_file(self,file):

        source_file_path = os.path.join(self.source_folder_path, file)
        destination_file_path = os.path.join(self.destination_folder_path,file)

        print(source_file_path)
        final_df = pd.DataFrame([1], columns = ['id'])

        #batch_info_extraction
        df = pd.read_excel(source_file_path, sheet_name = "Batch Info").dropna(axis=0,how="all")
        df['id'] = 1
        final_df = final_df.merge(df, on = 'id',how="left")

        #granulation_params_sheet
        df = pd.read_excel(source_file_path, sheet_name = "granulation_params").dropna(axis=0,how="all")
        if not df.empty:
            df['id'] = 1
            final_df = final_df.merge(df, on = 'id',how="left")

        #compression_initial_checks_sheet
        df = pd.read_excel(source_file_path, sheet_name = "compression_initial_checks").dropna(axis=0,how="all")
        if not df.empty:
            for col in df.columns:
                if 'time' in col:
                    df[col] = df[col].apply(lambda x: self.min_sec_to_min(x))
                df[col] = pd.to_numeric(df[col])
            df['id'] = 1
            final_df = final_df.merge(df, on = 'id',how="left")

        #compression_inprocess_checks1_sheet
        df = pd.read_excel(source_file_path, sheet_name = 'compression_inprocess_checks1').dropna(axis=0,how="all")
        if not df.empty:
            df_agg = df.groupby('side')[[col for col in df.columns if col not in ['date', 'time', 'side','appearance']]].agg(['min','max','mean','std'])
            df_agg.columns = ['_'.join(reversed(col)) for col in df_agg.columns.values]
            df_agg.reset_index(inplace=True)
            df_agg['id'] = 1
            pivot = df_agg.pivot(index = 'id', columns = 'side', values = [col for col in df_agg.columns if col not in ['id','side']])
            pivot.columns = [x.lower() for x in ['_'.join(col) for col in pivot.columns.values]]
            pivot.reset_index(inplace=True)
            final_df = final_df.merge(pivot, on = 'id', how="left")

        #compression_force_monitoring_sheet
        df = pd.read_excel(source_file_path, sheet_name = 'compression_force_monitoring').dropna(axis=0,how="all")
        if not df.empty:
            df['id'] = 1
            pivot = pd.pivot_table(df,index = 'id', columns = 'side', values = [col for col in df.columns if col not in ['id','side','date','time']])
            pivot.columns = [x.lower() for x in ['_'.join(col) for col in pivot.columns.values]]
            pivot.reset_index(inplace=True)
            final_df = final_df.merge(pivot, on = 'id', how="left")

        #compression_inprocess_checks2_sheet
        df = pd.read_excel(source_file_path, sheet_name = 'compression_inprocess_checks2').dropna(axis=0,how="all")
        if not df.empty:
            df['stage'] = np.nan
            stage = ''
            for index,row in df.iterrows():
                if 'initial' in str(row.date).lower():
                    stage = 'initial'
                elif ('in-process' in str(row.date).lower()) or ('inprocess' in str(row.date).lower()):
                    stage = 'inprocess'
                else:
                    df['stage'][index] = stage
            df = df[df['stage'].notna()]
            pivot = pd.pivot_table(df,index='stage', columns='side',values = 'friability', aggfunc = 'mean')
            pivot.columns = ["friability_"+col.lower() for col in pivot.columns]
            pivot['id'] = 1
            pivot.reset_index(inplace=True)
            df_pivot = pivot.pivot(index = 'id', columns = 'stage', values = [col for col in pivot.columns if col not in ['id','stage']])
            df_pivot.columns = ['_'.join(reversed(col)) for col in df_pivot.columns.values]
            df_pivot.reset_index(inplace=True)
            final_df = final_df.merge(df_pivot, on = 'id', how="left")

        #compression_inprocess_checks3_sheet
        df = pd.read_excel(source_file_path, sheet_name = 'compression_inprocess_checks3').dropna(axis=0,how="all")
        if not df.empty:
            df['stage'] = np.nan
            stage = ''
            for index,row in df.iterrows():
                if 'initial' in str(row.date).lower():
                    stage = 'initial'
                elif ('in-process' in str(row.date).lower()) or ('inprocess' in str(row.date).lower()):
                    stage = 'inprocess'
                else:
                    df['stage'][index] = stage
            df = df[df['stage'].notna()]
            df['disintegration_time'] = pd.to_numeric(df['disintegration_time'].apply(lambda x: self.min_sec_to_min(x)), errors="coerce")
            pivot = pd.pivot_table(df,index='stage', columns='side',values = 'disintegration_time', aggfunc = 'mean')
            pivot.columns = ["disintegration_time_"+col.lower() for col in pivot.columns]
            pivot['id'] = 1
            pivot.reset_index(inplace=True)
            df_pivot = pivot.pivot(index = 'id', columns = 'stage', values = [col for col in pivot.columns if col not in ['id','stage']])
            df_pivot.columns = ['_'.join(reversed(col)) for col in df_pivot.columns.values]
            df_pivot.reset_index(inplace=True)
            final_df = final_df.merge(df_pivot, on = 'id', how="left")

        #group_weight_variation_sheet
        df = pd.read_excel(source_file_path, sheet_name = 'group_weight_variation').dropna(axis=0,how="all")
        if not df.empty:
            df['id'] = 1
            pivot = pd.pivot_table(df,index = 'id', columns = 'side', values = 'weight_in_gm', aggfunc = 'mean')
            pivot.columns = ['average_group_weight_'+col.lower() for col in pivot.columns]
            pivot.reset_index(inplace=True)
            final_df = final_df.merge(pivot, on = 'id', how="left")

        #post_compression_parameters_sheet
        df = pd.read_excel(source_file_path, sheet_name = 'post_compression_parameters').dropna(axis=0,how="all")
        if not df.empty:
            df['id'] = 1
            final_df = final_df.merge(df, on='id',how='left').drop(columns = ['id'])
        else:
            final_df['compression_yield'] = np.nan
            final_df.drop(columns = ['id'], inplace=True)

        for col in final_df.columns:
            if col not in ['batch_no','product_name']:
                final_df[col] = pd.to_numeric(final_df[col], errors = "coerce")
        final_df = final_df.dropna(axis=1, how = "all")
        
        return final_df
    

    def intermediate_processing_bmr_compression(self,df):
        out_df = df.copy()
        out_df['parameter_value'] = ''
        for index,row in df.iterrows():

            x = "{"+(",").join([f'"{col}"'+":"+f'"{str(row[col])}"' for col in df.columns if col not in ['batch_no', 'material_code','product_name']]) +"}"
            out_df['parameter_value'][index] = x

        out_df.drop(columns = [col for col in out_df.columns if col not in ['batch_no', 'material_code','product_name', 'parameter_value']], inplace=True)

        out_df['current_datetime'] = datetime.datetime.now()
        out_df = out_df[out_df.columns.tolist()[:out_df.columns.tolist().index('parameter_value')]+['current_datetime']+out_df.columns.tolist()[out_df.columns.tolist().index('parameter_value'):-1]]
        out_df = out_df.rename(columns={'batch_no' : 'batch_id'})
        out_df.columns = [col.upper() for col in out_df.columns]

        print(out_df.columns)

        sparkdf = self.spark.createDataFrame(out_df, schema = Schemas.raw_bmr_compression)

        return sparkdf,out_df
            

    def min_sec_to_min(self,x):
        if "mins" in str(x).lower():
            m = int(x.lower().split("mins")[0].strip())
            if "secs" in str(x).lower():
                s = int(x.lower().split("mins")[-1].strip().split("secs")[0].strip())
            elif "sec" in str(x).lower():
                s = int(x.lower().split("mins")[-1].strip().split("sec")[0].strip())
            else:
                s=0
            m = (m*60+s)
        elif "min" in str(x).lower():
            m = int(x.lower().split("min")[0].strip())
            if "secs" in str(x).lower():
                s = int(x.lower().split("min")[-1].strip().split("secs")[0].strip())
            elif "sec" in str(x).lower():
                s = int(x.lower().split("min")[-1].strip().split("sec")[0].strip())
            else:
                s=0
            m = (m*60+s)
        else:
            return x
        return m/60
    
    def push_to_raw_compression_bmr(self,sparkdf,spark_log_df):
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf,"dbo.MLOPS_PIPELINE_RAW_COMPRESSION_BMR")

        print(" !!!!!!!  DATA IS SUCCESSFULLY PUSHED IN RAW BMR COmpression  !!!!!!!")
        self.transaction_log.push_DataFrame_to_sql(spark_log_df)
        print("!!!!!!!!! DATA IS SUCCESSFULLY PUSHed IN LOGGING FOR RAW BMR COmpression")



    