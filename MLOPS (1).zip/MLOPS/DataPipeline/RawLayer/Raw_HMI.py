import os
import logging
import pyspark
from pyspark.sql import SparkSession
from DataPipeline import TableColumn
from datetime import datetime
from DataPipeline import Schemas
from DataPipeline.SQLConnection import SQLConnection
import pandas as pd
import numpy as np
from tqdm import tqdm
import glob
import re
import os
import pdfplumber
import multiprocessing as mp
import shutil
import traceback
from DataPipeline.utils import *
from DataPipeline.TransactionLog import TransactionLog

import logging
import traceback


class HMI:
    def __init__(
        self,
        source_folder_path,
        destination_folder_path,
        date_line,
        product_line,
        batch_line,
    ) -> None:
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.source_folder_path = source_folder_path
        self.destination_folder_path = destination_folder_path
        self.date_line = date_line
        self.product_line = product_line
        self.batch_line = batch_line
        self.transaction_log = TransactionLog()

    def fetch_HMI_Files(self):
        try:
            final_cols = [
                "timestamp",
                "batch_no",
                "product_desc",
                "equipment_id",
                "parameter_id",
                "parameter_desc",
                "station_1_set_value",
                "station_1_actual_value",
                "station_2_set_value",
                "station_2_actual_value",
            ]
            try:
                logging.info("Reading HMI FIles from Library")
                logging.info(self.source_folder_path)
                hmi_files = os.listdir(self.source_folder_path)
                # hmi_files = [f for f in hmi_files if f.lower().endswith("pdf")]
            except Exception as e:
                logging.info("Error In Fetching the HMI FIles from the directory")
                print(e)
                logging.info(e)
                logging.exception("message")
                traceback.print_exc()

            final_df = pd.DataFrame(columns=final_cols)

            # for file in files:
            #     df = self.extract_HMI_Compression(file)     # Need to be in IF ELSE
            #     final_df = pd.concat([final_df, df], axis=0)

            for index in hmi_files:
                print("------------------------------------------------------------")
                logging.info("Site is :::")
                logging.info(index)
                path = os.path.join(self.source_folder_path, index)
                site = os.listdir(path)
                for machinecode in site:
                    logging.info("machinecode: %s", machinecode)
                    machine_path = os.path.join(path, machinecode)
                    machine = os.listdir(machine_path)
                    print(machinecode)
                    for files in machine:
                        print("Processing FIle No " , machine.index(files)+1 , "of" , len(machine))
                        logging.info("Files: %s", files)
                        file_path = os.path.join(machine_path, files)
                        logging.info(file_path)
                        if machinecode in ["tm018", "t046", "t045"]:
                            if get_batchid_from_file(
                                file_path, machinecode, self.batch_line
                            ):
                                df = self.extract_HMI_Compression(
                                    file_path, machinecode
                                )
                                final_df = pd.concat([final_df, df], axis=0)
                        elif machinecode in ["t235", "t270"]:
                            if get_batchid_from_file(
                                file_path, machinecode, self.batch_line
                            ):
                                df = self.extract_hmi_new_compression_parameter_list(
                                    file_path, machinecode
                                )
                                final_df = pd.concat([final_df, df], axis=0)
                print("------------------------------------------------------------")

            hmi_df = final_df.copy()
            if hmi_df.shape[0] == 0:
                return (None, None)
            print(hmi_df.head())
            print(hmi_df.shape)
            print("------------------------------------------------------------")
            print(hmi_df["parameter_desc"].unique())
            hmi_df = hmi_df[
                hmi_df["parameter_desc"]
                .str.strip()
                .isin(
                    [
                        "Main compr.force MV kN",
                        "Maincompressionforce:meanvalue kN",
                        "Pre compr. force MV kN",
                        "Pre-compressionforce:meanvalue kN",
                        "Tabl. cyl. ht. main co. m",
                        "Cylindricalheightmaincompression mm",
                        "Tabl. cyl. ht. pre co. mm",
                        "Cylindricalheightpre-compression mm",
                        "Tabl. filling depth mm",
                        "Tabletfillingdepth mm",
                        "Fillingdevicespeed rpm",
                        "Fill-o-matic speed rpm",
                        "Tablets/h x1000",
                        "Tabletsperhour x1000",
                    ]
                )
            ]
            print(hmi_df.shape)
            renamed_params = {
                "Main compr.force MV kN": "MAIN_COMPR_FORCE_MV_KN",
                "Maincompressionforce:meanvalue kN": "MAIN_COMPR_FORCE_MV_KN",
                "Pre compr. force MV kN": "PRE_COMPR_FORCE_MV_KN",
                "Pre-compressionforce:meanvalue kN": "PRE_COMPR_FORCE_MV_KN",
                "Tabl. cyl. ht. main co. m": "TABL_CYL_HT_MAIN_CO_MM",
                "Cylindricalheightmaincompression mm": "TABL_CYL_HT_MAIN_CO_MM",
                "Tabl. cyl. ht. pre co. mm": "TABL_CYL_HT_PRE_CO_MM",
                "Cylindricalheightpre-compression mm": "TABL_CYL_HT_PRE_CO_MM",
                "Tabl. filling depth mm": "TABL_FILLING_DEPTH_MM",
                "Tabletfillingdepth mm": "TABL_FILLING_DEPTH_MM",
                "Fillingdevicespeed rpm": "FILLING_DEVICE_SPEED",
                "Fill-o-matic speed rpm": "FILL-O-MATIC_SPEED_RPM",
                "Tablets/h x1000": "TABLETS_PER_HOUR",
                "Tabletsperhour x1000": "TABLETS_PER_HOUR",
            }
            hmi_df["parameter_desc"] = hmi_df["parameter_desc"].apply(
                lambda x: renamed_params[x]
            )

            print(hmi_df.shape)

            hmi_df = (
                hmi_df.groupby("batch_no", as_index=False)
                .apply(lambda x: x.sort_values("timestamp"))
                .reset_index(drop=True)
            )

            print(hmi_df.shape)
            pivot = pd.pivot_table(
                hmi_df,
                index=["batch_no", "equipment_id", "product_desc", "timestamp"],
                columns="parameter_desc",
                values=["station_1_set_value", "station_2_set_value"],
                aggfunc="last",
            ).reset_index()
            print("pivot is : " , pivot.shape)
            pivot.columns = [
                x.strip().replace(" ", "_").upper().replace("_SET_VALUE", "")
                for x in [" ".join(reversed(col)) for col in pivot.columns.values]
            ]
            for col in pivot.columns:
                if col not in ["BATCH_NO", "EQUIPMENT_ID", "PRODUCT_DESC", "TIMESTAMP"]:
                    pivot[col] = pd.to_numeric(
                        pivot[col].apply(lambda x: str(x).replace(",", ".")),
                        errors="coerce",
                    )

            import datetime

            pivot = pivot.rename(
                columns={
                    "BATCH_NO": "BATCH_ID",
                    "EQUIPMENT_ID": "MACHINE_CODE",
                    "PRODUCT_DESC": "PRODUCT_NAME",
                    "TIMESTAMP": "BATCH_DATETIME",
                }
            )
            pivot["CURRENT_DATETIME"] = datetime.datetime.now()
            final_cols = [
                "BATCH_ID",
                "MACHINE_CODE",
                "PRODUCT_NAME",
                "BATCH_DATETIME",
                "CURRENT_DATETIME",
                "MAIN_COMPR_FORCE_MV_KN_STATION_1",
                "MAIN_COMPR_FORCE_MV_KN_STATION_2",
                "PRE_COMPR_FORCE_MV_KN_STATION_1",
                "PRE_COMPR_FORCE_MV_KN_STATION_2",
                "TABL_CYL_HT_MAIN_CO_MM_STATION_1",
                "TABL_CYL_HT_MAIN_CO_MM_STATION_2",
                "TABL_CYL_HT_PRE_CO_MM_STATION_1",
                "TABL_CYL_HT_PRE_CO_MM_STATION_2",
                "TABL_FILLING_DEPTH_MM_STATION_1",
                "TABL_FILLING_DEPTH_MM_STATION_2",
                "FILLING_DEVICE_SPEED_STATION_1",
                "FILL-O-MATIC_SPEED_RPM_STATION_1",
                "TABLETS_PER_HOUR_STATION_1",
                "FILLING_DEVICE_SPEED_STATION_2",
                "FILL-O-MATIC_SPEED_RPM_STATION_2",
                "TABLETS_PER_HOUR_STATION_2",
            ]

            for col in final_cols:
                if col not in pivot.columns:
                    pivot[col] = np.nan
            pivot = pivot[final_cols]
            print("pivot is : " , pivot.shape)
            pivot = add_ProductCode_From_BatchID(pivot)

            sparkDF = self.spark.createDataFrame(pivot, schema=Schemas.raw_hmi_schema)
            spark_log_df = self.transaction_log.insert_data(
                "RAW", "HMI", pivot, "PRODUCTCODE", "PRODUCT_NAME", "BATCH_ID"
            )

            return sparkDF, spark_log_df

        except Exception as e:
            logging.info("Error in Processing RAW HMI")
            spark_log = self.transaction_log.failure_into_sql(
                "RAW", "HMI", "Error In RAW HMI", "Error"
            )
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()

    def extract_HMI_Compression(self, file, machinecode):
        # Fetching the Files from the folder PAth
        """
        This method Fetch FIles From  the FOlder
        """
        # Get a list of all files and directories in the folder
        # Iterate over the files
        # Check if the current item is a file
        if os.path.isfile(file):
            source_file_path = file
            destination_file_path = os.path.join(self.destination_folder_path, file)
            # Process the file
            print(
                "--------------------------------PDF Processing Start-------------------------------------------",
                file,
            )
            final_cols = [
                "timestamp",
                "batch_no",
                "product_desc",
                "equipment_id",
                "parameter_id",
                "parameter_desc",
                "station_1_set_value",
                "station_1_actual_value",
                "station_2_set_value",
                "station_2_actual_value",
            ]
            final_df = pd.DataFrame(columns=final_cols)
            try:
                with pdfplumber.open(source_file_path) as pdf:
                    # pdf = pdfplumber.open(source_file_path)
                    pages = pdf.pages
                    for page in pages:
                        txt = page.extract_text()
                        if txt.startswith("Parameter list"):
                            lines = txt.split("\n")
                            timestamp = pd.to_datetime(
                                lines[self.date_line]
                                .lower()
                                .split("date:")[-1]
                                .split("oper:")[0]
                                .strip(),
                                format="%d.%m.%Y %H:%M",
                                errors="coerce",
                            )
                            product_desc = (
                                lines[self.product_line]
                                .lower()
                                .split("product:")[-1]
                                .strip()
                                .upper()
                            )
                            batch_no = (
                                lines[self.batch_line]
                                .lower()
                                .split("batch:")[-1]
                                .strip()
                                .upper()
                            )
                            equipment_id = machinecode

                            tables = page.extract_tables()
                            table = tables[0][-1][0]
                            table_lines = table.split("\n")[2:]

                            df_list = []
                            for line in table_lines:
                                line = [x for x in line.split(" ") if x != ""]
                                line.reverse()

                                for i in range(len(line)):
                                    if not re.fullmatch(r"\d+,?\d*", line[i]):
                                        break
                                values = line[:i]
                                line = line[i:]
                                values.reverse()
                                line.reverse()

                                parameter_id = line[0]
                                parameter_desc = (" ").join([x for x in line[1:]])

                                if len(values) == 0:
                                    station_1_set_value = None
                                    station_1_actual_value = None
                                    station_2_set_value = None
                                    station_2_actual_value = None

                                elif len(values) == 1:
                                    station_1_set_value = values[0]
                                    station_1_actual_value = np.nan
                                    station_2_set_value = np.nan
                                    station_2_actual_value = np.nan

                                elif len(values) == 2:
                                    station_1_set_value = values[0]
                                    station_1_actual_value = np.nan
                                    station_2_set_value = values[1]
                                    station_2_actual_value = np.nan

                                elif len(values) == 3:
                                    station_1_set_value = values[0]
                                    station_1_actual_value = values[1]
                                    station_2_set_value = values[2]
                                    station_2_actual_value = np.nan

                                elif len(values) == 4:
                                    station_1_set_value = values[0]
                                    station_1_actual_value = values[1]
                                    station_2_set_value = values[2]
                                    station_2_actual_value = values[3]

                                line_list = [
                                    timestamp,
                                    batch_no,
                                    product_desc,
                                    equipment_id,
                                    parameter_id,
                                    parameter_desc,
                                    station_1_set_value,
                                    station_1_actual_value,
                                    station_2_set_value,
                                    station_2_actual_value,
                                ]
                                df_list.append(line_list)

                            if len(df_list) > 0:
                                df = pd.DataFrame(
                                    df_list,
                                    columns=[
                                        "timestamp",
                                        "batch_no",
                                        "product_desc",
                                        "equipment_id",
                                        "parameter_id",
                                        "parameter_desc",
                                        "station_1_set_value",
                                        "station_1_actual_value",
                                        "station_2_set_value",
                                        "station_2_actual_value",
                                    ],
                                )
                                for col in df.columns:
                                    if "value" in col:
                                        df[col] = pd.to_numeric(
                                            df[col].apply(
                                                lambda x: str(x).replace(",", ".")
                                            ),
                                            errors="coerce",
                                        )

                            final_df = pd.concat([final_df, df], axis=0)

                    self.archive_files(
                        file, "Archive"
                    )  # archive files from source files  to archive files
                    print(
                        "--------------------------------PDF Processing End-------------------------------------------",
                        file,
                    )
                    return final_df
            except Exception as e:
                print(e)
                traceback.print_exc()
                print(f"Corrupt File: {file}")
                return final_df
                # final_df = pd.DataFrame(columns = final_cols)

    def extract_hmi_new_compression_parameter_list(self, file, machinecode):
        print(file)
        source_file_path = file
        final_df = pd.DataFrame()

        try:
            pdf = pdfplumber.open(source_file_path)
            pages = pdf.pages

            for page in pages:
                txt = page.extract_text()
                lines = txt.split("\n")

                if lines[0] == "Parameter at start of Batch":
                    prod_index = 0
                    batch_index = 0
                    time_index = 0
                    for line in lines:
                        if line.startswith("Recipe"):
                            prod_index = lines.index(line)

                        if line.startswith("Batch-No.") or line.startswith(
                            "Batch-Name:"
                        ):
                            batch_index = lines.index(line)

                        if "Date:" in line:
                            time_index = lines.index(line)

                        if (prod_index != 0) & (batch_index != 0) & (time_index != 0):
                            break

                    product_desc = (
                        " ".join(lines[prod_index:batch_index]).split(":")[-1].strip()
                    )
                    batch_no = lines[batch_index].split(":")[-1].strip()
                    timestamp = lines[time_index].split("Date:")[-1].strip()
                    equipment_id = machinecode

                    data = pd.DataFrame(page.extract_table())
                    data.columns = data[:1].values.tolist()
                    data.columns = [" ".join(col) for col in data.columns.values]
                    data.columns = ["parameter_id"] + data.columns.tolist()[1:]
                    data = data[1:].reset_index(drop=True)

                    data = self.col_cleaning(data)
                    cols = data.columns.tolist()
                    data["batch_no"] = batch_no
                    data["equipment_id"] = equipment_id
                    data["product_desc"] = product_desc
                    data["timestamp"] = timestamp
                    data["timestamp"] = pd.to_datetime(
                        data["timestamp"], format="%d.%m.%Y%H:%M:%S", errors="coerce"
                    )

                    data = data[
                        ["batch_no", "product_desc", "equipment_id", "timestamp"] + cols
                    ]
                    print("================================")
                    print(data.columns)
                    data = data.rename(columns={"parameter": "parameter_desc" , "setvalue1": "station_1_set_value" , "setvalue2": "station_2_set_value" , "actualvalue1": "station_1_actual_value" , "actualvalue2": "station_2_actual_value"})
                    data['parameter_desc'] = data['parameter_desc'] + ' ' + data['unit']
                    final_df = pd.concat([final_df, data], axis=0).reset_index(
                        drop=True
                    )

            self.archive_files(
                file, "Archive"
            )  # archive files from source files  to archive files
        except Exception as e:
            print("Corrupt file : " + file)

        return final_df

    def archive_files(self, file, destinationfolder):
        if destinationfolder == "Archive":
            out_file = file.replace("Source", "Archive")
        elif destinationfolder == "Corrupt":
            out_file = file.replace("Source", "Corrupt")

        out_dir = "/".join(out_file.split("/")[:-1])
        if not os.path.exists(out_dir):
            os.makedirs(out_dir)
        shutil.move(file, out_file)

    def col_cleaning(self, df):
        df.columns = [
            re.sub(r"[ _-]+", "_", re.sub(r"[.()/:\n]", " ", col.lower()).strip())
            for col in df.columns
        ]
        return df

    # push into SQL table

    def push_to_raw_HMI(self, sparkDF, spark_log_df):
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkDF, "dbo.MLOPS_PIPELINE_RAW_HMI")

        print(" !!!!!!!  DATA IS SUCCESSFULLY PUSHED IN RAW HMI  !!!!!!!")
        self.transaction_log.push_DataFrame_to_sql(spark_log_df)
        print("!!!!!!!!! DATA IS SUCCESSFULLY PUSHed IN LOGGING FOR RAW HMI ")
