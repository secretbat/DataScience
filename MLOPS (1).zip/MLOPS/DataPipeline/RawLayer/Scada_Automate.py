import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import traceback
import logging
import pyspark
from pyspark.sql import SparkSession
from DataPipeline import TableColumn
from datetime import datetime
from DataPipeline import Schemas
from DataPipeline.SQLConnection import SQLConnection
from datetime import datetime
from DataPipeline.TransactionLog import TransactionLog
from pyspark.sql.functions import lit
import random
import string
import time


class Scada_Auto:
    def __init__(self) -> None:
        self.sparkdf = self.fetch_RAW_SCADA()
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.transaction_log = TransactionLog()

    def fetch_RAW_SCADA(self):
        # Filtering the Data Based on Product code, machine code , batch size and preprocessed DateTime
        """
        THis method fetch Data From PreProcessed Table based on Product code, machine code
        , batch size and preprocessed DateTime which is not there in FinalLayer Table

        """
        print("Time Taken is  : ", time.time())
        starttime = time.time()
        table = "[dbo].[VW_IND4_COATING_GRANULATION]"
        query = f"""SELECT DISTINCT [BATCH_ID]
            ,[MACHINECODE]
            ,cast(IIF(ISNUMERIC([PRODUCTCODE]) = 1,trim([PRODUCTCODE]),null) as int) PRODUCTCODE
            ,[PRODUCT_NAME] PRODUCTNAME
            ,[USER_FULL_NAME]
            ,[STAGE]
            ,[SUBSTAGE]
            ,convert(DATETIME2,[DATETIME],126) DATETIME
            ,[LOTNUMBER]
            ,[CURRENT_DATETIME]
            ,cast(IIF(ISNUMERIC([INLET_TEMP_ACT])=1,[INLET_TEMP_ACT],NULL) as float)[INLET_TEMP_ACT]
            ,cast(IIF(ISNUMERIC([SPRAY_RATE_ACT])=1,[SPRAY_RATE_ACT],NULL) as float)[SPRAY_RATE_ACT]
            ,cast(IIF(ISNUMERIC([SPRAY_PUMP_RPM_ACT])=1,[SPRAY_PUMP_RPM_ACT],NULL) as float)[SPRAY_PUMP_RPM_ACT]
            ,cast(IIF(ISNUMERIC([AIR_FLOW_CFM_ACT])=1,[AIR_FLOW_CFM_ACT],null) as float)[AIR_FLOW_CFM_ACT]
            ,cast(IIF(ISNUMERIC([AIR_FLOW_INLET_M_S_ACT])=1,[AIR_FLOW_INLET_M_S_ACT],null) as float)[AIR_FLOW_INLET_M_S_ACT]
            ,cast(IIF(ISNUMERIC([EXHAUST_TEMP_ACT])=1,[EXHAUST_TEMP_ACT],null) as float)[EXHAUST_TEMP_ACT]
            ,cast(IIF(ISNUMERIC([PRODUCT_TEMP_ACT])=1,[PRODUCT_TEMP_ACT],null) as float)[PRODUCT_TEMP_ACT]
            ,cast(IIF(ISNUMERIC([DRIVE_SPEED_ACT])=1,[DRIVE_SPEED_ACT],null) as float)[DRIVE_SPEED_ACT]
            ,cast(IIF(ISNUMERIC([ATOMIZATION_AIR_PRESSURE_ACT])=1,[ATOMIZATION_AIR_PRESSURE_ACT],null) as float)[ATOMIZATION_AIR_PRESSURE_ACT]
            ,cast(IIF(ISNUMERIC([ATOMIZATION_AIR_ACT])=1,[ATOMIZATION_AIR_ACT],null) as float)[ATOMIZATION_AIR_ACT] FROM {table} WHERE trim(BATCH_ID) like 'ID%' and
             BATCH_ID NOT IN (SELECT DISTINCT BATCH_ID from [dbo].[MLOPS_PIPELINE_AUTOMATED_SCADA])
            """
        sql = SQLConnection()
        spark_df = sql.read_tables_data_spark(query)

        endtime = time.time()
        timetaken = endtime - starttime
        logging.info("{ TimeTaken By the Automated Scada is : %s }", timetaken)
        print("Time taken by the Automated Scada : ", timetaken)
        return spark_df

    def intermediate_processing(self):
        try:
            starttime = time.time()
            scada = self.sparkdf

            def filter_data(df):
                return df.filter(df["DATETIME"] > "2021-01-01")

            scada = filter_data(scada)

            for col in Schemas.scada_manual_schemas.fieldNames():
                if col not in scada.columns:
                    scada = scada.withColumn(f"{col}", lit(None))

            scada = scada[Schemas.scada_manual_schemas.fieldNames()]

            scada = self.spark.createDataFrame(
                scada.rdd, schema=Schemas.scada_manual_schemas
            )
            # here we need to add logging code

            spark_log_df = self.transaction_log.insert_data_spark(
                "RAW", "AUTOMATE SCADA", scada, "PRODUCTCODE", "PRODUCTNAME", "BATCH_ID"
            )

            endtime = time.time()
            timetaken = endtime - starttime
            logging.info(
                "{ TimeTaken By the Automated Scada Intermediate Processing is : %s }",
                timetaken,
            )
            print(
                "Time taken by the Automated Scada Intermediate Processing : ",
                timetaken,
            )
            return scada, spark_log_df

        except Exception as e:
            logging.info("Error in Processing RAW HMI")
            spark_log = self.transaction_log.failure_into_sql(
                "RAW", "AUTOMATED SCADA", "Error In RAW AUTOMATED SCADA", "Error"
            )
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()

    def push_Data_in_automated_scada(self, sparkdf, spark_log_df):
        # Push the DataFrame Into SQL Table
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf, "dbo.MLOPS_PIPELINE_AUTOMATED_SCADA")
        print("DATA PUSHED SUCCESSFULLY FOR RAW AUTOMATED SCADA")
        self.transaction_log.push_DataFrame_to_sql(spark_log_df)
        print("DATA PUSHED SUCCESSFULLY FOR LOGGING FOR  RAW AUTOMATED SCADA")
