import os
import logging
import pyspark
from pyspark.sql import SparkSession
from DataPipeline import TableColumn
from DataPipeline.SQLConnection import SQLConnection
from datetime import datetime
import pandas as pd
import numpy as np
from tqdm import tqdm
import glob
import re
import os
import pdfplumber
import multiprocessing as mp
import shutil
import traceback
from DataPipeline import Schemas
from DataPipeline.TransactionLog import TransactionLog

import random
import string

class Raw_APQR:
    def __init__(self,source_folder_path,destination_folder_path):
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.source_folder_path = source_folder_path
        self.destination_folder_path = destination_folder_path
        self.transaction_log = TransactionLog()


    def fetch_APQR_Files(self):
        """
        Fetches all the APQR files from the source folder
        """
        logging.info("Fetching APQR filres methods")
        self.transaction_log.TRANSACTION_ID = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
        self.transaction_log.LOG_FILE_NAME = str(self.transaction_log.TRANSACTION_ID) + '_logging.log'
        self.transaction_log.DATETIME = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        self.transaction_log.LAYER = "RAW"
        self.transaction_log.SUBLAYER = "APQR"

        sql_df = self.transaction_log.create_SQL_DataFrame()
        try:
            all_apqr_path = glob.glob( self.source_folder_path )
            apqr_df= pd.concat( [ pd.read_excel(f) for f in all_apqr_path ] )
            print(apqr_df.shape)
            apqr_df.columns = map(str.upper, apqr_df.columns)

            col = {'BATCH NO.': 'BATCH_ID', 'MATERIAL CODE': 'PRODUCTCODE','INSPECTION LOT NO.': 'INSPECTION_LOT_NO', 
                'MATERIAL DESCRIPTION': 'MATERIAL_DESCRIPTION','PLANT NAME': 'PLANTNAME', 'RECIPE NO. CODE': 'RECIPE_NO'
                ,'PRODUCTION VERSION': 'PRODUCTION_VERSION','UD STATUS': 'UD_STATUS', 'CHAR SR. NO.': 'CHAR_SR_NO'
                ,'MIC NO': 'MIC_NO','MIC DESCRIPTION': 'MIC_DESCRIPTION', 'TARGET VALUE': 'TARGET_VALUE'
                ,'LOWER VALUE': 'LOWER_VALUE','HIGHER VALUE': 'HIGHER_VALUE', 'LONG_TEXT_DESCRIPTION': 'LONG TEXT DESCRIPTION',
                'ADDITIONAL INFORMATION': 'ADDITIONAL_INFORMATION'}
            apqr_df = apqr_df.rename(columns= col)

            

            apqr_df["CURRENT_DATETIME"] = datetime.now().strftime("%d/%m/%Y %H:%M:%S") #pd.to_datetime(pd.Timestamp.now(),unit='s')
            apqr_df["CURRENT_DATETIME"] = pd.to_datetime(apqr_df["CURRENT_DATETIME"])

            apqr_col = ['BATCH_ID','CURRENT_DATETIME','PRODUCTCODE','INSPECTION_LOT_NO',  'MATERIAL_DESCRIPTION', 'PLANT', 'PLANTNAME',  'RECIPE NO.',\
            'PRODUCTION_VERSION', 'UD_STATUS', 'OPERATION NO.', 'CHAR_SR_NO', 'MIC_NO', 'MIC_DESCRIPTION', 'TARGET_VALUE', 'LOWER_VALUE',\
            'HIGHER_VALUE', 'RESULT', 'UOM', 'LONG TEXT DESCRIPTION', 'ADDITIONAL_INFORMATION']
            apqr_df = apqr_df[apqr_col]

            
            sparkDF=self.spark.createDataFrame(apqr_df,schema=Schemas.raw_apqr_schema) 
            print((sparkDF.count(), len(sparkDF.columns)))

            # -----------------------------Logging Code-----------------------------------

            

            for productcode in apqr_df['PRODUCTCODE'].unique() :
                logging.info("Product code: %s",productcode)
                self.transaction_log.PRODUCTCODE = productcode
                logging.info("Printing shape of product code: %s", apqr_df[apqr_df['PRODUCTCODE'] == int(productcode)].head())
                logging.info(apqr_df[apqr_df['PRODUCTCODE'] == int(productcode)]['MATERIAL_DESCRIPTION'].iloc[0])
                self.transaction_log.PRODUCTNAME = apqr_df[apqr_df['PRODUCTCODE'] == int(productcode)]['MATERIAL_DESCRIPTION'].iloc[0]
                self.transaction_log.NO_OF_BATCHES = apqr_df.groupby('PRODUCTCODE')['BATCH_ID'].nunique()[int(productcode)]
                self.transaction_log.SITE = "Will Get from Plant Name"
                self.transaction_log.UNIT = "Will Get from Plant Name"
                self.transaction_log.STATUS = "SUCCESS"

                sql_df = self.transaction_log.insert_SQL_DataFrame(sql_df)

            # convert new_df into Spark
            logging.info("SQL_DF shape has been printed")
            logging.info(sql_df.shape)
            for i in sql_df.columns:
                if i != 'DATETIME':
                    sql_df[i] = sql_df[i].astype(str)
            sql_df['DATETIME'] = pd.to_datetime(sql_df['DATETIME'])
            logging.info("-----------------------------------------------")
            logging.info(sql_df.shape)
            spark_log_df = self.spark.createDataFrame(sql_df,schema=Schemas.logging_schemas)
            
            return sparkDF,spark_log_df
        except Exception as e:
            sql_df = self.transaction_log.create_SQL_DataFrame()
            print(e)
            print(" Inside Exception --> Error In Processing APQR Of ALL the Sites")
            logging.info("Inside Exception --> Error In Processing APQR Of ALL the Sites")
            logging.info(e)
            logging.exception(e)
            self.transaction_log.PRODUCTCODE = 'NA'
            self.transaction_log.PRODUCTNAME = 'NA'
            self.transaction_log.SITE = "Will Get from Plant Name"
            self.transaction_log.UNIT = "Will Get from Plant Name"
            self.transaction_log.STATUS = "FAILURE"
            self.transaction_log.FAILURE_REASON = "Error In Processing APQR Of ALL the Sites from Excel"
            self.transaction_log.FAILURE_DESCRIPTION = str(e)

            new_df = self.transaction_log.insert_SQL_DataFrame(sql_df)
            for i in new_df.columns:
                if i != 'DATETIME':
                    new_df[i] = new_df[i].astype(str)
            new_df['DATETIME'] = pd.to_datetime(new_df['DATETIME'])
            print(new_df.shape)
            print(new_df.columns)
            logging.info("----------------------------------------------------")
            logging.info(new_df.columns)
            # convert new_df into Spark
            spark_log = self.spark.createDataFrame(new_df,schema=Schemas.logging_schemas)
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            traceback.print_exc()   

    def push_Data_in_raw_apqr(self,sparkdf,spark_log_df):
        #Push the DataFrame Into SQL Table
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf,"dbo.MLOPS_PIPELINE_RAW_APQR")

        self.transaction_log.push_DataFrame_to_sql(spark_log_df)

        print("!!!!!!!!  Data Pushed Successfully in RAW APQR !!!!!!!!!")