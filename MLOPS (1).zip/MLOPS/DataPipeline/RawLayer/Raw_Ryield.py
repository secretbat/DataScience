import os
import logging
import pyspark
from pyspark.sql import SparkSession
from DataPipeline import TableColumn
from DataPipeline.SQLConnection import SQLConnection
from datetime import datetime
import pandas as pd
import numpy as np
from tqdm import tqdm
import glob
import re
import os
import pdfplumber
import multiprocessing as mp
import shutil
import traceback
from DataPipeline import Schemas
from DataPipeline.TransactionLog import TransactionLog

import random
import string

class Raw_RYIELD:
    def __init__(self,source_folder_path,destination_folder_path):
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.source_folder_path = source_folder_path
        self.destination_folder_path = destination_folder_path
        self.transaction_log = TransactionLog()


    def fetch_RYIELD_Files(self):
        """
        Fetches all the APQR files from the source folder
        """
        logging.info("Fetching RAW RYIELD fils methods")
        try:
            all_ryield_path = glob.glob( self.source_folder_path )
            ryield_df= pd.concat( [ pd.read_excel(f) for f in all_ryield_path ] )
            print(ryield_df.shape)
            ryield_df.columns = map(str.upper, ryield_df.columns)

            col = {'BATCH NUMBER': 'BATCH_ID', 'MATERIAL NO': 'PRODUCTCODE', 'BATCH SIZE': 'BATCH_SIZE','MATERIAL DESCRIPTION': 'PRODUCTNAME', '% YIELD' : 'OVERALL_YIELD_PERCENT'}
            ryield_df = ryield_df.rename(columns= col)

            # ryield_df = ryield_df[list(col.values())]            

            ryield_df["CURRENT_DATETIME"] = datetime.now().strftime("%d/%m/%Y %H:%M:%S") #pd.to_datetime(pd.Timestamp.now(),unit='s')
            ryield_df["CURRENT_DATETIME"] = pd.to_datetime(ryield_df["CURRENT_DATETIME"])
            print("----------------------------------------------------------------")
            print(ryield_df.columns)
            apqr_col = ['BATCH_ID','PRODUCTCODE','PRODUCTNAME',  'CURRENT_DATETIME', 'BATCH_SIZE', 'OVERALL_YIELD_PERCENT']
            ryield_df = ryield_df[apqr_col]

            
            sparkDF=self.spark.createDataFrame(ryield_df,schema=Schemas.raw_ryield_schema) 
            print((sparkDF.count(), len(sparkDF.columns)))

            # -----------------------------Logging Code-----------------------------------
            spark_log_df = self.transaction_log.insert_data(
                "RAW", "RYIELD", ryield_df, "PRODUCTCODE", "PRODUCTNAME", "BATCH_ID"
            )
            
            return sparkDF,spark_log_df
        except Exception as e:
            logging.info("Error in Processing RAW RYIELD")
            spark_log = self.transaction_log.failure_into_sql(
                "RAW", "RYIELD", "Error In RAW RYIELD", "Error"
            )
            self.transaction_log.push_DataFrame_to_sql(spark_log)
            print(e)
            traceback.print_exc()   

    def push_Data_in_raw_ryield(self,sparkdf,spark_log_df):
        #Push the DataFrame Into SQL Table
        sql_connect = SQLConnection()
        sql_connect.write_spark_to_table(sparkdf,"dbo.MLOPS_PIPELINE_RAW_RYIELD")
        print("!!!!!!!!  Data Pushed Successfully in RAW YIELD !!!!!!!!!")
        self.transaction_log.push_DataFrame_to_sql(spark_log_df)
        print("!!!!!!!!  Data Pushed Successfully in Logging For RAW Ryield  !!!!!!!!!")
        