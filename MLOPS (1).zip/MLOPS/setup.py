from setuptools import find_packages, setup

setup(
    name="ciplibrary_model",
    packages=find_packages(include=["*"]),
    version="4.2.3",
    description="This Library containing various custom utility functions accross for OEE granulation use case.",
    author="Reshma Chikate",
    include_package_data=True,
    license="CIPLA",
)
