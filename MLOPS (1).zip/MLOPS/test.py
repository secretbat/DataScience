import logging
import traceback
import time

class RootFilter(logging.Filter):
    def filter(self, record):
        return record.name == 'root'
# Set up a handler that uses the filter
handler = logging.StreamHandler()
handler.addFilter(RootFilter())
# Set up the logger with the handler
logger = logging.getLogger('my_logger')
logger.addHandler(handler)

start_time = time.time()
from ciplibrary_model.pegasus import pegasus_model
ymlpath = '/dbfs/mnt/pegasusdatalake/MLOps/DS/my_yml.yml'
basepath = '/dbfs/mnt/pegasusdatalake/MLOps/DS/Test/CipLibrary'

pegasus_model(ymlpath ,basepath)

end_time = time.time()
print("Duration is : " , end_time - start_time)
timetaken = end_time - start_time
logging.info('(Pegasus.py) --> (pegasus_model) --> { TimeTaken By the Library is : %s }',timetaken)
# historical_pipeline_data/Test/YAML_File/Yml_file.yml
print("Done !!!")
print("")