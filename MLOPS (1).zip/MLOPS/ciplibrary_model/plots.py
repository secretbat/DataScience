import yaml
import os
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import shap
from matplotlib.backends.backend_pdf import PdfPages
from sklearn.inspection import PartialDependenceDisplay
import itertools
import warnings


class plots:
    def __init__(self):
        pass


    def make_shap(self,rf_random,xtrain,ytrain,output_file_name,tgt,OUTPUT_DIR):
        for i in range(ytrain.shape[1]):
                model = rf_random.estimators_[i].best_estimator_
                explainer = shap.TreeExplainer(model,)
                if i==0:
                        shap_values = explainer.shap_values(xtrain, check_additivity=False)
                        shap_values_df = pd.DataFrame(shap_values, columns=xtrain.columns, index=xtrain.index)
                        shap_values_summary = pd.DataFrame(shap_values_df.abs().mean(), columns=["abs_mean_shap"])
                        shap_values_summary = shap_values_summary.sort_values(by="abs_mean_shap", ascending=False)

                        #---------------
                        fig = shap.summary_plot(
                        shap_values, xtrain, max_display=30, plot_type='dot', show=False)
                        #-----------------------

                        #-------------------------------
                        top_shap_features = shap_values_summary.index.tolist()
                        shapfilename=output_file_name+'_shap_plot_'+tgt[i]
                        with PdfPages(os.path.join(OUTPUT_DIR, shapfilename)) as pdf:
                                for feature in top_shap_features:
                                        fig = shap.dependence_plot(
                                        feature,
                                        shap_values,
                                        xtrain,
                                        interaction_index=None,
                                        alpha=1,
                                        dot_size=20,
                                        color="purple",
                                        show=False,
                                        )
                                        plt.title(feature, fontsize=15)
                                        plt.xlabel('')
                                        plt.ylabel(ytrain.columns[i])
                                        plt.title(feature)
                                        pdf.savefig()
                elif i==1:
                        shap_values = explainer.shap_values(xtrain, check_additivity=False)
                        shap_values_df = pd.DataFrame(shap_values, columns=xtrain.columns, index=xtrain.index)
                        shap_values_summary = pd.DataFrame(shap_values_df.abs().mean(), columns=["abs_mean_shap"])
                        shap_values_summary = shap_values_summary.sort_values(by="abs_mean_shap", ascending=False)

                        #---------------
                        fig = shap.summary_plot(
                        shap_values, xtrain, max_display=30, plot_type='dot', show=False)
                        #-----------------------

                        #-------------------------------
                        top_shap_features = shap_values_summary.index.tolist()
                        shapfilename=output_file_name+'_shap_plot_'+tgt[i]
                        with PdfPages(os.path.join(OUTPUT_DIR, shapfilename)) as pdf:
                                for feature in top_shap_features:
                                        fig = shap.dependence_plot(
                                        feature,
                                        shap_values,
                                        xtrain,
                                        interaction_index=None,
                                        alpha=1,
                                        dot_size=20,
                                        color="purple",
                                        show=False,
                                        )
                                        plt.title(feature, fontsize=15)
                                        plt.xlabel('')
                                        plt.ylabel(ytrain.columns[i])
                                        plt.title(feature)
                                        pdf.savefig()
        print('SHAP DONE')
  
    def make_pdp(self,feature_imp_sorted,yeild_sorted,ct_sorted,xtrain,ytrain,output_file_name,OUTPUT_DIR,rf_random):
        for i in range(ytrain.shape[1]):
                if ytrain.columns[i].lower().__contains__('yield'):
                        if ytrain.shape[1]==1:
                                pdffilename=output_file_name + '_pdp_plot_' + ytrain.columns[i]
                                with PdfPages(os.path.join(OUTPUT_DIR, pdffilename)) as pdf:
                                        for feature in feature_imp_sorted['FEATURES']:
                                                PartialDependenceDisplay.from_estimator(rf_random.estimators_[i].best_estimator_, xtrain, [feature])
                                                pdf.savefig()
                        elif ytrain.shape[1]==2:
                                pdffilename=output_file_name + '_pdp_plot_' + ytrain.columns[i]
                                with PdfPages(os.path.join(OUTPUT_DIR, pdffilename)) as pdf:
                                        for feature in yeild_sorted['FEATURES']:
                                                PartialDependenceDisplay.from_estimator(rf_random.estimators_[i].best_estimator_, xtrain, [feature])
                                                pdf.savefig()
                        
                elif ytrain.columns[i].lower().__contains__('duration'):
                        if ytrain.shape[1]==1:
                                pdffilename=output_file_name + '_pdp_plot_' + ytrain.columns[i]
                                with PdfPages(os.path.join(OUTPUT_DIR, pdffilename)) as pdf:
                                        for feature in feature_imp_sorted['FEATURES']:
                                                PartialDependenceDisplay.from_estimator(rf_random.estimators_[i].best_estimator_, xtrain, [feature])
                                                pdf.savefig()
                        elif ytrain.shape[1]==2:
                                pdffilename=output_file_name + '_pdp_plot_' + ytrain.columns[i]
                                with PdfPages(os.path.join(OUTPUT_DIR, pdffilename)) as pdf:
                                        for feature in ct_sorted['FEATURES']:
                                                PartialDependenceDisplay.from_estimator(rf_random.estimators_[i].best_estimator_, xtrain, [feature])
                                                pdf.savefig()
        print('PDP DONE')                                








