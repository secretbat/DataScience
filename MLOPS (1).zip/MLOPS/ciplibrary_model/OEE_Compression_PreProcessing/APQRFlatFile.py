import numpy as np
import pandas as pd
import re
import os
from IPython.display import display
from tabulate import tabulate
# import functions
import openpyxl
from openpyxl import load_workbook

class APQR_FLAT_FILE:
    
    def __init__(self):
        pass
    def apqr_flat_file(self,APQR_FILE , apqr_output_file):
        df = pd.read_excel(APQR_FILE)
        List_of_MIC = ["LOSS ON DRYING","BULK DENSITY","TAPPED DENSITY","% FINES"]

        df = df[df["MIC Description"].isin(List_of_MIC)]

        pivot = pd.DataFrame()
        df_pivot = pd.pivot_table(df,index = 'Batch No.', columns = ["MIC Description"], values = ['Result' ])
        print(df_pivot.columns.values)
        df_pivot.columns = [ value[1]   for value in df_pivot.columns.values]
        pivot = pd.concat([pivot, df_pivot], axis = 1)
        
        pivot = apqr_df.reset_index().rename(columns = {'Batch No.' : 'batch_id'})
        pivot.to_excel(apqr_output_file)
        return pivot
    
    def merge(self,df_hmi,df_apqr):
        final_flat_file = df_hmi.merge(df_apqr,left_on='batch_id',right_on='batch_id',validate='1:1')
        final_flat_file.to_excel(final_output_file)  
        
        return final_flat_file