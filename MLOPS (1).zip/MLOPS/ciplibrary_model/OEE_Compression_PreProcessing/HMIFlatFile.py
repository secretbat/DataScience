import numpy as np
import pandas as pd
import re
import os
from IPython.display import display
from tabulate import tabulate
# import functions
import openpyxl
from openpyxl import load_workbook

class HMI_FLAT_FILE:
    
    def __init__(self):
        pass
    
    def to_numeric(self,df,column):
        df[column]=pd.to_numeric(df[column],errors='coerce')
        return df 

    def read_file(self,file_name,col,product_name):
        df=pd.read_parquet(file_name)
        # convert all column names to lower case.
        df.columns = df.columns.str.lower()
        # filter batches
        #print(df[df['product_desc'] == product_name])
    #     print(df[df['parameter_desc'] == 'AMLO BESY 5 MG AND TELMI 40 MG BILAYERED TABLETS'])
        df = df[df[col] == product_name]
        return df
    
    def parameter(self,df,colname,cols):
        #df=pd.read_parquet(file_name)    
         # filter batches
        #print(df[df['parameter_no'] == parameter_no])
        df = df[df[colname].isin(cols)]
        return df
    
    def group_by(self,df,name,cols):
        list_of_cols = {}
        for col in cols:
            list_of_cols[col] ='last'
        print(list_of_cols)
    #     agg_func_selection = list_of_cols
        df=df.groupby(name).agg(list_of_cols).reset_index()
        return df
    
    def pivot_table(self,df,values,index,columns):
    #     pivot_values=['list_of_cols'],index=['list_of_cols'],columns=[]
        df=pd.pivot_table(df,values=values,index=index,columns=columns)
        return df
    
    def clean_up(self,df):
        df.columns = [' '.join(col) for col in df.columns.values]
        return df