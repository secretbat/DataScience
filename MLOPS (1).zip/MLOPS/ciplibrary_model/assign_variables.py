import yaml
import pandas as pd
import numpy as np
import os
import seaborn as sns
from tqdm import tqdm
import warnings

warnings.simplefilter("ignore")
import matplotlib.dates as mdates
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier

warnings.simplefilter("ignore")
from sklearn.linear_model import ElasticNet, ElasticNetCV
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error, make_scorer
from sklearn import preprocessing
from sklearn.metrics import r2_score
import re
import shap
from sklearn.model_selection import train_test_split
import itertools
from operator import mul
from functools import reduce
import statsmodels.api as sm
from matplotlib import pyplot as plt
from pdpbox import pdp, info_plots

# import pandas_profiling as pp
import matplotlib.backends.backend_pdf
from matplotlib.backends.backend_pdf import PdfPages
import colorama
from colorama import Fore
from pandas import ExcelWriter
from datetime import datetime
import xlwt
import os
import traceback
import logging

import pyspark
from pyspark.sql import SparkSession
from ciplibrary_model.SQLConnection_DS import SQLConnection_DS

pd.set_option("display.max_rows", 1000)
pd.set_option("display.max_columns", None)


class Variables:  # THis is to be optimized
    def __init__(
        self,
        site,
        unit,
        line,
        product_code,
        product_name,
        machine_code,
        batch_size,
        stage,
        use_case,
        batch_id,
        MaterialNo,
        lot_no,
        activity,
        years_to_be_included,
        column_data_tag,
        spraying,
        drying,
        preheating,
        outlier_cleaning_required,
        missing_value_perc,
        impute_missing_values_by,
        target_column,
        model_names,
        cv,
        niter,
        test_size,
        metrics,
        random_state,
        var_tobe_excluded,
        date_string,
        other,
    ):
        self.product_code = product_code
        self.product_name = product_name
        self.batch_id = batch_id
        self.MaterialNo = MaterialNo
        self.lot_no = lot_no
        self.activity = activity
        self.years_to_be_included = years_to_be_included
        self.column_data_tag = column_data_tag
        self.spraying = spraying
        self.drying = drying
        self.preheating = preheating
        self.outlier_cleaning_required = outlier_cleaning_required
        self.missing_value_perc = missing_value_perc
        self.impute_missing_values_by = impute_missing_values_by
        self.target_column = target_column
        self.model_names = model_names
        self.cv = cv
        self.niter = niter
        self.test_size = test_size
        self.metrics = metrics
        self.random_state = random_state
        self.site = site
        self.unit = unit
        self.line = line
        self.machine_code = machine_code
        self.batch_size = batch_size
        self.stage = stage
        self.use_case = use_case
        self.var_tobe_excluded = var_tobe_excluded
        self.date_string = date_string
        self.other = other

    def create_directory(self, path):
        print("INSIDE CREATE DIRECTORY")
        logging.info("INSIDE CREATE DIRECTORY")
        RAW_DATA_DIR = os.path.join(path, "raw_data")
        FLAT_DIR = os.path.join(path, "model_input")
        REPORT_DIR = os.path.join(path, "model_report")
        OUTPUT_DIR = os.path.join(path, "model_output")
        CODE_DIR = os.path.join(path, "model_code")

        if not os.path.exists(RAW_DATA_DIR):
            os.makedirs(RAW_DATA_DIR)
            print("RAW_DATA_DIR has been created")
            logging.info("RAW_DATA_DIR has been created")
        if not os.path.exists(FLAT_DIR):
            os.makedirs(FLAT_DIR)
            print("FLAT_DIR has been created")
            logging.info("FLAT_DIR has been created")
        if not os.path.exists(REPORT_DIR):
            os.makedirs(REPORT_DIR)
            print("REPORT_DIR has been created")
            logging.info("REPORT_DIR has been created")
        if not os.path.exists(OUTPUT_DIR):
            os.makedirs(OUTPUT_DIR)
            print("OUTPUT_DIR has been created")
            logging.info("OUTPUT_DIR has been created")
        if not os.path.exists(CODE_DIR):
            os.makedirs(CODE_DIR)
            print("CODE_DIR has been created")
            logging.info("CODE_DIR has been created")

        print(RAW_DATA_DIR, FLAT_DIR, REPORT_DIR, OUTPUT_DIR, CODE_DIR)
        return RAW_DATA_DIR, FLAT_DIR, REPORT_DIR, OUTPUT_DIR, CODE_DIR

    def data_import(self):
        logging.info(
            "Inside (assign_variables.py) -> (data_import) -> Inside data_import method"
        )

        print(self.product_name)
        if self.years_to_be_included == "ALL":
            if self.other["part"] != "N":
                if self.stage.lower() == "coating":
                    query = (
                        "(SELECT c1.BATCH_ID,c1.SUBSTAGE,c1.PAN_SPEED_SET,c1.PAN_SPEED_ACT,c1.INLET_TEMP_ACT,\
                                        c1.INLET_TEMP_SET,c1.SPRAY_RATE_ACT,c1.SPRAY_PUMP_RPM_ACT,c1.AIR_FLOW_CFM_ACT,c1.AIR_FLOW_INLET_M_S_ACT,c1.EXHAUST_TEMP_ACT,\
                                        c1.EXHAUST_TEMP_SET,c1.EXHAUST_FLAP_SET,c1.EXHAUST_FLAP_ACT,c1.PRODUCT_TEMP_ACT,c1.PRODUCT_TEMP_SET,c1.DRIVE_SPEED_ACT,\
                                        c1.DRIVE_SPEED_SET,c1.ATOMIZATION_AIR_ACT,c1.ATOMIZATION_AIR_SET,c1.AIR_FLOW_CFM_SET,c1.FINAL_DURATIONS_IN_MINS,c1.COATING_YIELD_PERCENT FROM dbo.MLOPS_PIPELINE_COATING c1\
                                        where PRODUCTCODE = "
                        + str(self.product_code)
                        + " AND MACHINECODE = '"
                        + str(self.machine_code)
                        + "' AND BATCH_SIZE = '"
                        + str(self.batch_size)
                        + "' AND PRODUCT_PART = '"
                        + str(self.other["part"])
                        + "') t"
                    )

                elif self.stage.lower() == "granulation":
                    query = (
                        "(SELECT c1.BATCH_ID,c1.SUBSTAGE,c1.PAN_SPEED_SET,c1.PAN_SPEED_ACT,c1.INLET_TEMP_ACT,\
                                        c1.INLET_TEMP_SET,c1.SPRAY_RATE_ACT,c1.SPRAY_PUMP_RPM_ACT,c1.AIR_FLOW_CFM_ACT,c1.AIR_FLOW_INLET_M_S_ACT,c1.EXHAUST_TEMP_ACT,\
                                        c1.EXHAUST_TEMP_SET,c1.EXHAUST_FLAP_SET,c1.EXHAUST_FLAP_ACT,c1.PRODUCT_TEMP_ACT,c1.PRODUCT_TEMP_SET,c1.DRIVE_SPEED_ACT,\
                                        c1.DRIVE_SPEED_SET,c1.ATOMIZATION_AIR_ACT,c1.ATOMIZATION_AIR_SET,c1.FINAL_DURATIONS_IN_MINS,c1.GRANULATION_YIELD_PERCENT FROM dbo.MLOPS_PIPELINE_GRANULATION c1\
                                        where PRODUCTCODE = "
                        + str(self.product_code)
                        + " AND MACHINECODE = '"
                        + str(self.machine_code)
                        + "' AND BATCH_SIZE = '"
                        + str(self.batch_size)
                        + "' AND PRODUCT_PART = '"
                        + str(self.other["part"])
                        + "') t"
                    )

            else:
                if self.stage.lower() == "compression":
                    query = (
                        "(SELECT c1.BATCH_ID,c1.MAIN_COMPR_FORCE_MV_KN_STATION_1,c1.MAIN_COMPR_FORCE_MV_KN_STATION_2,c1.PRE_COMPR_FORCE_MV_KN_STATION_1,\
                                        c1.PRE_COMPR_FORCE_MV_KN_STATION_2,c1.TABL_CYL_HT_MAIN_CO_MM_STATION_1,c1.TABL_CYL_HT_MAIN_CO_MM_STATION_2,c1.TABL_CYL_HT_PRE_CO_MM_STATION_1,\
                                        c1.TABL_CYL_HT_PRE_CO_MM_STATION_2,c1.TABL_FILLING_DEPTH_MM_STATION_1,c1.TABL_FILLING_DEPTH_MM_STATION_2,c1.FILLING_DEVICE_SPEED_STATION_1,c1.FILLING_DEVICE_SPEED_STATION_2,c1.FILL_O_MATIC_SPEED_RPM_STATION_1,c1.FILL_O_MATIC_SPEED_RPM_STATION_2,c1.TABLETS_PER_HOUR_STATION_1,c1.TABLETS_PER_HOUR_STATION_2,c1.FINES_STATION_1,\
                                        c1.BULK_DENSITY_STATION_1,c1.LOSS_ON_DRYING_STATION_1,c1.TAPPED_DENSITY_STATION_1,c1.FINES_STATION_2,c1.BULK_DENSITY_STATION_2,\
                                        c1.LOSS_ON_DRYING_STATION_2,c1.TAPPED_DENSITY_STATION_2,c1.COMPRESSION_YIELD_PERCENT FROM dbo.MLOPS_PIPELINE_COMPRESSION c1 \
                                        where PRODUCTCODE = "
                        + str(self.product_code)
                        + " AND BATCH_SIZE = '"
                        + str(self.batch_size)
                        + "' AND MACHINECODE = '"
                        + str(self.machine_code)
                        + "') t"
                    )

                elif self.stage.lower() == "coating":
                    query = (
                        "(SELECT c1.BATCH_ID,c1.SUBSTAGE,c1.PAN_SPEED_SET,c1.PAN_SPEED_ACT,c1.INLET_TEMP_ACT,\
                                        c1.INLET_TEMP_SET,c1.SPRAY_RATE_ACT,c1.SPRAY_PUMP_RPM_ACT,c1.AIR_FLOW_CFM_ACT,c1.AIR_FLOW_INLET_M_S_ACT,c1.EXHAUST_TEMP_ACT,\
                                        c1.EXHAUST_TEMP_SET,c1.EXHAUST_FLAP_SET,c1.EXHAUST_FLAP_ACT,c1.PRODUCT_TEMP_ACT,c1.PRODUCT_TEMP_SET,c1.DRIVE_SPEED_ACT,\
                                        c1.DRIVE_SPEED_SET,c1.ATOMIZATION_AIR_ACT,c1.ATOMIZATION_AIR_SET,c1.AIR_FLOW_CFM_SET,c1.FINAL_DURATIONS_IN_MINS,c1.COATING_YIELD_PERCENT FROM dbo.MLOPS_PIPELINE_COATING c1\
                                        where PRODUCTCODE = "
                        + str(self.product_code)
                        + " AND MACHINECODE = '"
                        + str(self.machine_code)
                        + "' AND BATCH_SIZE = '"
                        + str(self.batch_size)
                        + "') t"
                    )
                elif self.stage.lower() == "granulation":
                    query = (
                        "(SELECT c1.BATCH_ID,c1.SUBSTAGE,c1.PAN_SPEED_SET,c1.PAN_SPEED_ACT,c1.INLET_TEMP_ACT,\
                                        c1.INLET_TEMP_SET,c1.SPRAY_RATE_ACT,c1.SPRAY_PUMP_RPM_ACT,c1.AIR_FLOW_CFM_ACT,c1.AIR_FLOW_INLET_M_S_ACT,c1.EXHAUST_TEMP_ACT,\
                                        c1.EXHAUST_TEMP_SET,c1.EXHAUST_FLAP_SET,c1.EXHAUST_FLAP_ACT,c1.PRODUCT_TEMP_ACT,c1.PRODUCT_TEMP_SET,c1.DRIVE_SPEED_ACT,\
                                        c1.DRIVE_SPEED_SET,c1.ATOMIZATION_AIR_ACT,c1.ATOMIZATION_AIR_SET,c1.FINAL_DURATIONS_IN_MINS,c1.GRANULATION_YIELD_PERCENT FROM dbo.MLOPS_PIPELINE_GRANULATION c1\
                                        where PRODUCTCODE = "
                        + str(self.product_code)
                        + " AND MACHINECODE = '"
                        + str(self.machine_code)
                        + "' AND BATCH_SIZE = '"
                        + str(self.batch_size)
                        + "') t"
                    )
        print(query)
        logging.info(query)
        connect = SQLConnection_DS()
        df = connect.read_table_data(query)
        logging.info("STARTING DF--------")
        print("SQL DATA IMPORTED.........")
        logging.info(df.head())
        return df

    def check_SQL_Query(self, query):
        logging.info(
            "Inside (assign_variables.py) -> (data_import) -> Inside data_import method"
        )
        import pandas as pd

        print(query)
        spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        spark_df = spark.sql(query)
        data = spark_df.select("*").toPandas()

        if data.empty == True:
            # this is the new Product
            return 1
        else:
            # this product is exist in DB
            modelRefinedcount = int(data.loc[0][0]) + 1
            return modelRefinedcount