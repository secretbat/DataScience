import pandas as pd

def sort_df(df):
    data = pd.DataFrame()
    count = 0
    batches = df['BATCH_ID'].unique()
    for i in batches:
        batch = df[df['BATCH_ID'] == i]
        batch.sort_values('DATETIME', inplace=True)
        merge = [data, batch]
        data = pd.concat(merge)
        count = count + 1
    # print(count)
    df = data
    return df