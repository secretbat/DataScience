import pandas as pd
import numpy as np
import re
import openpyxl
from openpyxl import load_workbook

class AdheranceCalculations:
    def __init__(self,df,excelFileName):
        self.df = df
        self.excelFileName = excelFileName

    
    def Adherance_or_DeploymentIndex_Calculation(self):
        OriginalDf = self.df.copy()
        df_copy = self.df.copy()
        df_copy.columns = [str(i).lower() for i in df_copy.columns.tolist()]
        
        # rename the columns to imp_score, optimal_ranges, Features
        for i in df_copy.columns:
            if 'score' in i.lower():
                df_copy.rename({i:'imp_score'}, inplace=True , axis=1)
            elif 'range' in i.lower():

                if "suggested" in i.lower() or "optimal" in i.lower():
                    df_copy.rename({i:'optimal_ranges'}, inplace=True , axis=1)
                else:
                    df_copy.rename({i:'actual_range'}, inplace=True , axis=1)

            elif 'feature' in i.lower():
                df_copy.rename({i:'Features'}, inplace=True , axis=1)

            elif 'controllable' in i.lower() or 'control' in i.lower():
                df_copy.rename({i:'controllable'}, inplace=True , axis=1)

            elif 's.' in i.lower() or 's .' in i.lower():
                df_copy.rename({i:'s.n.'}, inplace=True ,axis=1)

            elif 'remark' in i.lower():
                df_copy.rename({i:'remarks'}, inplace=True ,axis=1)
                
        for i in df_copy.columns:
            if  i in ['s.n.', 'controllable', 'actual_range', 'remarks'] :
                df_copy.drop(i,axis=1 , inplace=True)
                
        list_of_batches = [ i for i in df_copy.columns if i not in ['imp_score' ,'optimal_ranges','Features' ]]

        # there are some batches which have values interms of ranges [ eg : 384.5-385.14 ]
        for i in list_of_batches:
            df_copy[i] = df_copy[i].apply(lambda x :( float(str(x).split('-')[0]) + float(str(x).split('-')[1]) )/ 2  if '-' in str(x) else x)

        self.df = df_copy
        self.df = self.data_preprocessing()
        # Basic calculations.
        self.df = self.basic_calculation()

        # Calculate deployment error
        deployment_error_df, deployment_error_df_summary, adherence_df = self.calculate_deployment_error()

        # Degree of Adherence
        adherence_df, adherence_df_summary = self.calculate_adherence(adherence_df)

        # attach features
        deployment_error_df, adherence_df = self.attach_features(df_copy, deployment_error_df, adherence_df)

        # final summary
        final_summary_df = self.get_final_summary(adherence_df_summary, deployment_error_df_summary)
        final_summary_df.columns = final_summary_df.columns.str.upper()
        
        # write_to_excel
        self.write_to_excel(self.excelFileName,final_summary_df, adherence_df, deployment_error_df, OriginalDf)
        
        
        print("---------------------------------------------- !!!(((SUCCESS)))!!!-------------------------------------------------------")

    def data_preprocessing(self):
        df1 = self.df.copy()
    #     df1.columns = [str(i).lower() for i in df1.columns.tolist()]
        
    #     for i in df1.columns:
    #         if 'score' in i.lower():
    #             print('inside Score')
    #             df1.rename({i:'imp_score'}, inplace=True , axis=1)
    #         elif 'range' in i.lower():
    #             df1.rename({i:'optimal_ranges'}, inplace=True , axis=1)
                
    #     print(df1.columns)
        def limits(x):     # THis method will return Tuple {Range(A-Above, B-below,R-range) , LowerBound , Upper bound}
            x = str(x).lower()
            if 'above' in str(x).lower() or '>' in str(x).lower():
                lower = re.findall('[0-9]+', x)[0]
                return 'A',lower,np.inf
            elif 'below' in str(x).lower() or '<' in str(x).lower():
                upper = re.findall('[0-9]+', x)[0]
                return 'B',-np.inf,upper
            elif 'to' in str(x).lower():    
                number = x.split("to")
                range1 = re.findall(r'[\d\.\d]+', number[0])[0]
                range2 = re.findall(r'[\d\.\d]+', number[1])[0]
                return 'R',range1,range2
            elif '-' in str(x).lower():
                number = x.split("-")
                range1 = re.findall(r'[\d\.\d]+', number[0])[0]
                range2 = re.findall(r'[\d\.\d]+', number[1])[0]
                return 'R',range1,range2
            else:
                return 'R',x,x
                    
        df1['limits,lower,upper'] = df1['optimal_ranges'].apply(lambda x :limits(x) )
        df1['lower'] = df1['limits,lower,upper'].apply(lambda x : x[1])
        df1['upper'] = df1['limits,lower,upper'].apply(lambda x : x[2])
        df1['limits'] = df1['limits,lower,upper'].apply(lambda x : x[0])
        
        df1[['lower','upper']] = df1[['lower','upper']].astype('float64')
        df1.drop(['Features','limits,lower,upper'],axis=1 ,inplace= True)

    #     df1.rename({'score':'imp_score'}, inplace=True , axis=1)
    #     cols = df1.columns.tolist()
    #     cols = cols[1:] + cols[0:1]
    #     df1 = df1[cols]
    #     print(df1.columns)
        df1 = df1[[cols for cols in df1.columns if cols not in ["lower" , 'upper','limits' , 'optimal_ranges', 'imp_score'] ] +
            ["lower" , 'upper','limits' , 'optimal_ranges', 'imp_score']]
        
        return df1
    

    def get_batch_code(file_name):
        df = pd.read_excel(file_name)
        batch_code = pd.Series(df.columns.values).apply(lambda x: x[:3].lower()).mode().values[0]
        return batch_code
    
    def read_file(file_name,batch_code):
        df=pd.read_excel(file_name)
        
        # convert all column names to lower case.
        df.columns = df.columns.str.lower()
        
        # filter batches
        df1 = df.filter(regex=batch_code,axis=1)
        
        # Detect the score column 
        score_col = df.filter(regex="score",axis=1).columns[0]
        
        df1["imp_score"] = np.array(df[score_col])
        df1["optimal_ranges"] = np.array(df["optimal_ranges"])
        df1["limits"] = df["optimal_ranges"].apply(lambda x: x[0]).apply(lambda x:"R" if x not in ["A","B"] else x)
        
        return df1
    
    def creating_lower_upper_columns(df):
        lower=[]
        upper=[]
        for index, value in df[["optimal_ranges","limits"]].iterrows():
            if value["limits"]=="A":
                number = value["optimal_ranges"].split("Above")
                numbers = re.findall(r'[\d\.\d]+', number[1])
                if len(numbers) == 1:
                    lower.append(float(numbers[0]))
                    upper.append(float(np.inf))
                else:
                    low_range = float(numbers[0])*60 + float(numbers[1])
                    lower.append(low_range)
                    upper.append(np.inf)

            elif value["limits"]=="B":
                number = value["optimal_ranges"].split("Below")
                numbers = re.findall(r'[\d\.\d]+', number[1])
                if len(numbers) == 1:
                    lower.append(float(-np.inf))
                    upper.append(float(numbers[0]))
                else:
                    up_range = float(numbers[0])*60 + float(numbers[1])
                    lower.append(float(-np.inf))
                    upper.append(up_range)

            else:
                number = value["optimal_ranges"].split("to")
                range1 = re.findall(r'[\d\.\d]+', number[0])[0]
                range2 = re.findall(r'[\d\.\d]+', number[1])[0]
                lower.append(range1)
                upper.append(range2)
                
        df["lower"] = np.array(lower)
        df["lower"] =df["lower"].astype(float)
        
        df["upper"] = np.array(upper)
        df["upper"] =df["upper"].astype(float)
        
        return df
    

    def basic_calculation(self):
        df = self.df.copy()
        for i in df.iloc[:,:-5]:
            df5 = pd.DataFrame([df[i], df["limits"], df["lower"],df["upper"],df["imp_score"]]).T
            check = []
            r = []
            for j,value in df5.iterrows():

                # Creating R column.
                val1 = abs(value["upper"] - value[i])
                val2 = abs(value["lower"] - value[i])
                if min(val1,val2)==val1:
                    r.append(value["upper"])
                else:
                    r.append(value["lower"])

                #######################################################        
                if value["lower"] <= value[i] <= value["upper"]:
                        # print("yes")
                        check.append(0)
                        # print(0)

                else:
                    # print("not in range")
                    if value["limits"] == "A":
                        diff = abs(value["lower"] - value[i])
                        check.append(diff)
                        # print(diff)

                    elif value["limits"] == "B":
                        diff1 = abs(value["upper"] - value[i])
                        check.append(diff1)
                        # print(diff1)

                    elif value["limits"] == "R":
                        val1 = abs(value["upper"] - value[i])
                        val2 = abs(value["lower"] - value[i])
                        check.append(min(val1,val2))   
                ###########################################################

            # Append columns to the df5 dataframe.
            df5["R"]=np.array(r)
            
            df5["R"]  =df5["R"].apply(lambda x: 0.001 if x==0 else x )

            df5[str(i)+"_Adh"] = np.array(check)

            df5["imp/R"] = df5["imp_score"] / df5["R"]

            df5[str(i)+"_Adh_"+"imp/R"] = df5[str(i)+"_Adh"] * df5["imp/R"]
            
            # append columns to the batch_columns dataframe.
            df[str(i)+"_deployment_error"] = np.array(df5[str(i)+"_Adh_"+"imp/R"] )
            df[str(i)+"_Adh"] = df5[str(i)+"_Adh"]

            # remove check and r list.
            del check
            del r
            
        return df

    def calculate_adherence(self,df):
        for i in df.columns[:-1]:
            ls=[]
            for index,value in df.iterrows():
                if value[i] != 0:
                    ls.append(0)
                else:
                    ls.append(value["imp_score"])
            df[str(i)[:-4] + "_adherence"] = np.array(ls)
        
        # filter adherence columns only.
        adherence_df = df.filter(regex = "_adherence", axis = 1)
        adherence_df.columns = adherence_df.columns.str.rstrip('_adherence')    
        
        # Calculate sum.
        adherence_df.loc['Degree of Adherence'] = adherence_df.sum()
        adherence_df_summary = pd.DataFrame(adherence_df.loc["Degree of Adherence",:])

        
        return adherence_df, adherence_df_summary
    
    def calculate_deployment_error(self):
        df = self.df.copy()
        # Deployment_error calculation.
        deployment_error_df = df.loc[:,df.columns.str.endswith('_deployment_error')]
        
        # Rename column names
        deployment_error_df.columns = deployment_error_df.columns.str.rstrip('_deployment_error')
        
        # Calculate sum
        deployment_error_df.loc['Deployment Error'] = deployment_error_df.sum()
        deployment_error_df_summary = pd.DataFrame(deployment_error_df.loc["Deployment Error",:])
        
        # filter adherence columns.
        adherence_df = df.loc[:, df.columns.str.endswith('_Adh')]
        adherence_df["imp_score"] = df["imp_score"]
        
        return deployment_error_df, deployment_error_df_summary, adherence_df
    
    def attach_features(self,df, deployment_error_df, adherence_df):
        deployment_error_df["Features"] = df["Features"]
        deployment_error_df.set_index(["Features"], inplace = True)
        deployment_error_df.rename(index = {deployment_error_df.index[-1]: "Deployment Error"}, inplace = True)
        
        df_ = deployment_error_df[deployment_error_df.index=="Deployment Error"]
        slice_ = pd.IndexSlice[df_.index, df_.columns]
    #     deployment_error_df = deployment_error_df.style.set_properties(**{'background-color': 'yellow'}, subset=slice_)
        print(slice_)
        
        adherence_df["Features"] = df["Features"]
        adherence_df.set_index(["Features"], inplace = True)
        adherence_df.rename(index = {adherence_df.index[-1]: "Degree of Adherence"}, inplace = True)
        
        df_1 = adherence_df[adherence_df.index=="Degree of Adherence"]
        slice_1= pd.IndexSlice[df_1.index, df_1.columns]
    #     adherence_df = adherence_df.style.set_properties(**{'background-color': 'yellow'}, subset=slice_1)
        print(slice_1)
        return deployment_error_df, adherence_df
    

    def get_final_summary(self,adherence_df_summary, deployment_error_df_summary):
        # combine two data frames adherence_df_summary and deployment_error_df_summary
        final_summary_df = pd.concat([adherence_df_summary, deployment_error_df_summary],axis=1)
        final_summary_df.index = final_summary_df.index.str.upper()
        final_summary_df.columns = final_summary_df.columns.str.capitalize()

        return final_summary_df
    
    def write_to_excel(self,file_name, final_summary_df, adherence_df, deployment_error_df, df):
        ExcelWorkbook = load_workbook(file_name)
        writer = pd.ExcelWriter(file_name, engine = 'openpyxl')
        writer.book = ExcelWorkbook

    #     raw_data
    #     df.to_excel(writer,
    #                        sheet_name='Raw Data', 
    #                        startrow=0, 
    #                        startcol=0,
    #                        index=False)
        

        # final_summary
        final_summary_df.to_excel(writer, sheet_name='Overall Summary')

        # adherence_error
        adherence_df.to_excel(writer, sheet_name='Degree of Adherence')


        # deployment_error
        deployment_error_df.to_excel(writer, sheet_name='Deployment Error')
        writer.save()
        writer.close()
    




