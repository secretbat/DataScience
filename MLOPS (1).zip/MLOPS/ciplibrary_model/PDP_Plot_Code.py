from sklearn.inspection import partial_dependence  # plot_partial_dependence ,
import pandas as pd
import logging


class PDP_Plot_Ranges:
    def __init__(self):
        pass

    def pdpRanges(self, feature_imp_sorted, model, xtrain, isYield):
        logging.info("INSIDE PDP RANGES")
        from sklearn.inspection import PartialDependenceDisplay
        from sklearn.inspection import partial_dependence

        if isYield:
            new_df = pd.DataFrame(
                columns=[
                    "FEATURES",
                    "YEILD_SUGGESTED_RANGES",
                    "YIELD_FEATURES_IMPORTANCE",
                ]
            )
        else:
            new_df = pd.DataFrame(
                columns=["FEATURES", "CT_SUGGESTED_RANGES", "CT_FEATURES_IMPORTANCE"]
            )
        # new_df = pd.DataFrame(columns = ['FeatureName' , 'Ranges'])

        for feature in feature_imp_sorted["FEATURES"]:
            try:
                results = partial_dependence(model, xtrain, feature)
                result = results.get("average")[0]
                feature_values = results.get("values")[0]

                logging.info("PDP VALUES")
                logging.info(result)
                logging.info(feature_values)

                maximum = 0
                ranges_index = []

                for i in range(len(result)):
                    if maximum == 0:
                        maximum = result[i]
                    elif isYield == True:
                        if result[i] > maximum:
                            print("uptrend")
                            ranges_index.append(i)
                            maximum = result[i]
                        elif result[i] == maximum:
                            print("straight line")
                            ranges_index.append(i)
                            maximum = result[i]
                        elif result[i] < maximum:
                            print("downtrend")
                    elif isYield == False:
                        if result[i] < maximum:
                            print("downtrend")
                            ranges_index.append(i)
                            maximum = result[i]
                        elif result[i] == maximum:
                            print("straight line")
                            ranges_index.append(i)
                            maximum = result[i]
                        elif result[i] > maximum:
                            print("uptrend")

                    maximum = result[i]

                lower = round(feature_values[ranges_index][0], 3)
                upper = round(
                    feature_values[ranges_index][len(feature_values[ranges_index]) - 1],
                    3,
                )

                df_new_row = {}
                df_new_row["FEATURES"] = [feature]
                if isYield:
                    df_new_row["YEILD_SUGGESTED_RANGES"] = [
                        str(str(lower) + " to " + str(upper))
                    ]
                else:
                    df_new_row["CT_SUGGESTED_RANGES"] = [
                        str(str(lower) + " to " + str(upper))
                    ]

                if isYield:
                    df_new_row["YIELD_FEATURES_IMPORTANCE"] = feature_imp_sorted[
                        feature_imp_sorted["FEATURES"] == feature
                    ]["YEILD_SCORES"]
                    df_new_row["YIELD_FEATURES_IMPORTANCE"] = df_new_row[
                        "YIELD_FEATURES_IMPORTANCE"
                    ].round(3)
                else:
                    df_new_row["CT_FEATURES_IMPORTANCE"] = feature_imp_sorted[
                        feature_imp_sorted["FEATURES"] == feature
                    ]["CT_SCORES"]
                    df_new_row["CT_FEATURES_IMPORTANCE"] = df_new_row[
                        "CT_FEATURES_IMPORTANCE"
                    ].round(3)

                df_new_row_1 = pd.DataFrame(df_new_row)
                new_df = pd.concat([new_df, df_new_row_1])
            except Exception as e:
                print(e)
                logging.info("Failed to create PDP Ranges for Feature %s", feature)
                df_new_row = {}
                df_new_row["FEATURES"] = [feature]
                if isYield:
                    df_new_row["YEILD_SUGGESTED_RANGES"] = "Kindly Check in PDP PLot"
                else:
                    df_new_row["CT_SUGGESTED_RANGES"] = "Kindly Check in PDP PLot"

                df_new_row_1 = pd.DataFrame(df_new_row)
                new_df = pd.concat([new_df, df_new_row_1])

        new_df.reset_index(inplace=True, drop=True)
        # new_df.set_index('FEATURES',inplace=True)
        print(new_df)
        logging.info("RANGES")
        logging.info(new_df)
        return new_df

    def calculate_Actual_Ranges_From_RAWDATA(self, df, feature_imp_sorted):
        copy_new_df = feature_imp_sorted.copy()
        copy_new_df["ACTUAL_RANGES_FROM_FLAT_FILE"] = "NA"
        for index, row in feature_imp_sorted.iterrows():
            featurename = row["FEATURES"]
            minbatchinraw = df[featurename].min()
            maxbatchinraw = df[featurename].max()
            actualRangeinBatch = (
                str(round(minbatchinraw, 3)) + " to " + str(round(maxbatchinraw, 3))
            )
            copy_new_df.at[index, "ACTUAL_RANGES_FROM_FLAT_FILE"] = actualRangeinBatch
        return copy_new_df

    def plot_pdp_yield(
        self,
        model,
        X,
        feature,
        target=False,
        return_pd=False,
        y_pct=True,
        figsize=(4, 4),
        norm_hist=True,
        dec=0.5,
    ):
        # Getting values from the partial dependence plot
        print("Inside plot_pdp_yield")
        list2 = []
        list4 = []
        pardep = partial_dependence(model, X, [feature])
        j = feature
        list2.append(pardep.get("values")[0])
        list4.append(pardep.get("average")[0])

        # Creating new columns
        df1 = pd.DataFrame(list4)
        df5 = df1.T
        df5.rename(columns={0: "yield"}, inplace=True)

        df3 = pd.DataFrame(list2)
        df6 = df3.T
        df6.rename(columns={0: "X-Axis"}, inplace=True)

        df2 = pd.concat([df5, df6], axis=1)
        logging.info("BEFORE TRANSFORM")
        logging.info(df2.head())
        df2.sort_values(by="yield", ascending=True, inplace=True)
        # --------------------------------------------------
        logging.info("YIELD calc")
        maxId = df2.index[-1]
        print(maxId)
        logging.info(maxId)
        indexpos = len(df2) // 2
        print(indexpos)
        logging.info(indexpos)
        new_row = pd.DataFrame(
            {"yield": [df2.iloc[maxId][0]], "X-Axis": [df2.iloc[maxId][1]]}
        )
        df2 = pd.concat(
            [df2.iloc[:indexpos], new_row, df2.iloc[indexpos:]]
        ).reset_index(drop=True)
        df2 = df2[~(df2.index == (maxId + 1))].reset_index(drop=True)
        print(df2)
        logging.info(df2)
        # -----------------------------------------------------
        df2["shift Y"] = df2["yield"].shift(periods=1)
        df2["difference"] = df2["yield"] - df2["shift Y"]

        df2.reset_index(inplace=True)
        df2.drop("index", axis=1, inplace=True)
        # print(df2.head())
        # print(df2['difference'])
        # df2.sort_values(by='difference',ascending=False,inplace=True)
        # df2.reset_index(inplace = True,drop=True)
        # print(df2.head())
        df10 = pd.DataFrame()
        df4 = pd.DataFrame()
        list3 = []
        for k in range(len(df2)):
            if df2["difference"][k] > 0:
                max1 = df2["difference"].idxmax()
                # print(max1)
                # print(df2.shape)
                if df2.index[-1] == max1:
                    df2.shift(periods=-1, fill_value=df2["yield"].mean())
                elif df2.index[0] == max1:
                    df2.shift(periods=1, fill_value=df2["yield"].mean())
                # print(max1)
                maxid1 = df2[df2.index == int(max1 - 1)]["yield"]

                if (
                    df2[df2.index == int(max1)]["yield"].iloc[-1]
                    > df2[df2.index == int(max1 - 1)]["yield"].iloc[-1]
                ):
                    # df2.sort_values(by='difference',ascending=False,inplace=True)
                    a = "Above " + str(df2[df2.index == int(max1)]["X-Axis"].iloc[-1])
                    a1 = float(df2[df2.index == int(max1)]["yield"].iloc[-1])
                    list3.append(a)
                    list3.append(a1)
                    a2 = float(df2[df2.index == int(max1)]["X-Axis"].iloc[-1])
                    list3.append(a2)
                    print(max1)
                    print(df2.index)
                    a3 = float(df2[df2.index == int(max1 + 1)]["X-Axis"].iloc[-1])
                    list3.append(a3)

                    df4 = pd.DataFrame(list3, columns=[j])
                else:
                    a = "Below " + str(
                        df2[df2.index == int(max1 - 1)]["X-Axis"].iloc[-1]
                    )
                    a1 = float(df2[df2.index == int(max1 - 1)]["yield"].iloc[-1])
                    list3.append(a)
                    list3.append(a1)
                    a2 = float(df2[df2.index == int(max1 - 1)]["X-Axis"].iloc[-1])
                    list3.append(a2)
                    a3 = float(df2[df2.index == int(max1 - 2)]["X-Axis"].iloc[-1])
                    list3.append(a3)

                    df4 = pd.DataFrame(list3, columns=[j])

            # Difference less than 0
            elif df2["difference"][k] < 0:
                min1 = df2["difference"].idxmin()
                minid1 = df2[df2.index == int(min1 - 1)]["yield"]

                if (
                    df2[df2.index == int(min1)]["yield"].iloc[-1]
                    > df2[df2.index == int(min1 - 1)]["yield"].iloc[-1]
                ):
                    b = "Above " + str(df2[df2.index == int(min1)]["X-Axis"].iloc[-1])
                    list3.append(b)
                    b1 = float(df2[df2.index == int(min1)]["yield"].iloc[-1])
                    list3.append(b1)
                    b2 = float(df2[df2.index == int(min1)]["X-Axis"].iloc[-1])
                    list3.append(b2)
                    b3 = float(df2[df2.index == int(min1 + 1)]["X-Axis"].iloc[-1])
                    list3.append(b3)

                    df4 = pd.DataFrame(list3, columns=[j])
                else:
                    b = "Below " + str(
                        df2[df2.index == int(min1 - 1)]["X-Axis"].iloc[-1]
                    )
                    list3.append(b)
                    b1 = float(df2[df2.index == int(min1 - 1)]["yield"].iloc[-1])
                    list3.append(b1)
                    b2 = float(df2[df2.index == int(min1 - 1)]["X-Axis"].iloc[-1])
                    list3.append(b2)
                    b3 = float(df2[df2.index == int(min1 - 2)]["X-Axis"].iloc[-1])
                    list3.append(b3)

                    df4 = pd.DataFrame(list3, columns=[j])

        df10 = df10.join(df4, how="outer", lsuffix="_")

        # Removing the duplicates from the ranges
        list11 = []
        final_ranges_yield = pd.DataFrame()
        for i in df10.columns:
            ranges = df10[i].drop_duplicates(keep="first").reset_index(drop=True)
            list11.append(ranges)
            final_ranges_yield = pd.DataFrame(list11)
        return final_ranges_yield

    def plot_pdp_OEE(
        self,
        model,
        X,
        feature,
        target=False,
        return_pd=False,
        y_pct=True,
        figsize=(4, 4),
        norm_hist=True,
        dec=0.5,
    ):
        # Getting values from the partial dependence plot
        list2 = []
        list4 = []
        pardep = partial_dependence(model, X, [feature])
        j = feature
        # list2.append(pardep[0][0])
        # list4.append(pardep[1][0])
        list2.append(pardep.get("values")[0])
        list4.append(pardep.get("average")[0])

        # Creating new columns
        df1 = pd.DataFrame(list4)
        df5 = df1.T
        df5.rename(columns={0: "ct"}, inplace=True)

        df3 = pd.DataFrame(list2)
        df6 = df3.T
        df6.rename(columns={0: "X-Axis"}, inplace=True)

        df2 = pd.concat([df5, df6], axis=1)
        df2.sort_values(by="ct", ascending=True, inplace=True)
        logging.info("BEFORE TRANSFORM CT")
        logging.info(df2)

        # --------------------------------------------------
        logging.info("DURATION/CT calc")
        maxId = df2.index[-1]
        print(maxId)
        logging.info(maxId)
        indexpos = len(df2) // 2
        print(indexpos)
        logging.info(indexpos)
        new_row = pd.DataFrame(
            {"ct": [df2.iloc[maxId][0]], "X-Axis": [df2.iloc[maxId][1]]}
        )
        df2 = pd.concat(
            [df2.iloc[:indexpos], new_row, df2.iloc[indexpos:]]
        ).reset_index(drop=True)
        df2 = df2[~(df2.index == (maxId + 1))]
        print(df2)
        logging.info(df2)
        # -----------------------------------------------------

        df2["shift Y"] = df2["ct"].shift(periods=1)
        df2["difference"] = df2["ct"] - df2["shift Y"]

        df2.reset_index(inplace=True)
        df2.drop("index", axis=1, inplace=True)

        df10 = pd.DataFrame()
        df4 = pd.DataFrame()
        list3 = []
        for k in range(len(df2)):
            # Difference greater than 0
            if df2["difference"][k] > 0:
                max1 = df2["difference"].idxmax()
                maxid1 = df2[df2.index == int(max1 - 1)]["ct"]

                if (
                    df2[df2.index == int(max1)]["ct"].iloc[-1]
                    > df2[df2.index == int(max1 - 1)]["ct"].iloc[-1]
                ):
                    a = "Below " + str(
                        df2[df2.index == int(max1 - 1)]["X-Axis"].iloc[-1]
                    )
                    a1 = float(df2[df2.index == int(max1 - 1)]["ct"].iloc[-1])
                    list3.append(a)
                    list3.append(a1)
                    a2 = float(df2[df2.index == int(max1 - 1)]["X-Axis"].iloc[-1])
                    list3.append(a2)
                    a3 = float(df2[df2.index == int(max1 - 2)]["X-Axis"].iloc[-1])
                    list3.append(a3)
                    df4 = pd.DataFrame(list3, columns=[j])
                else:
                    a = "Below " + str(df2[df2.index == int(max1)]["X-Axis"].iloc[-1])
                    a1 = float(df2[df2.index == int(max1)]["ct"].iloc[-1])
                    list3.append(a)
                    list3.append(a1)
                    a2 = float(df2[df2.index == int(max1)]["X-Axis"].iloc[-1])
                    list3.append(a2)
                    a3 = float(df2[df2.index == int(max1 - 1)]["X-Axis"].iloc[-1])
                    list3.append(a3)
                    df4 = pd.DataFrame(list3, columns=[j])

            # Difference less than 0
            elif df2["difference"][k] < 0:
                min1 = df2["difference"].idxmin()
                minid1 = df2[df2.index == int(min1 - 1)]["ct"]

                if (
                    df2[df2.index == int(min1)]["ct"].iloc[-1]
                    > df2[df2.index == int(min1 - 1)]["ct"].iloc[-1]
                ):
                    b = "Below " + str(
                        df2[df2.index == int(min1 - 1)]["X-Axis"].iloc[-1]
                    )
                    list3.append(b)
                    b1 = float(df2[df2.index == int(min1 - 1)]["ct"].iloc[-1])
                    list3.append(b1)
                    b2 = float(df2[df2.index == int(min1 - 1)]["X-Axis"].iloc[-1])
                    list3.append(b2)
                    b3 = float(df2[df2.index == int(min1 - 2)]["X-Axis"].iloc[-1])
                    list3.append(b3)

                    df4 = pd.DataFrame(list3, columns=[j])
                else:
                    b = "Below " + str(df2[df2.index == int(min1)]["X-Axis"].iloc[-1])
                    list3.append(b)
                    b1 = float(df2[df2.index == int(min1)]["ct"].iloc[-1])
                    list3.append(b1)
                    b2 = float(df2[df2.index == int(min1)]["X-Axis"].iloc[-1])
                    list3.append(b2)
                    b3 = float(df2[df2.index == int(min1 - 1)]["X-Axis"].iloc[-1])
                    list3.append(b3)
                    df4 = pd.DataFrame(list3, columns=[j])

        df10 = df10.join(df4, how="outer", lsuffix="_")

        # Removing the duplicates from the ranges
        list11 = []
        final_ranges_ct = pd.DataFrame()
        for i in df10.columns:
            ranges = df10[i].drop_duplicates(keep="first").reset_index(drop=True)
            list11.append(ranges)
            final_ranges_ct = pd.DataFrame(list11)

        return final_ranges_ct

    def Get_PDP_Ranges_optimized(self, feature_imp_sorted, rf_random, usecase, df, tgt):
        logging.info("TARGET INFO")
        count_tgt = 0
        for i in range(0, len(tgt)):
            print(tgt[0])
            logging.info(tgt[0])
            if (tgt[0].lower().__contains__("yield")) and (count_tgt == 0):
                logging.info("Inside IF ")
                count_tgt += 1
                feature_list = df.columns.tolist()

                final_features = []
                for i in df[feature_list]:
                    if len(df[feature_list][i].unique()) > 5:
                        final_features.append(i)
                df11 = pd.DataFrame()
                list14 = []
                a = feature_imp_sorted["FEATURES"][
                    feature_imp_sorted["FEATURES"].isin(final_features)
                ]
                logging.info("INSIDE PDP RANGES")
                logging.info(a)
                for j in feature_imp_sorted["FEATURES"][
                    feature_imp_sorted["FEATURES"].isin(final_features)
                ]:
                    list14.append(
                        self.plot_pdp_yield(
                            rf_random.estimators_[0].best_estimator_,
                            df[feature_list],
                            feature=j,
                        )
                    )
                    df11 = df11.append(
                        self.plot_pdp_yield(
                            rf_random.estimators_[0].best_estimator_,
                            df[feature_list],
                            feature=j,
                        )
                    )
                df11.rename(
                    columns={
                        0: "Range_1",
                        1: "Y1",
                        2: "X1",
                        3: "H1",
                        4: "Range_2",
                        5: "Y2",
                        6: "X2",
                        7: "H2",
                    },
                    inplace=True,
                )

                logging.info("YIELD RANGES END")

                # Calculating one point before and after X1
                if "H2" in df11.columns:
                    df11["H2 - H1"] = df11["H2"] - df11["H1"]
                    df11["X2 - X1"] = df11["X2"] - df11["X1"]

                    # Checking if the curve is concave or convex
                    try:
                        df11["Graph"] = 0
                        for i in range(df11.shape[0]):
                            if df11["H2 - H1"][i] > df11["X2 - X1"][i]:
                                df11["Graph"].iloc[i] = "Convex"
                            elif df11["H2 - H1"][i] < df11["X2 - X1"][i]:
                                df11["Graph"].iloc[i] = "Concave"
                            else:
                                df11["Graph"].iloc[i] = "NA"
                    except:
                        print("Convex/Concave graphs not present")

                    try:
                        for i in range(df11.shape[0]):
                            if df11["Graph"].iloc[i] == "Convex":
                                if df11["Y2"].iloc[i] > df11["Y1"].iloc[i]:
                                    df11["Range_1"].iloc[i] = df11["Range_2"].iloc[i]
                            else:
                                if df11["Y2"].iloc[i] < df11["Y1"].iloc[i]:
                                    df11["Range_1"].iloc[i] = df11["Range_2"].iloc[i]
                    except:
                        print("Cannot get optimal ranges")
                    df12 = df11.rename(columns={"Range_1": "OPTIMAL_RANGES_YIELD"})

                    # Merging optimal ranges with feature_imp_sorted list
                    OPTIMAL_RANGES_YIELD = feature_imp_sorted.merge(
                        df12.iloc[:, 0:1],
                        left_on="FEATURES",
                        right_on=df12.index,
                        how="outer",
                    )
                    print(OPTIMAL_RANGES_YIELD.head())
                    # return OPTIMAL_RANGES_YIELD

                else:
                    df12 = df11.rename(columns={"Range_1": "OPTIMAL_RANGES_YIELD"})

                    # Merging optimal ranges with feature_imp_sorted list
                    OPTIMAL_RANGES_YIELD = feature_imp_sorted.merge(
                        df12.iloc[:, 0:1],
                        left_on="FEATURES",
                        right_on=df12.index,
                        how="outer",
                    )

                    print(OPTIMAL_RANGES_YIELD.head())
                logging.info("YIELD RANGES END FINAL")
                # return OPTIMAL_RANGES_YIELD
                # OPTIMAL_RANGES_YIELD.to_excel("")

            # ----------------------------------- CT -----------------------------------
            elif tgt[0].lower().__contains__("duration") or tgt[1].lower().__contains__(
                "duration"
            ):
                logging.info("INSIDE CT")
                count_tgt += 1
                feature_list = df.columns.tolist()
                final_features = []
                for i in df[feature_list]:
                    if (
                        len(df[feature_list][i].unique()) > 5
                    ):  # {{{ Earlier it was 5 }}}
                        final_features.append(i)
                df21 = pd.DataFrame()
                list15 = []
                for j in feature_imp_sorted["FEATURES"][
                    feature_imp_sorted["FEATURES"].isin(final_features)
                ]:
                    if tgt[0].lower().__contains__("duration"):
                        list15.append(
                            self.plot_pdp_OEE(
                                rf_random.estimators_[0].best_estimator_,
                                df[feature_list],
                                feature=j,
                            )
                        )
                        df21 = df21.append(
                            self.plot_pdp_OEE(
                                rf_random.estimators_[0].best_estimator_,
                                df[feature_list],
                                feature=j,
                            )
                        )
                    elif tgt[1].lower().__contains__("duration"):
                        list15.append(
                            self.plot_pdp_OEE(
                                rf_random.estimators_[1].best_estimator_,
                                df[feature_list],
                                feature=j,
                            )
                        )
                        df21 = df21.append(
                            self.plot_pdp_OEE(
                                rf_random.estimators_[1].best_estimator_,
                                df[feature_list],
                                feature=j,
                            )
                        )
                df21.rename(
                    columns={
                        0: "Range_1",
                        1: "Y1",
                        2: "X1",
                        3: "H1",
                        4: "Range_2",
                        5: "Y2",
                        6: "X2",
                        7: "H2",
                    },
                    inplace=True,
                )

                logging.info("CT RANGES END")

                # Calculating one point before and after X1
                if "H2" in df21.columns:
                    df21["H2 - H1"] = df21["H2"] - df21["H1"]
                    df21["X2 - X1"] = df21["X2"] - df21["X1"]

                    # Checking if the curve is concave or convex
                    try:
                        df21["Graph"] = 0
                        for i in range(df11.shape[0]):
                            if df21["H2 - H1"][i] > df21["X2 - X1"][i]:
                                df21["Graph"].iloc[i] = "Convex"
                            elif df21["H2 - H1"][i] < df21["X2 - X1"][i]:
                                df21["Graph"].iloc[i] = "Concave"
                            else:
                                df21["Graph"].iloc[i] = "NA"
                    except:
                        print("Convex / Concave graphs not present")

                    try:
                        for i in range(df21.shape[0]):
                            if df21["Graph"].iloc[i] == "Convex":
                                if df21["Y2"].iloc[i] > df21["Y1"].iloc[i]:
                                    df21["Range_1"].iloc[i] = df21["Range_2"].iloc[i]
                            else:
                                if df21["Y2"].iloc[i] < df21["Y1"].iloc[i]:
                                    df21["Range_1"].iloc[i] = df21["Range_2"].iloc[i]
                    except:
                        print("Cannot get optimal ranges")
                    df22 = df21.rename(columns={"Range_1": "OPTIMAL_RANGES_CT"})

                    # Merging optimal ranges with feature_imp_sorted list
                    OPTIMAL_RANGES_CT = feature_imp_sorted.merge(
                        df22.iloc[:, 0:1],
                        left_on="FEATURES",
                        right_on=df22.index,
                        how="outer",
                    )
                    print(OPTIMAL_RANGES_CT.head())

                else:
                    df22 = df21.rename(columns={"Range_1": "OPTIMAL_RANGES_CT"})

                    # Merging optimal ranges with feature_imp_sorted list
                    OPTIMAL_RANGES_CT = feature_imp_sorted.merge(
                        df22.iloc[:, 0:1],
                        left_on="FEATURES",
                        right_on=df22.index,
                        how="outer",
                    )
                    print(OPTIMAL_RANGES_CT.head())

                logging.info("CT RANGES END_FINAL")

        logging.info("COUNT LOOP")
        logging.info(count_tgt)

        combined_ranges = pd.merge(
            right=OPTIMAL_RANGES_CT, left=OPTIMAL_RANGES_YIELD, on="Features"
        )
        if len(tgt) > 1:
            combined_ranges.drop(["YEILD_SCORES", "CT_SCORES"], axis=1, inplace=True)
        elif len(tgt) == 1:
            if tgt[0].lower().__contains("yield"):
                combined_ranges.drop(["YEILD_SCORES"], axis=1, inplace=True)
            elif tgt[0].lower().__contains("duration"):
                combined_ranges.drop(["CT_SCORES"], axis=1, inplace=True)
        # combined_ranges["Min"] = combined_ranges["Min"].astype('str')
        # combined_ranges["Max"] = combined_ranges["Max"].astype('str')
        combined_ranges["OPTIMAL_RANGES_CT"] = combined_ranges[
            "OPTIMAL_RANGES_CT"
        ].astype("str")
        combined_ranges["OPTIMAL_RANGES_YIELD"] = combined_ranges[
            "OPTIMAL_RANGES_YIELD"
        ].astype("str")
        combined_ranges.head(10)

        combined_ranges = self.calculate_Actual_Ranges_From_RAWDATA(
            df, feature_imp_sorted
        )

        # Merging the optimal ranges of Yield and CT

        merged_ranges = []
        for i in range(0, combined_ranges.shape[0]):
            # Both has Below ranges present
            if (
                combined_ranges["OPTIMAL_RANGES_CT"][i].split()[0] == "Below"
                and combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[0] == "Below"
            ):
                if float(combined_ranges["OPTIMAL_RANGES_CT"][i].split()[1]) < float(
                    combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[1]
                ):
                    range1 = (
                        combined_ranges["ACTUAL_RANGES_FROM_FLAT_FILE"][i].split()[0]
                        + " to "
                        + combined_ranges["OPTIMAL_RANGES_CT"][i].split()[1]
                    )
                    merged_ranges.append(range1)
                else:
                    range1 = (
                        combined_ranges["ACTUAL_RANGES_FROM_FLAT_FILE"][i].split()[0]
                        + " to "
                        + combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[1]
                    )
                    merged_ranges.append(range1)

            # Both has above ranges present
            elif (
                combined_ranges["OPTIMAL_RANGES_CT"][i].split()[0] == "Above"
                and combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[0] == "Above"
            ):
                if float(combined_ranges["OPTIMAL_RANGES_CT"][i].split()[1]) > float(
                    combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[1]
                ):
                    range1 = (
                        combined_ranges["OPTIMAL_RANGES_CT"][i].split()[1]
                        + " to "
                        + combined_ranges["ACTUAL_RANGES_FROM_FLAT_FILE"][i].split()[2]
                    )
                    merged_ranges.append(range1)
                else:
                    range1 = (
                        combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[1]
                        + " to "
                        + combined_ranges["ACTUAL_RANGES_FROM_FLAT_FILE"][i].split()[2]
                    )
                    merged_ranges.append(range1)

            # CT has Above ranges and Yield has Below ranges
            elif (
                combined_ranges["OPTIMAL_RANGES_CT"][i].split()[0] == "Above"
                and combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[0] == "Below"
            ):
                if float(combined_ranges["OPTIMAL_RANGES_CT"][i].split()[1]) < float(
                    combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[1]
                ):
                    range1 = (
                        combined_ranges["OPTIMAL_RANGES_CT"][i].split()[1]
                        + " to "
                        + combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[1]
                    )
                    merged_ranges.append(range1)
                else:
                    merged_ranges.append("Check PDPbox")

            # CT has Below ranges and Yield has Above ranges
            elif (
                combined_ranges["OPTIMAL_RANGES_CT"][i].split()[0] == "Below"
                and combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[0] == "Above"
            ):
                if float(combined_ranges["OPTIMAL_RANGES_CT"][i].split()[1]) > float(
                    combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[1]
                ):
                    range1 = (
                        combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[1]
                        + " to "
                        + combined_ranges["OPTIMAL_RANGES_CT"][i].split()[1]
                    )
                    merged_ranges.append(range1)
                else:
                    merged_ranges.append("Check PDPbox")

            # Yield ranges has NAN present
            elif (combined_ranges["OPTIMAL_RANGES_CT"][i].split()[0] == "Below") and (
                combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[0]
            ) == "nan":
                range1 = (
                    combined_ranges["ACTUAL_RANGES_FROM_FLAT_FILE"][i].split()[0]
                    + " to "
                    + combined_ranges["OPTIMAL_RANGES_CT"][i].split()[1]
                )
                merged_ranges.append(range1)
            elif (combined_ranges["OPTIMAL_RANGES_CT"][i].split()[0] == "Above") and (
                combined_ranges["Optimal Ranges_Yield"][i].split()[0]
            ) == "nan":
                range1 = (
                    combined_ranges["OPTIMAL_RANGES_CT"][i].split()[1]
                    + " to "
                    + combined_ranges["ACTUAL_RANGES_FROM_FLAT_FILE"][i].split()[2]
                )
                merged_ranges.append(range1)

            # CT ranges has NAN present
            elif (
                combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[0] == "Below"
            ) and (combined_ranges["OPTIMAL_RANGES_CT"][i].split()[0]) == "nan":
                range1 = (
                    combined_ranges["ACTUAL_RANGES_FROM_FLAT_FILE"][i].split()[0]
                    + " to "
                    + combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[1]
                )
                merged_ranges.append(range1)
            elif (
                combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[0] == "Above"
            ) and (combined_ranges["OPTIMAL_RANGES_CT"][i].split()[0]) == "nan":
                range1 = (
                    combined_ranges["OPTIMAL_RANGES_YIELD"][i].split()[1]
                    + " to "
                    + combined_ranges["ACTUAL_RANGES_FROM_FLAT_FILE"][i].split()[2]
                )
                merged_ranges.append(range1)

            else:
                merged_ranges.append("Check PDPbox")

            combined_ranges["Common_Ranges"] = pd.DataFrame(merged_ranges)
            logging.info("COMBINED RANGES")
            logging.info(combined_ranges.head())
            print(combined_ranges.head())
            return combined_ranges

    def No_of_Batches2(self, df, ranges_df):
        copy_new_df = ranges_df.copy()

        if "YEILD_SUGGESTED_RANGES" in copy_new_df.columns:
            ranges_col = "YEILD_SUGGESTED_RANGES"
        elif "CT_SUGGESTED_RANGES" in copy_new_df.columns:
            ranges_col = "CT_SUGGESTED_RANGES"

        copy_new_df["BATCHES_IN_ACTUAL_DATA_FROM_SUGGESTED_RANGE"] = 0
        copy_new_df["ACTUAL_RANGES_IN_WHICH_BATCHES_RUN"] = "NA"
        for index, row in ranges_df.iterrows():
            featurename = row["FEATURES"]
            minbatchinraw = df[featurename].min()
            maxbatchinraw = df[featurename].max()
            logging.info("INSIDE_NO_OF_BATCHES")
            logging.info(row[ranges_col])
            print(row[ranges_col])
            if "Above" in str(row[ranges_col]):
                minvalue = float(str(row[ranges_col]).split()[1])
                maxvalue = maxbatchinraw
            elif "Below" in str(row[ranges_col]):
                maxvalue = float(str(row[ranges_col]).split()[1])
                minvalue = minbatchinraw
            elif "to" in str(row[ranges_col]):
                minvalue = float(str(row[ranges_col]).split("to")[0])
                maxvalue = float(str(row[ranges_col]).split("to")[1])
            elif "nan" in str(row[ranges_col]):
                continue

            actualRangeinBatch = (
                str(round(minbatchinraw, 3)) + " to " + str(round(maxbatchinraw, 3))
            )
            #     print('actualRangeinBatch is : ',actualRangeinBatch)
            count = 0
            for index1, row1 in df.iterrows():
                if float(row1[featurename]) >= minvalue and float(
                    row1[featurename] <= maxvalue
                ):
                    count = count + 1

            copy_new_df.at[index, "BATCHES_IN_ACTUAL_DATA_FROM_SUGGESTED_RANGE"] = count
            copy_new_df.at[
                index, "ACTUAL_RANGES_IN_WHICH_BATCHES_RUN"
            ] = actualRangeinBatch

        copy_new_df["BATCHES_IN_ACTUAL_DATA_FROM_SUGGESTED_RANGE_PERCENT"] = (
            copy_new_df["BATCHES_IN_ACTUAL_DATA_FROM_SUGGESTED_RANGE"] / df.shape[0]
        ) * 100

        return copy_new_df
