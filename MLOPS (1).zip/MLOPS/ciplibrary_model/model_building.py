import yaml
import pandas as pd
import numpy as np
import os
import seaborn as sns
from tqdm import tqdm
import warnings
warnings.simplefilter("ignore")
import matplotlib.dates as mdates
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.multioutput import MultiOutputRegressor
from sklearn.inspection import PartialDependenceDisplay
warnings.simplefilter("ignore")
from sklearn.linear_model import ElasticNet, ElasticNetCV
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error, make_scorer
from sklearn import preprocessing
from sklearn.metrics import r2_score
import re
import shap
from sklearn.model_selection import train_test_split
import itertools
from operator import mul
from functools import reduce
import statsmodels.api as sm
from matplotlib import pyplot as plt
from pdpbox import pdp, info_plots
import pandas_profiling as pp
import matplotlib.backends.backend_pdf
from matplotlib.backends.backend_pdf import PdfPages
import colorama
from colorama import Fore
from pandas import ExcelWriter
from datetime import datetime
import xlwt
import os
import logging
import traceback
from ciplibrary_model.PDP_Plot_Code import PDP_Plot_Ranges
from ciplibrary_model.plots import plots
pd.set_option('display.max_rows', 1000)
pd.set_option('display.max_columns', None)

class ml_model:
    
    def rmse_calc(predictions,test_labels):
            return np.sqrt(((predictions - test_labels) ** 2).mean())
    
    def evaluate(model, test_features, test_labels):
                global mape,accuracy,rmse,r2
                predictions = model.predict(test_features)
                errors = abs(predictions - test_labels)
                mape = 100 * np.mean(errors / test_labels)
                accuracy = 100 - mape
                rmse = rmse_calc(predictions, test_labels)
                r2 = r2_score(test_labels, predictions)
                print('Model Performance')
                print('Average Error:',np.mean(errors))
                print('RMSE:', rmse)
                print('Accuracy:', accuracy)
                print('MAPE:',mape)
                print('r2:',r2)
                print('Min and Max errors: ', errors.min(), errors.max())
                return mape,accuracy,rmse,r2

#     def rmse_calc(predictions,test_labels):
#             return np.sqrt(((predictions - test_labels) ** 2).mean())



#-------------------------------------------------------------------- Model Building --------------------------------------------------------------------

    def model_building(self,df,cv,random_state,niter,tgt,test_size,output_file_name,book,OUTPUT_DIR,sub_file_name,v1,dt,sql_logs,substage=None):
            logging.info('(Model_building.py) --> (model_building()) --> { Inside Model BUidling model_building() method}')
            self.df=df
            global rf_random, model
            print('INSIDE MODEL BUILDING')
            print(self.df.shape)
            logging.info('INSIDE MODEL BUILDING')
            logging.info(self.df.shape)
            #importing libraries
            
            from sklearn.model_selection import KFold
            from sklearn.model_selection import cross_val_score
            from xgboost import XGBRegressor
            from sklearn.model_selection import GridSearchCV
            import pickle

            plot_obj = plots()
            pdp_object =  PDP_Plot_Ranges()
            #import SHAP

            """
            This Function will build a Random Forest Model on the passed dataframe

            Args:
                    The input data for this function is as per below, and make sure it must be passed in same order
                    (Dataframename, Number of Cross-Validations - cv, Number of Iterations - niter , Target Column Name , Test dataset size)
            Returns:
                    It will return below Items,
                    Model Performance Metrics - Avg Error,Accuracy,MAPE,R2,Min & Max Errors
                    Feature Importance Bar Plot
                    Trained Model stored in Variable
            Usage Example:
                    performance,feature,feature_plot,model = yfs.build_RF(data,5,250,'duration_in_mins',0.30)
            """
            # {{{ DO we need this or not}}}
        #     if v1.stage=='Compression':
        #         if v1.var_tobe_excluded!=" "or v1.var_tobe_excluded!="NA" or v1.var_tobe_excluded!=[]: 
        #             self.df.drop(v1.var_tobe_excluded, axis = 1, inplace = True)
        #         else:
        #             pass;
        #     else:
        #         pass;
            #Final_model_list = []
        #     Final_model_df = pd.DataFrame(columns = ["Model_Name","Test_Split_size","Crossed_validation","No_Iteraions", "Random_State", "Train_Accuracy","Test_Accuracy", "Train_rmse", "Test_rmse"])
            def rmse_calc(predictions,test_labels):
                    return np.sqrt(((predictions - test_labels) ** 2).mean())
            def evaluate(model, test_features, test_labels):
                    #global mape,accuracy,rmse,r2
                    predictions = model.predict(test_features)
                    errors = abs(predictions - test_labels)
                    mape = 100 * np.mean(errors / test_labels)
                    accuracy = 100 - mape
                    rmse = rmse_calc(predictions, test_labels)
                    r2 = r2_score(test_labels, predictions)
                    print('Model Performance')
                    print('Average Error:',np.mean(errors))
                    print('RMSE:', rmse)
                    print('Accuracy:', accuracy)
                    print('MAPE:',mape)
                    print('r2:',r2)
                    print('Min and Max errors: ', errors.min(), errors.max())
                    return mape,accuracy,rmse,r2,errors
            count12 = 0
            if len(tgt) > 1:
                Final_model_df = pd.DataFrame(columns=["Model_Name",'Test_Split_size',"Crossed_validation","No_Iteraions", 'Random_State', 'Estimator','Train_Accuracy_Yield','Train_Accuracy_OEE','Test_Accuracy_Yield','Test_Accuracy_OEE','Train_rmse_Yeild','Train_rmse_OEE','Test_rmse_Yield','Test_rmse_OEE'])
            elif len(tgt) == 1:
                Final_model_df = pd.DataFrame(columns=["Model_Name",'Test_Split_size',"Crossed_validation","No_Iteraions", 'Random_State', 'Estimator','Train_Accuracy','Test_Accuracy', 'Train_rmse', 'Test_rmse'])
            print(Final_model_df.shape)
            for test_size in test_size:
                    for cv in cv:
                            for niter in niter:
                                    for rs in random_state:
                                        #     print('Inside Random state,',rs)
                                            train, test = train_test_split(self.df,test_size=test_size, random_state=rs)
                                            xtrain = train[train.columns.difference(tgt)]
                                            print('XTRAIN COLUMNS')
                                            print(xtrain.shape)
                                            print(xtrain.columns)                                        
                                            xtest = test[test.columns.difference(tgt)]
                                            logging.info('printing xtest Data is : ')
                                            logging.info(xtest)
                                            ytrain = train[tgt]
                                            print('YTRAIN COLUMNS')
                                            print(ytrain.shape)
                                            ytest = test[tgt]
                                            print(xtest.shape)
                                            print(ytest.shape)

                                            for model_name in v1.model_names:
                                                    if model_name=='rf':
                                                            count12 = count12+1
                                                            # print('Inside Model Name++++++')
                                                            logging.info('(Model_building.py) --> (model_building()) --> { Building Random Forest Modelcusing Randamized search cv}')
                                                            n_estimators = [int(x) for x in np.linspace(start = 300, stop = 400, num = 10)]
                                                            max_features = ['auto', 'sqrt']
                                                            max_depth = [3,4,5]
                                                            min_samples_split = [2,3]
                                                            min_samples_leaf = [2,3,4,5]
                                                            bootstrap = [True, False]
                                                            random_grid = {#'n_estimators': n_estimators,
                                                                #     'max_features': max_features,
                                                                    'max_depth': max_depth,
                                                                #     'min_samples_split': min_samples_split,
                                                                    'min_samples_leaf': min_samples_leaf
                                                                #     'bootstrap': bootstrap
                                                                        }
                                                            rf = RandomForestRegressor()
                                                        #     rf = MultiOutputRegressor(rf1)
                                                            # print(rf)
                                                            rf_random = MultiOutputRegressor(RandomizedSearchCV(estimator = rf, param_distributions = random_grid, n_iter = niter, cv = cv, verbose=2, random_state=rs, n_jobs = -1))
                                                            logging.info("Printing the Xtrain")
                                                            logging.info(xtrain)
                                                            rf_random.fit(xtrain,ytrain)
                                                            estimator = rf_random
                                                            print("--------+++++++++_--------------------")
                                                            logging.info('ESTIMATOR')
                                                            logging.info(estimator)
                                                            print(estimator)
                                                        #     #-----Exporting the model
                                                        #     import pickle
                                                        #     pickle.dump(rf_random,open(os.path.join(OUTPUT_DIR,'model.pkl'), 'wb'))
                                                            
                                                            # exporting done 
                                                            test_mape,test_accuracy,test_rmse,test_r2,test_errors= evaluate(rf_random, xtest,ytest[tgt] )
                                                            
                                                            train_mape,train_accuracy,train_rmse,train_r2,test_errors= evaluate(rf_random, xtrain,ytrain[tgt] )

                                                            print('COMBINATION EVALUATION DONE')
                                                            #Dataframe creation

                                                            #"Model_Name","Test_Split_size","Crossed_validation","No_Iteraions", "Random_State", "Train_Accuracy","Test_Accuracy", "Train_rmse", "Test_rmse"
                                                            if len(tgt) > 1:
                                                                new_row = {"Model_Name":[model_name],'Test_Split_size':[test_size],"Crossed_validation":[cv],"No_Iteraions":[niter], 'Random_State':[rs], 'Estimator':[estimator],'Train_Accuracy_Yield':[train_accuracy[0]],'Train_Accuracy_OEE':[train_accuracy[1]],'Test_Accuracy_Yield':[test_accuracy[0]],'Test_Accuracy_OEE':[test_accuracy[1]], 'Train_rmse_Yeild':[train_rmse[0]], 'Train_rmse_OEE':[train_rmse[1]], 'Test_rmse_Yield':[test_rmse[0]], 'Test_rmse_OEE':[test_rmse[1]]}
                                                                print(new_row)
                                                                print('==============')
                                                                logging.info('(Model_building.py) --> (model_building()) --> { New Rows is : %s }' , new_row)
                                                                interm_df = pd.DataFrame(new_row)
                                                                logging.info("INtermm DFF")
                                                                logging.info(interm_df.shape)
                                                                print("INtermm DFF",interm_df.shape)
                                                                print(Final_model_df.shape)
                                                                #Final_model_list.append(interm_df)
                                                                Final_model_df = Final_model_df.append(interm_df)
                                                                print(Final_model_df.shape)
                                                            #     print(Final_model_df.columns)      
                                                            #     Final_model_df.to_csv(os.path.join(OUTPUT_DIR,'Model_check.csv'))

                                                            elif len(tgt) == 1:
                                                                new_row = {"Model_Name":[model_name],'Test_Split_size':[test_size],"Crossed_validation":[cv],"No_Iteraions":[niter], 'Random_State':[rs], 'Estimator':[estimator],'Train_Accuracy':[train_accuracy[0]],'Test_Accuracy':[test_accuracy[0]], 'Train_rmse':[train_rmse[0]], 'Test_rmse':[test_rmse[0]]}
                                                                print(new_row)

                                                                logging.info('(Model_building.py) --> (model_building()) --> { New Rows is : %s }' , new_row)
                                                                interm_df = pd.DataFrame(new_row)
                                                                logging.info("INtermm DFF")
                                                                logging.info(interm_df.shape)
                                                                print("INtermm DFF",interm_df.shape)
                                                                print(Final_model_df.shape)
                                                                #Final_model_list.append(interm_df)
                                                                Final_model_df = Final_model_df.append(interm_df)
                                                                print(Final_model_df.shape)
                                                                # print(Final_model_df)
                                                            print('###Finish###')
                                                            logging.info('(Model_building.py) --> (model_building()) --> { ###########FINISH############ }')
            
            print('Final Model Building START')
            # print(Final_model_df)
            print('-----------------------')
            if len(tgt) > 1:
                print('Inside_double_target')
                Final_model_df = Final_model_df.sort_values(['Test_Accuracy_Yield','Test_Accuracy_OEE','Test_rmse_Yield','Test_rmse_OEE'],
                                                        ascending = [False,False,True,True])
                
                print("++++++++START++++++++++++" , count12)
                print(Final_model_df)
                print("+++++++++++END+++++++++")
                # Final model with best accuracy
                Final_df=Final_model_df.copy()
                test_size = Final_df.iloc[0,1]
                cv=Final_df.iloc[0,2]
                niter=Final_df.iloc[0,3]
                random_state = Final_df.iloc[0,4]

            #     print('after DF')   
                sheet_name='AA_Model_Results'+sub_file_name

                book=dt.create_Sheet(book,sheet_name,Final_df)
                #book.save(output_file_name)
                #writer.save()
                #print('\033[92m' + '\033[1m' +"AA model results have been saved in the path: "+self.output_path+ '\033[0m')
                logging.info('(Model_building.py) --> (model_building()) --> { Train Test Split}')
                #print(train_acc)
                train, test = train_test_split(self.df,test_size=test_size, random_state=random_state)
                xtrain = train[train.columns.difference(tgt)]
                xtest = test[test.columns.difference(tgt)]
                ytrain = train[tgt]
                ytest = test[tgt]          
            #     rf_random = RandomizedSearchCV(estimator = rf, param_distributions = random_grid, n_iter = niter, cv = cv, verbose=2, random_state=random_state, n_jobs = -1)
            #     print('Before RandomForest')
                rf_random = Final_df.iloc[0,5]
            #     rf = RandomForestRegressor()
            #     rf_random = MultiOutputRegressor(RandomizedSearchCV(estimator = rf, param_distributions = {'max_depth': [3,4,5]}, n_iter = 50,cv=10,verbose=2, n_jobs = -1))
            #     rf_random = rf_random.fit(xtrain,ytrain)
                print('Model is: ', rf_random)
                import pickle
                pickle.dump(rf_random,open(os.path.join(OUTPUT_DIR,'model.pkl'), 'wb'))

                test_mape,test_accuracy,test_rmse,test_r2,test_errors=evaluate(rf_random, xtest,ytest[tgt] )
                train_mape,train_accuracy,train_rmse,train_r2,test_errors=evaluate(rf_random, xtrain,ytrain[tgt] )
                print('FINAL EVALUATION DONE')
                features = xtrain.columns.tolist()
            #     importances = rf.feature_importances_
                importances_yield = abs(rf_random.estimators_[0].best_estimator_.feature_importances_)
                importances_ct = abs(rf_random.estimators_[1].best_estimator_.feature_importances_)
                print('FEATURE IMPORTANCES')
            #     print(importances)
            #     indices = np.argsort(importances)
                feature_imp = pd.DataFrame({'FEATURES':features,'CT_SCORES':importances_ct,'YEILD_SCORES':importances_yield})
                print('Feature Imp:')
                feature_imp["CT_SCORES"] = round(feature_imp["CT_SCORES"]*100, 3)
                feature_imp["YEILD_SCORES"] = round(feature_imp["YEILD_SCORES"]*100, 3)
                feature_imp_sorted = feature_imp.sort_values(['YEILD_SCORES','CT_SCORES'], ascending = [False,False])
                feature_imp_sorted.reset_index(inplace=True)
                print(feature_imp_sorted)

                ct_sorted = feature_imp_sorted.sort_values(by=['CT_SCORES'],ascending=False)
                yeild_sorted = feature_imp_sorted.sort_values(by=['YEILD_SCORES'],ascending=False)

                sheet_name="Feature_imp_ALL"+sub_file_name
                yeild_sorted['PRODUCTCODE'] = v1.product_code
                yeild_sorted['PRODUCTNAME'] = v1.product_name
            #     feature_imp_sorted['MODEL_REFINED_COUNT'] = sql_logs.REFINED_COUNT
                yeild_sorted['DATETIME'] = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
                yeild_sorted['MODEL_SUGGESTED_RANGES'] = 'NA'
                yeild_sorted = pdp_object.calculate_Actual_Ranges_From_RAWDATA(self.df,yeild_sorted)
                yeild_sorted.to_csv(os.path.join(OUTPUT_DIR,sheet_name+'.csv'))
                book=dt.create_Sheet(book,sheet_name,yeild_sorted)

                # sheet_name="Feature_imp_OEE_"+sub_file_name
                ct_sorted['PRODUCTCODE'] = v1.product_code
                ct_sorted['PRODUCTNAME'] = v1.product_name
            #     feature_imp_sorted['MODEL_REFINED_COUNT'] = sql_logs.REFINED_COUNT
                ct_sorted['DATETIME'] = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
                ct_sorted['MODEL_SUGGESTED_RANGES'] = 'NA'
                ct_sorted = pdp_object.calculate_Actual_Ranges_From_RAWDATA(self.df,ct_sorted)
                ct_sorted.to_csv(os.path.join(OUTPUT_DIR,sheet_name+'.csv'))
                # book=dt.create_Sheet(book,sheet_name,ct_sorted)

                sql_logs.ACCURACY_TRAIN = 'Yeild : '+str(train_accuracy[0]),'OEE : '+str(train_accuracy[1])
                sql_logs.RMSE_TRAIN = 'Yeild : '+str(train_rmse[0]),'OEE : '+str(train_rmse[1])    
                sql_logs.ACCURACY_TEST = 'Yeild : '+str(test_accuracy[0]),'OEE : '+str(test_accuracy[1])
                sql_logs.RMSE_TEST = 'Yeild : '+str(test_rmse[0]),'OEE : '+str(test_rmse[1])
                print("Feature_importance: "+sub_file_name,feature_imp_sorted)
                logging.info("Feature_importance: "+sub_file_name)
                logging.info(feature_imp)

                ########## PDP ####################

                plot_obj.make_pdp(feature_imp_sorted,yeild_sorted,ct_sorted,xtrain,ytrain,output_file_name,OUTPUT_DIR,rf_random)
                
                ##########################################

            elif len(tgt) == 1:
                print('Inside_single_target')
                Final_model_df = Final_model_df.sort_values(['Test_Accuracy', 'Test_rmse'],
                                                     ascending = [False, True])
            
                print("++++++++START++++++++++++" , count12)
                print(Final_model_df)
                print("+++++++++++END+++++++++")
                # Final model with best accuracy
                Final_df=Final_model_df.copy()
                test_size = Final_df.iloc[0,1]
                cv=Final_df.iloc[0,2]
                niter=Final_df.iloc[0,3]
                random_state = Final_df.iloc[0,4]

                sheet_name='AA_Model_Results'+sub_file_name

                book=dt.create_Sheet(book,sheet_name,Final_df)
                #print('\033[92m' + '\033[1m' +"AA model results have been saved in the path: "+self.output_path+ '\033[0m')
                logging.info('(Model_building.py) --> (model_building()) --> { Train Test Split}')
                #print(train_acc)
                train, test = train_test_split(self.df,test_size=test_size, random_state=random_state)
                xtrain = train[train.columns.difference(tgt)]
                xtest = test[test.columns.difference(tgt)]
                ytrain = train[tgt].round(2)
                ytest = test[tgt].round(2)
                rf_random = Final_df.iloc[0,5]
                # rf_random = rf.fit(xtrain,ytrain)
                print('Model is: ', rf_random)
                import pickle
                pickle.dump(rf_random,open(os.path.join(OUTPUT_DIR,'model.pkl'), 'wb'))

                test_mape,test_accuracy,test_rmse,test_r2,test_errors=evaluate(rf_random, xtest,ytest[tgt] )
                train_mape,train_accuracy,train_rmse,train_r2,test_errors=evaluate(rf_random, xtrain,ytrain[tgt] )

                features = xtrain.columns.tolist()
                if tgt[0].lower().__contains__('yield'):
                    importances = rf_random.estimators_[0].best_estimator_.feature_importances_
                    indices = np.argsort(importances)
                    feature_imp = pd.DataFrame({'FEATURES':features,'YEILD_SCORES':importances})
                    feature_imp_sorted = feature_imp.sort_values('YEILD_SCORES', inplace = False, ascending=False)
                elif tgt[0].lower().__contains__('duration'):
                    importances = rf_random.estimators_[0].best_estimator_.feature_importances_
                    indices = np.argsort(importances)
                    feature_imp = pd.DataFrame({'FEATURES':features,'CT_SCORES':importances})
                    feature_imp_sorted = feature_imp.sort_values('CT_SCORES', inplace = False, ascending=False)
                feature_imp_sorted.reset_index(inplace=True)

                sql_logs.ACCURACY_TRAIN = train_accuracy
                sql_logs.RMSE_TRAIN = train_rmse    
                sql_logs.ACCURACY_TEST = test_accuracy
                sql_logs.RMSE_TEST = test_rmse
                print("Feature_importance: "+sub_file_name,feature_imp_sorted)
                logging.info("Feature_importance: "+sub_file_name)
                logging.info(feature_imp_sorted)
                #creating empty lists
                yeild_sorted=[]
                ct_sorted=[]

                sheet_name="Feature_imp"+sub_file_name
                feature_imp_sorted['PRODUCTCODE'] = v1.product_code
                feature_imp_sorted['PRODUCTNAME'] = v1.product_name
            #     feature_imp_sorted['MODEL_REFINED_COUNT'] = sql_logs.REFINED_COUNT
                feature_imp_sorted['DATETIME'] = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
                feature_imp_sorted['MODEL_SUGGESTED_RANGES'] = 'NA'
                feature_imp_sorted = pdp_object.calculate_Actual_Ranges_From_RAWDATA(self.df,feature_imp_sorted)
                feature_imp_sorted.to_csv(os.path.join(OUTPUT_DIR,sheet_name+'.csv'))
                book=dt.create_Sheet(book,sheet_name,feature_imp_sorted)
                ########## PDP ####################

                plot_obj.make_pdp(feature_imp_sorted,yeild_sorted,ct_sorted,xtrain,ytrain,output_file_name,OUTPUT_DIR,rf_random)
            
                ##########################################
            
        ###################################CREATING PDP PLots OBJECT##################################################
            

            

             ###################################Calling PDP PLots##################################################
            ### UNCOMMENT BELOW CODE BLOCK
            
            try:           
                    # ranges_df = pdp_object.Get_PDP_Ranges_optimized(feature_imp_sorted,rf_random,v1.use_case,xtrain,tgt)
                    if len(tgt)>1:
                        logging.info('INSIDE MULTI')
                        ranges_df_yield = pdp_object.pdpRanges(feature_imp_sorted,rf_random.estimators_[0].best_estimator_,xtrain,isYield=True)
                        ranges_df_ct = pdp_object.pdpRanges(feature_imp_sorted,rf_random.estimators_[1].best_estimator_,xtrain,isYield=False)
                        ranges_df = ranges_df_yield.merge(ranges_df_ct,on=['FEATURES'])
                    elif len(tgt)==1:
                        isYield = np.where(tgt[0].lower().__contains__('yield'),True,False)
                        ranges_df = pdp_object.pdpRanges(feature_imp_sorted,rf_random.estimators_[0].best_estimator_,xtrain,isYield)
                    ranges_df['PRODUCTCODE'] = v1.product_code
                    ranges_df['PRODUCTNAME'] = v1.product_name
                    # ranges_df['MODEL_REFINED_COUNT'] = sql_logs.REFINED_COUNT
                    ranges_df['DATETIME'] = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
                    print('------------Ranges-----------------')
                    print(ranges_df)
                    logging.info("------------Ranges---------------------")
                    logging.info(ranges_df)
                    ranges_df = pdp_object.No_of_Batches2(self.df,ranges_df)
                    sheet_name = 'all_optimized'
                    if substage != None:
                            if substage == 0:
                                    sheet_name = 'Drying'
                            elif substage == 1:
                                    sheet_name = 'Spraying'
                            elif substage == 2:
                                    sheet_name = 'PreHeating'
                                            
                    try:
                            book=dt.create_Sheet(book,"PDP_Ranges_"+sheet_name,ranges_df)
                    except Exception as error:
                            logging.error('(model_building.py) --> () --> Error in Creating the Sheet For PDP Ranges')
                            traceback.print_exc()
            except Exception as error:
                    print(error)
                    logging.info("Exception For PDP Plots")
                    logging.error('(model_building.py) --> () --> Error in PDP Plot Ranges')
                    logging.info(error)
                    logging.info(traceback.print_exc())
                    traceback.print_exc()
                    pass
            
            
            book.save(OUTPUT_DIR+'\\'+output_file_name+"_"+v1.date_string+'.xls')
            ######################################################################################################
            plt.figure(figsize = (12, 16))
            feature_imp_sorted.set_index('FEATURES', inplace=True)
            b = feature_imp_sorted.plot(kind = 'bar', figsize = (10,4))
        #     model = rf_random.best_estimator_

          
            #####################################SHAP to PDF Working##################################
            
            ###########SHAP to PDF function#############
                                          
            plot_obj = plots()
            plot_obj.make_shap(rf_random,xtrain,ytrain,output_file_name,tgt,OUTPUT_DIR)

            ######################################

            logging.info('(Model_building.py) --> (model_building()) --> { SHap to PDF Working }')
            ########## PDP ####################

            # plot_obj.make_pdp(yeild_sorted,ct_sorted,xtrain,ytrain,output_file_name,OUTPUT_DIR,rf_random)
            
            ##########################################
            print('MODEL BUILDING END')    
            return sql_logs