import yaml
import pandas as pd
import numpy as np
import os
import seaborn as sns
from tqdm import tqdm
import warnings

warnings.simplefilter("ignore")
import matplotlib.dates as mdates
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier

warnings.simplefilter("ignore")
from sklearn.linear_model import ElasticNet, ElasticNetCV
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error, make_scorer
from sklearn import preprocessing
from sklearn.metrics import r2_score
import re
import shap
from sklearn.model_selection import train_test_split
import itertools
from operator import mul
from functools import reduce
import statsmodels.api as sm
from matplotlib import pyplot as plt
from pdpbox import pdp, info_plots

# import pandas_profiling as pp
import matplotlib.backends.backend_pdf
from matplotlib.backends.backend_pdf import PdfPages
import colorama
from colorama import Fore
from pandas import ExcelWriter
from datetime import datetime
import xlwt
import os
import logging
import traceback
from ciplibrary_model.utils import sort_df

pd.set_option("display.max_rows", 1000)
pd.set_option("display.max_columns", None)


class CoatingFn:
    def OEE_Coating_generator_2(self, df, book, v1, dt):
        logging.info(
            "Inside Coating_functions.py ---> OEE_Coating_FF_generator_2() ---> { Inside OEE_Coating_FF_generator_2() started} "
        )
        self.df = df
        global OEE_Gran_DRYING
        global OEE_Gran_SPRAYING
        global OEE_Gran_PREWARMING
        global OEE_Gran_AIRDRYING
        global OEE_Gran_DRYMIXING
        global OEE_Gran2
        # print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')

        OEE_Gran_DRYING = pd.DataFrame()
        OEE_Gran_SPRAYING = pd.DataFrame()
        OEE_Gran_PREWARMING = pd.DataFrame()
        no_spray = [
            "ATOMIZATION_AIR_SET",
            "ATOMIZATION_AIR_ACT",
            "SPRAY_RATE_ACT",
            "SPRAY_PUMP_RPM_ACT",
        ]

        if v1.preheating == "Y":
            temp_x = self.df[v1.activity].str.contains(
                "Preheating", case=False, na=False
            )
            temp_data = self.df[temp_x]
            print("\033[92m" + "\033[1m" + " Prewarming activities " + "\033[0m")
            print(temp_data[v1.activity].value_counts())
            OEE_Gran_PREWARMING = temp_data.copy()
            OEE_Gran_PREWARMING.drop(columns=[v1.activity], inplace=True)
            OEE_Gran_PREWARMING.set_index(v1.batch_id, drop=True, inplace=True)
            for col in no_spray:
                if col in OEE_Gran_PREWARMING.columns:
                    OEE_Gran_PREWARMING = OEE_Gran_PREWARMING.drop(columns=[col])
                else:
                    continue
            book = dt.create_Sheet(book, "OEE_Gran_PREWARMING", OEE_Gran_PREWARMING)

        if v1.spraying == "Y":
            temp_x = self.df[v1.activity].str.contains("Spraying", case=False, na=False)
            temp_data = self.df[temp_x]
            print("\033[92m" + "\033[1m" + " Spraying activities " + "\033[0m")
            print(temp_data[v1.activity].value_counts())
            OEE_Gran_SPRAYING = temp_data.copy()
            OEE_Gran_SPRAYING.drop(columns=[v1.activity], inplace=True)
            OEE_Gran_SPRAYING.set_index(v1.batch_id, drop=True, inplace=True)
            book = dt.create_Sheet(book, "OEE_Gran_SPRAYING", OEE_Gran_SPRAYING)

        if v1.drying == "Y":
            logging.info(
                "Inside Coating_functions.py ---> OEE_Coating_FF_generator_2() ---> { Please select the index DRYING stage , input the indices separated by single space } "
            )
            temp_x = self.df[v1.activity].str.contains("Drying", case=False, na=False)
            temp_data = self.df[temp_x]
            print("\033[92m" + "\033[1m" + " Drying activities " + "\033[0m")
            logging.info(
                "Inside Coating_functions.py ---> OEE_Coating_FF_generator_2() ---> { Drying activities %s } ",
                temp_data[v1.activity].value_counts(),
            )
            print(temp_data[v1.activity].value_counts())
            OEE_Gran_DRYING = temp_data.copy()
            OEE_Gran_DRYING.drop(columns=[v1.activity], inplace=True)
            OEE_Gran_DRYING.set_index(v1.batch_id, drop=True, inplace=True)
            for col in no_spray:
                if col in OEE_Gran_DRYING.columns:
                    OEE_Gran_DRYING = OEE_Gran_DRYING.drop(columns=[col])
                else:
                    continue

            book = dt.create_Sheet(book, "OEE_Gran_DRYING", OEE_Gran_DRYING)

        return OEE_Gran_DRYING, OEE_Gran_SPRAYING, OEE_Gran_PREWARMING

    def OEE_Coating_FF_generator_4(self, df, book, v1):
        logging.info(
            "Inside Coating_functions.py ---> OEE_Coating_FF_generator_3() ---> {  Inside  OEE_Coating_FF_generator_3() Started}"
        )
        self.df = df
        column_list = list(self.df.columns)
        for i, j in enumerate(column_list):
            print(i, j)

        logging.info(
            "Inside Coating_functions.py ---> OEE_Coating_FF_generator_3() ---> {  Below are the columns present in the passed data frame %s }",
            column_list,
        )
        print(self.df.head())
        logging.info("@@@@")
        logging.info(self.df.shape)
        print(self.df.shape)

        # df.reset_index(inplace=True)
        # Generating Cycle Time column
        print("Use_case is %%%%%%%", v1.use_case)
        if len(v1.target_column) < 2:
            multi_output = False
        else:
            multi_output = True

        if v1.use_case == "OEE" or v1.use_case == "ALL":
            oee_df = self.df.copy()
            oee_df = oee_df.reset_index()
            if not multi_output:
                oee_df = oee_df[[v1.batch_id, v1.target_column[0]]]
            else:
                oee_df = oee_df[[v1.batch_id, v1.target_column[0], v1.target_column[1]]]
            oee_df = oee_df.set_index(v1.batch_id)
            oee_df = oee_df.groupby(v1.batch_id).agg("mean")
            logging.info("Before duplicates in OEE")
            logging.info(oee_df.shape)
            print(oee_df.shape)
            # oee_df = oee_df.drop_duplicates()
            print("After duplicates")
            print(oee_df.shape)
            print("OEE DF :")
            # print(oee_df)

            features = self.df.describe().columns.to_list()
            if (
                v1.var_tobe_excluded != " "
                or v1.var_tobe_excluded != "NA"
                or v1.var_tobe_excluded != []
            ):
                for i in v1.var_tobe_excluded:
                    features = list(filter(lambda x: x != i, features))
                else:
                    features = self.df.describe().columns

            features = self.df.describe().columns.to_list()
            if not multi_output:
                features = list(filter(lambda x: x != v1.target_column[0], features))
            else:
                features = list(
                    filter(
                        lambda x: x not in [v1.target_column[0], v1.target_column[1]],
                        features,
                    )
                )
            print(
                "\033[92m"
                + "\033[1m"
                + "---------------------- Features ----------------------"
                + "\033[92m"
                + "\033[1m"
            )
            print(features)

            if v1.other["Recipe_Based"] == "Y":
                # print('Inside recipe based approach')
                for i in [
                    "0.05",
                    "0.1",
                    "0.15",
                    "0.2",
                    "0.25",
                    "0.3",
                    "0.35",
                    "0.4",
                    "0.45",
                    "0.5",
                    "0.55",
                    "0.6",
                    "0.65",
                    "0.7",
                    "0.75",
                    "0.8",
                    "0.85",
                    "0.9",
                    "0.95",
                ]:
                    globals()[f"features_{str(int(float(i)*100))}"] = eval(
                        "df.groupby(v1.batch_id)[features].quantile("
                        + i
                        + ").reset_index()"
                    )
                    globals()[f"features_{str(int(float(i)*100))}"] = globals()[
                        f"features_{str(int(float(i)*100))}"
                    ].set_index(v1.batch_id)
                    globals()[f"features_{str(int(float(i)*100))}"].columns = [
                        str(col) + "_" + (str(int(float(i) * 100)))
                        for col in globals()[
                            f"features_{str(int(float(i)*100))}"
                        ].columns
                    ]

                # print(features_5)
                # Feature df
                feature_df = features_5.reset_index().merge(
                    features_10.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_15.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_20.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_25.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_30.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_35.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_40.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_45.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_50.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_55.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_60.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_65.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_70.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_75.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_80.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_85.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_90.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_95.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(oee_df, on=[v1.batch_id])
                feature_df = feature_df.set_index(v1.batch_id)

                features = feature_df.columns.tolist()
                print("# of features ", features)

            else:
                for i in ["mean", "median", "min", "max", "mode"]:
                    if i != "mode":
                        globals()[f"{i}_features"] = eval(
                            "df.groupby(v1.batch_id)[features]."
                            + i
                            + "().reset_index()"
                        )
                        globals()[f"{i}_features"] = globals()[
                            f"{i}_features"
                        ].set_index(v1.batch_id)
                        globals()[f"{i}_features"].columns = [
                            str(col) + "_" + i
                            for col in globals()[f"{i}_features"].columns
                        ]
                    else:
                        mode_features = (
                            df.groupby(v1.batch_id)[features]
                            .apply(lambda x: x.mode().iloc[0])
                            .reset_index()
                        )
                        mode_features = mode_features.set_index(v1.batch_id)
                        mode_features.columns = [
                            str(col) + "_mod" for col in mode_features.columns
                        ]

                # print(mean_features)
                # Feature df
                feature_df = mean_features.reset_index().merge(
                    min_features.reset_index(), on=[v1.batch_id]
                )
                # print(feature_df)
                feature_df = feature_df.merge(
                    max_features.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    mode_features.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    median_features.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(oee_df, on=[v1.batch_id])
                feature_df = feature_df.set_index(v1.batch_id)

                features = feature_df.columns.tolist()
                print("# of features ", features)

            df2 = feature_df
            # feature_df.reset_index(inplace=True)
            # feature_df.rename(columns={'batch_id': v1.Batch_LOT }, inplace=True)

            ## Final Flat File Merging

            # df2 = feature_df.merge(time2,on=v1.Batch_LOT,validate='1:1')
            # df2=df2.set_index(v1.Batch_LOT)
            print(
                "\033[92m"
                + "\033[1m"
                + " Final Data Frame for the said Stage has been created and stored in the passed variable : "
                + "\033[0m"
            )
            print(
                "\033[92m"
                + "\033[1m"
                + "#########################################################################################"
                + "\033[0m"
            )

        if v1.use_case == "Yield" or v1.use_case == "ALL":
            logging.info(
                "Inside Coating_functions.py ---> OEE_Coating_FF_generator_3() ---> {  Use Case is Yield}"
            )
            yield_df = self.df.copy()
            yield_df = yield_df.reset_index()
            print("@@@@")
            print(yield_df.shape)
            if not multi_output:
                yield_df = yield_df[[v1.batch_id, v1.target_column[0]]]
            else:
                yield_df = yield_df[
                    [v1.batch_id, v1.target_column[0], v1.target_column[1]]
                ]
            yield_df = yield_df.set_index(v1.batch_id)
            yield_df = yield_df.groupby(v1.batch_id).agg("mean")
            print("@@@@")
            logging.info("INSIDE GENERATOR 4")
            logging.info("Before duplicates in yield")
            logging.info("@@@@")
            logging.info(yield_df.shape)
            # yield_df=yield_df.drop_duplicates()
            print("@@@@")
            print("After duplicates")
            print(yield_df.shape)
            logging.info("@@@@")
            logging.info(yield_df.shape)

            features = df.describe().columns.to_list()
            if not multi_output:
                features = list(filter(lambda x: x != v1.target_column[0], features))
            else:
                features = list(
                    filter(
                        lambda x: x not in [v1.target_column[0], v1.target_column[1]],
                        features,
                    )
                )
            if (
                v1.var_tobe_excluded != " "
                or v1.var_tobe_excluded != "NA"
                or v1.var_tobe_excluded != []
            ):
                for i in v1.var_tobe_excluded:
                    features = list(filter(lambda x: x != i, features))
                else:
                    pass
            print(
                "\033[92m"
                + "\033[1m"
                + "&&&&&&&&&&&& Features &&&&&&&&&&&"
                + "\033[92m"
                + "\033[1m"
            )
            print(features)

            if v1.other["Recipe_Based"] == "Y":
                for i in [
                    "0.05",
                    "0.1",
                    "0.15",
                    "0.2",
                    "0.25",
                    "0.3",
                    "0.35",
                    "0.4",
                    "0.45",
                    "0.5",
                    "0.55",
                    "0.6",
                    "0.65",
                    "0.7",
                    "0.75",
                    "0.8",
                    "0.85",
                    "0.9",
                    "0.95",
                ]:
                    globals()[f"features_{str(int(float(i)*100))}"] = eval(
                        "df.groupby(v1.batch_id)[features].quantile("
                        + i
                        + ").reset_index()"
                    )
                    globals()[f"features_{str(int(float(i)*100))}"] = globals()[
                        f"features_{str(int(float(i)*100))}"
                    ].set_index(v1.batch_id)
                    globals()[f"features_{str(int(float(i)*100))}"].columns = [
                        str(col) + "_" + (str(int(float(i) * 100)))
                        for col in globals()[
                            f"features_{str(int(float(i)*100))}"
                        ].columns
                    ]

                # print(features_5)
                # Feature df
                feature_df = features_5.reset_index().merge(
                    features_10.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_15.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_20.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_25.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_30.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_35.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_40.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_45.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_50.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_55.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_60.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_65.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_70.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_75.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_80.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_85.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_90.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    features_95.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(yield_df, on=[v1.batch_id])
                feature_df = feature_df.set_index(v1.batch_id)

                features = feature_df.columns.tolist()
                print("# of features ", features)

            else:
                for i in ["mean", "median", "min", "max", "mode"]:
                    if i != "mode":
                        globals()[f"{i}_features"] = eval(
                            "df.groupby(v1.batch_id)[features]."
                            + i
                            + "().reset_index()"
                        )
                        globals()[f"{i}_features"] = globals()[
                            f"{i}_features"
                        ].set_index(v1.batch_id)
                        globals()[f"{i}_features"].columns = [
                            str(col) + "_" + i
                            for col in globals()[f"{i}_features"].columns
                        ]
                    else:
                        mode_features = (
                            df.groupby(v1.batch_id)[features]
                            .apply(lambda x: x.mode().iloc[0])
                            .reset_index()
                        )
                        mode_features = mode_features.set_index(v1.batch_id)
                        mode_features.columns = [
                            str(col) + "_mod" for col in mode_features.columns
                        ]

                # print(mean_features)
                # Feature df
                feature_df = mean_features.reset_index().merge(
                    min_features.reset_index(), on=[v1.batch_id]
                )
                # print(feature_df)
                feature_df = feature_df.merge(
                    max_features.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    mode_features.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(
                    median_features.reset_index(), on=[v1.batch_id]
                )
                feature_df = feature_df.merge(yield_df, on=[v1.batch_id])
                feature_df = feature_df.set_index(v1.batch_id)

                features = feature_df.columns.tolist()
                print("# of features ", features)

            df2 = feature_df
            print(df2)

        logging.info("@@@@")
        logging.info(df2.shape)
        print(df2.shape)
        return df2
