from datetime import datetime
import pandas as pd

from ciplibrary_model.SQLConnection_DS import SQLConnection_DS

class Model_Ranges:
    def __init__(self,PRODUCTCODE=None,PRODUCTNAME=None,USECASE=None,MODEL_REFINED_COUNT=None,DATETIME=None,MODEL_SUGGESTED_RANGES=None,ACTUAL_RANGES_IN_WHICH_BATCHES_RUN=None,NO_OF_BATCHES_IN_SUGGESTED_RANGE=None,PERCENT_OF_BATCHES_IN_SUGGESTED_RANGE=None):
        self.PRODUCTCODE=PRODUCTCODE
        self.PRODUCTNAME=PRODUCTNAME
        self.USECASE=USECASE
        self.MODEL_REFINED_COUNT=MODEL_REFINED_COUNT
        self.DATETIME=DATETIME
        self.MODEL_SUGGESTED_RANGES=MODEL_SUGGESTED_RANGES
        self.ACTUAL_RANGES_IN_WHICH_BATCHES_RUN=ACTUAL_RANGES_IN_WHICH_BATCHES_RUN
        self.NO_OF_BATCHES_IN_SUGGESTED_RANGE=NO_OF_BATCHES_IN_SUGGESTED_RANGE
        self.PERCENT_OF_BATCHES_IN_SUGGESTED_RANGE=PERCENT_OF_BATCHES_IN_SUGGESTED_RANGE


    def insert_SQL_DataFrame(self):

        sql_df = pd.DataFrame(columns=['PRODUCTCODE','PRODUCTNAME','USECASE','MODEL_REFINED_COUNT','DATETIME','MODEL_SUGGESTED_RANGES','ACTUAL_RANGES_IN_WHICH_BATCHES_RUN','NO_OF_BATCHES_IN_SUGGESTED_RANGE','PERCENT_OF_BATCHES_IN_SUGGESTED_RANGE'])
        sql_dictionary = {  'PRODUCTCODE': [self.PRODUCTCODE],
                            'PRODUCTNAME': [self.PRODUCTNAME],
                            'USECASE': [self.USECASE],
                            'MODEL_REFINED_COUNT': [self.MODEL_REFINED_COUNT],
                            'DATETIME': [self.DATETIME],
                            'MODEL_SUGGESTED_RANGES': [self.MODEL_SUGGESTED_RANGES],
                            'ACTUAL_RANGES_IN_WHICH_BATCHES_RUN': [self.ACTUAL_RANGES_IN_WHICH_BATCHES_RUN],
                            'NO_OF_BATCHES_IN_SUGGESTED_RANGE': [self.NO_OF_BATCHES_IN_SUGGESTED_RANGE],
                            'PERCENT_OF_BATCHES_IN_SUGGESTED_RANGE': [self.PERCENT_OF_BATCHES_IN_SUGGESTED_RANGE]                        }
        
        print(sql_dictionary)
        df_insert_sql = pd.DataFrame(sql_dictionary)
        new_df = pd.concat([sql_df , df_insert_sql])
        return new_df
    
    def push_DataFrame_to_sql(self,sparkdf):
        sql_connect = SQLConnection_DS()
        sql_connect.write_spark_to_table(sparkdf,"dbo.MODEL_OUTPUT")

        print(" !!!!!!!  Done  !!!!!!!")
