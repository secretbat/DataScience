from datetime import datetime
import pandas as pd
from ciplibrary_model.SQLConnection_DS import SQLConnection_DS

class SQL_Logger:
    def __init__(self,MACHINECODE=None,PRODUCTCODE=None,LINE=None,UNIT=None,SITE=None,BATCH_SIZE=None,PRODUCTNAME=None,MIN_BATCHID=None,MAX_BATCHID=None,DATETIME=None,USECASE=None,STAGE=None,SUBSTAGE=None,DS_NAME=None,DE_NAME=None,ACCURACY_TRAIN=None,ACCURACY_TEST=None,RMSE_TRAIN=None,RMSE_TEST=None,REFINED_COUNT=None,REFRESHED_DATE=None,NO_BATCHES=None,OUTPUT_DIR=None,TIME_TAKEN=None,MULTIOUTPUT=None):
        self.MACHINECODE=MACHINECODE
        self.PRODUCTCODE=PRODUCTCODE
        self.LINE=LINE
        self.UNIT=UNIT
        self.SITE=SITE
        self.BATCH_SIZE=BATCH_SIZE
        self.PRODUCTNAME=PRODUCTNAME
        self.MIN_BATCHID=MIN_BATCHID
        self.MAX_BATCHID=MAX_BATCHID
        self.DATETIME=DATETIME
        self.USECASE=USECASE
        self.STAGE=STAGE
        self.SUBSTAGE=SUBSTAGE
        self.DS_NAME=DS_NAME
        self.DE_NAME=DE_NAME
        self.ACCURACY_TRAIN=ACCURACY_TRAIN
        self.ACCURACY_TEST=ACCURACY_TEST
        self.RMSE_TRAIN=RMSE_TRAIN
        self.RMSE_TEST=RMSE_TEST
        self.REFINED_COUNT=REFINED_COUNT
        self.REFRESHED_DATE=REFRESHED_DATE
        self.NO_BATCHES=NO_BATCHES
        self.OUTPUT_DIR=OUTPUT_DIR
        self.TIME_TAKEN=TIME_TAKEN
        self.MULTIOUTPUT=MULTIOUTPUT

    def create_SQL_DataFrame(self):
        sql_df = pd.DataFrame(columns=['MACHINECODE','PRODUCTCODE','LINE','UNIT','SITE','BATCH_SIZE','PRODUCTNAME','MIN_BATCHID','MAX_BATCHID','DATETIME','USECASE','STAGE','SUBSTAGE','DS_NAME','DE_NAME','ACCURACY_TRAIN','ACCURACY_TEST','RMSE_TRAIN','RMSE_TEST','REFINED_COUNT','REFRESHED_DATE','NO_BATCHES','OUTPUT_DIR','TIME_TAKEN','MULTIOUTPUT'])
        return sql_df

    def insert_SQL_DataFrame(self,sql_df):
        sql_dictionary = {  
                            'MACHINECODE': [self.MACHINECODE],
                            'PRODUCTCODE': [self.PRODUCTCODE],
                            'LINE': [self.LINE],
                            'UNIT': [self.UNIT],
                            'SITE': [self.SITE],
                            'BATCH_SIZE': [self.BATCH_SIZE],
                            'PRODUCTNAME': [self.PRODUCTNAME],
                            'MIN_BATCHID': [self.MIN_BATCHID],
                            'MAX_BATCHID': [self.MAX_BATCHID],
                            'DATETIME': [self.DATETIME],
                            'USECASE': [self.USECASE],
                            'STAGE': [self.STAGE],
                            'SUBSTAGE': [self.SUBSTAGE],
                            'DS_NAME': [self.DS_NAME],
                            'DE_NAME': [self.DE_NAME],
                            'ACCURACY_TRAIN': [self.ACCURACY_TRAIN],
                            'ACCURACY_TEST': [self.ACCURACY_TEST],
                            'RMSE_TRAIN': [self.RMSE_TRAIN],
                            'RMSE_TEST': [self.RMSE_TEST],
                            'REFINED_COUNT': [self.REFINED_COUNT],
                            'REFRESHED_DATE': [self.REFRESHED_DATE],
                            'NO_BATCHES': [self.NO_BATCHES],
                            'OUTPUT_DIR': [self.OUTPUT_DIR],
                            'TIME_TAKEN': [self.TIME_TAKEN],
                            'MULTIOUTPUT' : [self.MULTIOUTPUT]
                        }
        
        print(sql_dictionary)
        df_insert_sql = pd.DataFrame(sql_dictionary)
        new_df = pd.concat([sql_df , df_insert_sql])
        return new_df
    
    def push_DataFrame_to_sql(self,sparkdf):
        sql_connect = SQLConnection_DS()
        sql_connect.write_spark_to_table(sparkdf,"dbo.MODEL_OUTPUT")

        print(" !!!!!!!  Done  !!!!!!!")
