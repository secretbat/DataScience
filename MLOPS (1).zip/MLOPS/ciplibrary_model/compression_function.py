import pandas as pd
import numpy as np
import os
import seaborn as sns
import matplotlib.pyplot as plt
from tqdm import tqdm
import warnings
warnings.simplefilter("ignore")
import matplotlib.dates as mdates
import re
import itertools
from operator import mul
from functools import reduce
import statsmodels. api as sm
from sklearn.model_selection import train_test_split
from sklearn.linear_model import ElasticNet, ElasticNetCV
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error, make_scorer
from sklearn import preprocessing
from sklearn.metrics import r2_score
from sklearn.neighbors import KNeighborsRegressor, RadiusNeighborsRegressor
import random as rnd
from math import sqrt
from sklearn.metrics import mean_squared_error
import joblib
import click
import pickle
import logging
import traceback



pd.set_option('display.max_rows', 1000)
pd.set_option('display.max_columns', None)

class OEE_Compression_Model:

    def Station1_Bin_Creator(self,df,LOD,Bulk_Density,Tapped_Density,Fines,Tablet_cyl_ht_Main_Station1,Tablet_cyl_ht_Pre_Station1
                                ,Main_comp_force,Pre_comp_force,Tablet_filling_depth_Station1,book,dt):

        """
        This function Station1_Bin_Creator creates bins in APQR data params viz LOD,BD,TD and % Fines for Station 1 .
        Args:
            The input data for this function is a dictionary in below format containing the dataframe name and
            the column names of the required features.
                input_data = { 'df':final_flat_file,
                'LOD':'Loss On Drying_telmi',
                'Bulk_Density':'Bulk Density_telmi',
                'Tapped_Density':'Tapped Density_telmi',
                'Fines':'% Fines_telmi',
                'Tablet_cyl_ht_Main_Station1':'Tabl. cyl. ht. main co. mm_station_1',
                'Tablet_cyl_ht_Pre_Station1' : 'Tabl. cyl. ht. pre co. mm_station_1',
                'Main_comp_force':'Main compr.force MV kN_station_1',
                'Pre_comp_force':'Pre compr. force MV kN_station_1',
                'Tablet_filling_depth_Station1':'Tabl. filling depth mm_station_1'}
        Returns:
                It will return below two lists of DataFrames
                List 1 -  All the dataframes formed using various combinations of bins in APQR data where there are NaN
                values present.
                List 2 - All the dataframes formed using various combinations of bins in APQR data where there are 
                no null values present
        Example:
            You can run this function in below way,
            bad_stn1,good_stn1 = pgs.Station1_Bin_Creator(**input_data)
        """



        bin_combs =     [[1, 1, 2, 2],
            [1, 2, 1, 1],
            [1, 2, 1, 2],
            [1, 2, 2, 1],
            [1, 2, 2, 2],
            [2, 1, 1, 2],
            [2, 1, 2, 1],
            [2, 1, 2, 2],
            [2, 2, 1, 1],
            [2, 2, 1, 2],
            [2, 2, 2, 1],
            [2, 2, 2, 2]]
        lod_COL=LOD 
        td_COL=Tapped_Density
        bd_COL=Bulk_Density
        fines_COL=Fines
        nulldf = list()
        gooddf = list()
        station1_controls = [Tablet_cyl_ht_Main_Station1,
                            Tablet_cyl_ht_Pre_Station1,
                            Main_comp_force,
                            Pre_comp_force,
                            Tablet_filling_depth_Station1]
        for i in bin_combs:
            nbins_lod =i[0]
            nbins_td =i[1]
            nbins_bd =i[2]
            nbins_fines =i[3]
            bd_1=(np.histogram_bin_edges(df[bd_COL], bins=nbins_bd))
            bd_1[len(bd_1)-1]=bd_1[len(bd_1)-1]+0.01
            bd_1 = bd_1.tolist()
            lod_1=(np.histogram_bin_edges(df[lod_COL], bins=nbins_lod))
            lod_1[len(lod_1)-1]=lod_1[len(lod_1)-1]+0.01
            lod_1=lod_1.tolist()
            td_1=(np.histogram_bin_edges(df[td_COL], bins=nbins_td))
            td_1[len(td_1)-1]=td_1[len(td_1)-1]+0.01
            td_1=td_1.tolist()
            fines_1=(np.histogram_bin_edges(df[fines_COL], bins=nbins_fines))
            fines_1[len(fines_1)-1]=fines_1[len(fines_1)-1]+0.01
            fines_1=fines_1.tolist()
            profile_df=pd.DataFrame()
            profile_df=profile_df.append(pd.DataFrame(lod_1).T)
            profile_df['feature']='LOD1'
            profile_df=profile_df.append(pd.DataFrame(td_1).T)
            profile_df['feature']=profile_df['feature'].fillna('Tapped_Density1')
            profile_df=profile_df.append(pd.DataFrame(bd_1).T)
            profile_df['feature']=profile_df['feature'].fillna('Bulk_Density1')
            profile_df=profile_df.append(pd.DataFrame(fines_1).T)
            profile_df['feature']=profile_df['feature'].fillna('Fines1')
            if 1 in profile_df.columns.tolist():
                profile_df['bin1']=profile_df[0].astype(str)+'-'+profile_df[1].astype(str)
            if 2 in profile_df.columns.tolist():
                profile_df['bin2']=profile_df[1].astype(str)+'-'+profile_df[2].astype(str)
            if 3 in profile_df.columns.tolist():
                profile_df['bin3']=profile_df[2].astype(str)+'-'+profile_df[3].astype(str)
            if 4 in profile_df.columns.tolist():
                profile_df['bin4']=profile_df[3].astype(str)+'-'+profile_df[4].astype(str)
            if 5 in profile_df.columns.tolist():
                profile_df['bin5']=profile_df[4].astype(str)+'-'+profile_df[5].astype(str)
            profile_df=profile_df[['feature','bin1','bin2']]
            lod_1=profile_df[profile_df['feature']=='LOD1'].drop(columns='feature')
            lod_1= lod_1.values.tolist()[0]
            lod_1=[col for col in lod_1 if 'nan' not in col]

            bd_1=profile_df[profile_df['feature']=='Bulk_Density1'].drop(columns='feature')
            bd_1= bd_1.values.tolist()[0]
            bd_1=[col for col in bd_1 if 'nan' not in col]

            td_1=profile_df[profile_df['feature']=='Tapped_Density1'].drop(columns='feature')
            td_1= td_1.values.tolist()[0]
            td_1=[col for col in td_1 if 'nan' not in col]

            fines_1=profile_df[profile_df['feature']=='Fines1'].drop(columns='feature')
            fines_1= fines_1.values.tolist()[0]
            fines_1=[col for col in fines_1 if 'nan' not in col]
            import itertools
            all_possible_profiles=list(itertools.product(lod_1, bd_1, td_1, fines_1))
            #print("All possible combinations ", (len(all_possible_profiles)))
            profile_df = pd.DataFrame(all_possible_profiles, columns=['lod_stn1', 'bd_stn1', 'td_stn1','fines_stn1'])
            profile_df=profile_df.reset_index(drop=True).reset_index().rename(columns={'index':'profile_id'})
            #print("Profile df shape ", profile_df.shape)
            df[lod_COL]=df[lod_COL].round(2)
            df[td_COL]=df[td_COL].round(2)
            df[bd_COL]=df[bd_COL].round(2)
            df[fines_COL]=df[fines_COL].round(2)
            char_df=pd.DataFrame()
            no_of_profiles=profile_df['profile_id'].unique().tolist()
            for profile in no_of_profiles:
                temp_df=profile_df[profile_df['profile_id']==profile].reset_index(drop=True)
                temp_df[['lod_stn1_low','lod_stn1_high']]=temp_df['lod_stn1'].str.split('-', expand=True)
                temp_df[['bd_stn1_low','bd_stn1_high']]=temp_df['bd_stn1'].str.split('-', expand=True)
                temp_df[['td_stn1_low','td_stn1_high']]=temp_df['td_stn1'].str.split('-', expand=True)
                temp_df[['fines_stn1_low','fines_stn1_high']]=temp_df['fines_stn1'].str.split('-', expand=True)
                req_df=df[(df[lod_COL]>=float(temp_df['lod_stn1_low'][0])) & (df[lod_COL]<float(temp_df['lod_stn1_high'][0]))
                        & (df[bd_COL]>=float(temp_df['bd_stn1_low'][0])) & (df[bd_COL]<float(temp_df['bd_stn1_high'][0]))
                        & (df[td_COL]>=float(temp_df['td_stn1_low'][0])) & (df[td_COL]<float(temp_df['td_stn1_high'][0]))
                        & (df[fines_COL]>=float(temp_df['fines_stn1_low'][0])) & (df[fines_COL]<float(temp_df['fines_stn1_high'][0]))]
                #req_df.to_excel("bin_"+str(profile)+".xlsx")
                if req_df.shape[0]>0:
                        min_range=req_df[station1_controls][req_df[station1_controls]>0].min().reset_index().set_index('index').T
                        reg_lst= min_range.values.flatten().tolist()
                        for i,j in enumerate(list(reg_lst)):
                            if j==5 and req_df[station1_controls].iloc[:,i].name.find("force MV kN_station_t") != -1:
                                min_range.iloc[:,i]=req_df[station1_controls].iloc[:,i][req_df[station1_controls].iloc[:,i]>5].min()
                        cols=[col+'_lower_bound' for col in min_range.columns.tolist()]
                        min_range.columns=cols
                        max_range=req_df[station1_controls].max().reset_index().set_index('index').T
                        reg_lst= max_range.values.flatten().tolist()
                        for i,j in enumerate(list(reg_lst)):
                            if j==5 and req_df[station1_controls].iloc[:,i].name.find("force MV kN_station_1") != -1:
                                max_range.iloc[:,i]=req_df[station1_controls].iloc[:,i][req_df[station1_controls].iloc[:,i]<5].max()

                        cols=[col+'_upper_bound' for col in max_range.columns.tolist()]
                        max_range.columns=cols
                        mode_df=req_df[station1_controls].mode().head(1)
                        cols=[col+'_mode' for col in mode_df.columns.tolist()]
                        mode_df.columns=cols
                        ranges=pd.concat([min_range,max_range,mode_df], axis=1)
                        ranges['profile_id']=[profile]
                        ranges['#_of_batches']=[req_df.shape[0]]
                        ranges['batches']=[req_df['BATCH_ID'].unique().tolist()]
                        char_df=char_df.append(ranges)
            profile_df=profile_df.merge(char_df, on=['profile_id'], how='left',validate='1:1')
            if profile_df.isnull().values.any() == True:
                nulldf.append(profile_df)
            else:
                gooddf.append(profile_df)

        Good_bin_combinations = print("In this data there are " , len(gooddf) , "possible combinations of bins without any null values" )
        Bad_bin_combinations = print("In this data there are " , len(nulldf) , "possible combinations of bins with null values" )

        #New Code Added ---------------------------
        str1 = "In this data there are "+  str(len(gooddf)) + "possible combinations of bins without any null values"
        str2 = "In this data there are "+  str(len(nulldf)) + "possible combinations of bins with null values"
        info_dict = {'infostation1' : [str1,str2]}
        info_dict_df = pd.DataFrame(info_dict)

        # try:
        #     book=dt.create_Sheet(book,'null_df',nulldf)
        # except Exception as error:
        #     logging.error('(compression_function.py) --> (Station1_Bin_Creator) --> Error in Creating the Sheet')
        #     traceback.print_exc()

        # try:
        #     book=dt.create_Sheet(book,'gooddf',gooddf)
        # except Exception as error:
        #     logging.error('(compression_function.py) --> (Station1_Bin_Creator) --> Error in Creating the Sheet')
        #     traceback.print_exc()

        # -------------------------------------------

        # return nulldf,gooddf
        return book,info_dict_df,gooddf
        # return Good_bin_combinations,Bad_bin_combinations


    def Station2_SingleAPQR_Data_Bin_Creator(self,df,LOD,Bulk_Density,Tapped_Density,Fines,Tablet_cyl_ht_Main_Station2,Tablet_cyl_ht_Pre_Station2
                                ,Main_comp_force_stn2,Pre_comp_force_stn2,Tablet_filling_depth_Station2,book,dt,stationNo):

        """
        This function Station2_SingleAPQR_Data_Bin_Creator creates bins in APQR data params viz LOD,BD,TD and % Fines for Station 1 .
        This function is to be used in products where there are 2 Stations and 1 set of APQR data is present. 

        Args:
        The input data for this function is a dictionary in below format containing the dataframe name and
        the column names of the required features.

        input_data2 = { 'df':final_flat_file,
                'LOD':'Loss On Drying_telmi',
                'Bulk_Density':'Bulk Density_telmi',
                'Tapped_Density':'Tapped Density_telmi',
                'Fines':'% Fines_telmi',
                'Tablet_cyl_ht_Main_Station2' : 'Tabl. cyl. ht. main co. mm_station_2',
                'Tablet_cyl_ht_Pre_Station2' : 'Tabl. cyl. ht. pre co. mm_station_2',
                'Main_comp_force_stn2':'Main compr.force MV kN_station_2',
                'Pre_comp_force_stn2':'Pre compr. force MV kN_station_2',
                'Tablet_filling_depth_Station2':'Tabl. filling depth mm_station_2'
                }

        Returns:
        It will return below two lists of DataFrames
        List 1 : All the dataframes formed using various combinations of bins in APQR data where there are NaN
                values present.
        List 2 : All the dataframes formed using various combinations of bins in APQR data where there are 
                no null values present

        Usage Example:
        You can run this function in below way,
        bad_stn2,good_stn2 = pgs.Station2_SingleAPQR_Data_Bin_Creator(**input_data2)

        """

        bin_combs =     [[1, 1, 2, 2],
            [1, 2, 1, 1],
            [1, 2, 1, 2],
            [1, 2, 2, 1],
            [1, 2, 2, 2],
            [2, 1, 1, 2],
            [2, 1, 2, 1],
            [2, 1, 2, 2],
            [2, 2, 1, 1],
            [2, 2, 1, 2],
            [2, 2, 2, 1],
            [2, 2, 2, 2]]
        lod_COL=LOD 
        td_COL=Tapped_Density
        bd_COL=Bulk_Density
        fines_COL=Fines
        nulldf = list()
        gooddf = list()
        station2_controls = [Tablet_cyl_ht_Main_Station2,
                            Tablet_cyl_ht_Pre_Station2,
                            Main_comp_force_stn2,
                            Pre_comp_force_stn2,
                            Tablet_filling_depth_Station2]
        for i in bin_combs:
            nbins_lod =i[0]
            nbins_td =i[1]
            nbins_bd =i[2]
            nbins_fines =i[3]
            bd_1=(np.histogram_bin_edges(df[bd_COL], bins=nbins_bd))
            bd_1[len(bd_1)-1]=bd_1[len(bd_1)-1]+0.01
            bd_1 = bd_1.tolist()
            lod_1=(np.histogram_bin_edges(df[lod_COL], bins=nbins_lod))
            lod_1[len(lod_1)-1]=lod_1[len(lod_1)-1]+0.01
            lod_1=lod_1.tolist()
            td_1=(np.histogram_bin_edges(df[td_COL], bins=nbins_td))
            td_1[len(td_1)-1]=td_1[len(td_1)-1]+0.01
            td_1=td_1.tolist()
            fines_1=(np.histogram_bin_edges(df[fines_COL], bins=nbins_fines))
            fines_1[len(fines_1)-1]=fines_1[len(fines_1)-1]+0.01
            fines_1=fines_1.tolist()
            profile_df=pd.DataFrame()
            profile_df=profile_df.append(pd.DataFrame(lod_1).T)
            profile_df['feature']='LOD1'
            profile_df=profile_df.append(pd.DataFrame(td_1).T)
            profile_df['feature']=profile_df['feature'].fillna('Tapped_Density1')
            profile_df=profile_df.append(pd.DataFrame(bd_1).T)
            profile_df['feature']=profile_df['feature'].fillna('Bulk_Density1')
            profile_df=profile_df.append(pd.DataFrame(fines_1).T)
            profile_df['feature']=profile_df['feature'].fillna('Fines1')
            if 1 in profile_df.columns.tolist():
                profile_df['bin1']=profile_df[0].astype(str)+'-'+profile_df[1].astype(str)
            if 2 in profile_df.columns.tolist():
                profile_df['bin2']=profile_df[1].astype(str)+'-'+profile_df[2].astype(str)
            if 3 in profile_df.columns.tolist():
                profile_df['bin3']=profile_df[2].astype(str)+'-'+profile_df[3].astype(str)
            if 4 in profile_df.columns.tolist():
                profile_df['bin4']=profile_df[3].astype(str)+'-'+profile_df[4].astype(str)
            if 5 in profile_df.columns.tolist():
                profile_df['bin5']=profile_df[4].astype(str)+'-'+profile_df[5].astype(str)
            profile_df=profile_df[['feature','bin1','bin2']]
            lod_1=profile_df[profile_df['feature']=='LOD1'].drop(columns='feature')
            lod_1= lod_1.values.tolist()[0]
            lod_1=[col for col in lod_1 if 'nan' not in col]

            bd_1=profile_df[profile_df['feature']=='Bulk_Density1'].drop(columns='feature')
            bd_1= bd_1.values.tolist()[0]
            bd_1=[col for col in bd_1 if 'nan' not in col]

            td_1=profile_df[profile_df['feature']=='Tapped_Density1'].drop(columns='feature')
            td_1= td_1.values.tolist()[0]
            td_1=[col for col in td_1 if 'nan' not in col]

            fines_1=profile_df[profile_df['feature']=='Fines1'].drop(columns='feature')
            fines_1= fines_1.values.tolist()[0]
            fines_1=[col for col in fines_1 if 'nan' not in col]
            import itertools
            all_possible_profiles=list(itertools.product(lod_1, bd_1, td_1, fines_1))
            #print("All possible combinations ", (len(all_possible_profiles)))
            profile_df = pd.DataFrame(all_possible_profiles, columns=['lod_stn2', 'bd_stn2', 'td_stn2','fines_stn2'])
            profile_df=profile_df.reset_index(drop=True).reset_index().rename(columns={'index':'profile_id'})
            #print("Profile df shape ", profile_df.shape)
            df[lod_COL]=df[lod_COL].round(2)
            df[td_COL]=df[td_COL].round(2)
            df[bd_COL]=df[bd_COL].round(2)
            df[fines_COL]=df[fines_COL].round(2)
            char_df=pd.DataFrame()
            no_of_profiles=profile_df['profile_id'].unique().tolist()
            for profile in no_of_profiles:
                temp_df=profile_df[profile_df['profile_id']==profile].reset_index(drop=True)
                temp_df[['lod_stn2_low','lod_stn2_high']]=temp_df['lod_stn2'].str.split('-', expand=True)
                temp_df[['bd_stn2_low','bd_stn2_high']]=temp_df['bd_stn2'].str.split('-', expand=True)
                temp_df[['td_stn2_low','td_stn2_high']]=temp_df['td_stn2'].str.split('-', expand=True)
                temp_df[['fines_stn2_low','fines_stn2_high']]=temp_df['fines_stn2'].str.split('-', expand=True)
                req_df=df[(df[lod_COL]>=float(temp_df['lod_stn2_low'][0])) & (df[lod_COL]<float(temp_df['lod_stn2_high'][0]))
                        & (df[bd_COL]>=float(temp_df['bd_stn2_low'][0])) & (df[bd_COL]<float(temp_df['bd_stn2_high'][0]))
                        & (df[td_COL]>=float(temp_df['td_stn2_low'][0])) & (df[td_COL]<float(temp_df['td_stn2_high'][0]))
                        & (df[fines_COL]>=float(temp_df['fines_stn2_low'][0])) & (df[fines_COL]<float(temp_df['fines_stn2_high'][0]))]
                # req_df.to_excel("bin_"+str(profile)+".xlsx")
                if req_df.shape[0]>0:
                        min_range=req_df[station2_controls][req_df[station2_controls]>0].min().reset_index().set_index('index').T
                        reg_lst= min_range.values.flatten().tolist()
                        for i,j in enumerate(list(reg_lst)):
                            if j==5 and req_df[station2_controls].iloc[:,i].name.find("force MV kN_station_t") != -1:
                                min_range.iloc[:,i]=req_df[station2_controls].iloc[:,i][req_df[station2_controls].iloc[:,i]>5].min()
                        cols=[col+'_lower_bound' for col in min_range.columns.tolist()]
                        min_range.columns=cols
                        max_range=req_df[station2_controls].max().reset_index().set_index('index').T
                        reg_lst= max_range.values.flatten().tolist()
                        for i,j in enumerate(list(reg_lst)):
                            if j==5 and req_df[station2_controls].iloc[:,i].name.find("force MV kN_station_1") != -1:
                                max_range.iloc[:,i]=req_df[station2_controls].iloc[:,i][req_df[station2_controls].iloc[:,i]<5].max()

                        cols=[col+'_upper_bound' for col in max_range.columns.tolist()]
                        max_range.columns=cols
                        mode_df=req_df[station2_controls].mode().head(1)
                        cols=[col+'_mode' for col in mode_df.columns.tolist()]
                        mode_df.columns=cols
                        ranges=pd.concat([min_range,max_range,mode_df], axis=1)
                        ranges['profile_id']=[profile]
                        ranges['#_of_batches']=[req_df.shape[0]]
                        ranges['batches']=[req_df['BATCH_ID'].unique().tolist()]
                        char_df=char_df.append(ranges)
            profile_df=profile_df.merge(char_df, on=['profile_id'], how='left',validate='1:1')
            if profile_df.isnull().values.any() == True:
                nulldf.append(profile_df)
            else:
                gooddf.append(profile_df)
        Good_bin_combinations = print("In this data there are " , len(gooddf) , "possible combinations of bins without any null values" )
        Bad_bin_combinations = print("In this data there are " , len(nulldf) , "possible combinations of bins with null values" )
        
        #New Code Added ---------------------------
        
        info = 'info'+stationNo
        null_dataframe = 'null_df'+stationNo
        good_dataframe = 'good_df'+stationNo
        str1 = "In this data there are "+  str(len(gooddf)) + "possible combinations of bins without any null values"
        str2 = "In this data there are "+  str(len(nulldf)) + "possible combinations of bins with null values"
        info_dict = {info : [str1,str2]}
        info_dict_df = pd.DataFrame(info_dict)

        # try:
        #     book=dt.create_Sheet(book,null_dataframe,nulldf)
        # except Exception as error:
        #     logging.error('(compression_function.py) --> (Station1_Bin_Creator) --> Error in Creating the Sheet')
        #     traceback.print_exc()

        # try:
        #     book=dt.create_Sheet(book,good_dataframe,gooddf)
        # except Exception as error:
        #     logging.error('(compression_function.py) --> (Station1_Bin_Creator) --> Error in Creating the Sheet')
        #     traceback.print_exc()

        # -------------------------------------------

        # return nulldf,gooddf
        return book,info_dict_df,gooddf
        
        # return nulldf,gooddf
        # return Good_bin_combinations,Bad_bin_combinations


    def Station2_DL_DoubleAPQR_Data_Bin_Creator(self,df,LOD1,Bulk_Density1,Tapped_Density1,Fines1,
                                                LOD2,Bulk_Density2,Tapped_Density2,Fines2,
                                                Tablet_cyl_ht_Main_Station2,Tablet_cyl_ht_Pre_Station2
                                                ,Main_comp_force_stn2,Pre_comp_force_stn2,Tablet_filling_depth_Station2,book,dt,stationNo):
        
        """
        This function Station2_DL_DoubleAPQR_Data_Bin_Creator creates bins in APQR data params viz LOD,BD,TD and % Fines for Station 1 .
        This function is to be used in products where there are 2 Stations and 2 sets of APQR data is present. 

        Args:
        The input data for this function is a dictionary in below format containing the dataframe name and
        the column names of the required features.

        input_data3 = { 'df':final_flat_file,
                'LOD1':'Loss On Drying_telmi',
                'Bulk_Density1':'Bulk Density_telmi',
                'Tapped_Density1':'Tapped Density_telmi',
                'Fines1':'% Fines_telmi',
                'LOD2':'Loss On Drying_amlo',
                'Bulk_Density2':'Bulk Density_amlo',
                'Tapped_Density2':'Tapped Density_amlo',
                'Fines2':'% Fines_amlo',     
                'Tablet_cyl_ht_Main_Station2' : 'Tabl. cyl. ht. main co. mm_station_2',
                'Tablet_cyl_ht_Pre_Station2' : 'Tabl. cyl. ht. pre co. mm_station_2',
                'Main_comp_force_stn2':'Main compr.force MV kN_station_2',
                'Pre_comp_force_stn2':'Pre compr. force MV kN_station_2',
                'Tablet_filling_depth_Station2':'Tabl. filling depth mm_station_2'
                }

        Returns:
        It will return below two lists of DataFrames
        List 1 : All the dataframes formed using various combinations of bins in APQR data where there are NaN
                values present.
        List 2 : All the dataframes formed using various combinations of bins in APQR data where there are 
                no null values present

        Usage Example:
        You can run this function in below way,
        bad_stn3,good_stn3 = pgs.Station2_DL_DoubleAPQR_Data_Bin_Creator(**input_data3)

        """

        lod_COL=LOD1 
        td_COL=Tapped_Density1
        bd_COL=Bulk_Density1
        fines_COL=Fines1
        lod2_COL=LOD2
        td2_COL=Tapped_Density2
        bd2_COL=Bulk_Density2
        fines2_COL=Fines2    
        nulldf = list()
        gooddf = list()  
        station2_controls = [Tablet_cyl_ht_Main_Station2,
                            Tablet_cyl_ht_Pre_Station2,
                            Main_comp_force_stn2,
                            Pre_comp_force_stn2,
                            Tablet_filling_depth_Station2]
        ziplod1 = [1,2]
        zipbd1 = [1,2]
        ziptd1 = [1,2]
        zipfines1 = [1,2]
        ziplod2 = [1,2]
        zipbd2 = [1,2]
        ziptd2 = [1,2]
        zipfines2 = [1,2]
        bin_combs=[]
        for i in list(itertools.product(ziplod1,zipbd1,ziptd1,zipfines1,ziplod2,zipbd2,ziptd2,zipfines2)):    
            a = list(i)
            b = reduce(mul,a, 1)
            if b == 4 or b == 8 or b == 16:
                bin_combs.append(a)
            else:
                b =+ b
        
        for i in bin_combs:
            nbins_lod =i[0]
            nbins_td =i[1]
            nbins_bd =i[2]
            nbins_fines =i[3]
            nbins_lod2 =i[4]
            nbins_td2 =i[5]
            nbins_bd2 =i[6]
            nbins_fines2 =i[7]
            bd_1=(np.histogram_bin_edges(df[bd_COL], bins=nbins_bd))
            bd_1[len(bd_1)-1]=bd_1[len(bd_1)-1]+0.01
            bd_1 = bd_1.tolist()
            lod_1=(np.histogram_bin_edges(df[lod_COL], bins=nbins_lod))
            lod_1[len(lod_1)-1]=lod_1[len(lod_1)-1]+0.01
            lod_1=lod_1.tolist()
            td_1=(np.histogram_bin_edges(df[td_COL], bins=nbins_td))
            td_1[len(td_1)-1]=td_1[len(td_1)-1]+0.01
            td_1=td_1.tolist()
            fines_1=(np.histogram_bin_edges(df[fines_COL], bins=nbins_fines))
            fines_1[len(fines_1)-1]=fines_1[len(fines_1)-1]+0.01
            fines_1=fines_1.tolist()
            bd_2=(np.histogram_bin_edges(df[bd2_COL], bins=nbins_bd2))
            bd_2[len(bd_2)-1]=bd_2[len(bd_2)-1]+0.01
            bd_2 = bd_2.tolist()
            lod_2=(np.histogram_bin_edges(df[lod2_COL], bins=nbins_lod2))
            lod_2[len(lod_2)-1]=lod_2[len(lod_2)-1]+0.01
            lod_2=lod_2.tolist()
            td_2=(np.histogram_bin_edges(df[td2_COL], bins=nbins_td2))
            td_2[len(td_2)-1]=td_2[len(td_2)-1]+0.01
            td_2=td_2.tolist()
            fines_2=(np.histogram_bin_edges(df[fines2_COL], bins=nbins_fines2))
            fines_2[len(fines_2)-1]=fines_2[len(fines_2)-1]+0.01
            fines_2=fines_2.tolist()       
            profile_df=pd.DataFrame()
            profile_df=profile_df.append(pd.DataFrame(lod_1).T)
            profile_df['feature']='LOD1'
            profile_df=profile_df.append(pd.DataFrame(td_1).T)
            profile_df['feature']=profile_df['feature'].fillna('Tapped_Density1')
            profile_df=profile_df.append(pd.DataFrame(bd_1).T)
            profile_df['feature']=profile_df['feature'].fillna('Bulk_Density1')
            profile_df=profile_df.append(pd.DataFrame(fines_1).T)
            profile_df['feature']=profile_df['feature'].fillna('Fines1')        
            profile_df=profile_df.append(pd.DataFrame(lod_2).T)
            profile_df['feature']=profile_df['feature'].fillna('LOD2')
            profile_df=profile_df.append(pd.DataFrame(td_2).T)
            profile_df['feature']=profile_df['feature'].fillna('Tapped_Density2')
            profile_df=profile_df.append(pd.DataFrame(bd_2).T)
            profile_df['feature']=profile_df['feature'].fillna('Bulk_Density2')
            profile_df=profile_df.append(pd.DataFrame(fines_2).T)
            profile_df['feature']=profile_df['feature'].fillna('Fines2')
            
            if 1 in profile_df.columns.tolist():
                profile_df['bin1']=profile_df[0].astype(str)+'-'+profile_df[1].astype(str)
            if 2 in profile_df.columns.tolist():
                profile_df['bin2']=profile_df[1].astype(str)+'-'+profile_df[2].astype(str)
            if 3 in profile_df.columns.tolist():
                profile_df['bin3']=profile_df[2].astype(str)+'-'+profile_df[3].astype(str)
            if 4 in profile_df.columns.tolist():
                profile_df['bin4']=profile_df[3].astype(str)+'-'+profile_df[4].astype(str)
            if 5 in profile_df.columns.tolist():
                profile_df['bin5']=profile_df[4].astype(str)+'-'+profile_df[5].astype(str)
            profile_df=profile_df[['feature','bin1','bin2']]
            
            lod_1=profile_df[profile_df['feature']=='LOD1'].drop(columns='feature')
            lod_1= lod_1.values.tolist()[0]
            lod_1=[col for col in lod_1 if 'nan' not in col]

            bd_1=profile_df[profile_df['feature']=='Bulk_Density1'].drop(columns='feature')
            bd_1= bd_1.values.tolist()[0]
            bd_1=[col for col in bd_1 if 'nan' not in col]

            td_1=profile_df[profile_df['feature']=='Tapped_Density1'].drop(columns='feature')
            td_1= td_1.values.tolist()[0]
            td_1=[col for col in td_1 if 'nan' not in col]

            fines_1=profile_df[profile_df['feature']=='Fines1'].drop(columns='feature')
            fines_1= fines_1.values.tolist()[0]
            fines_1=[col for col in fines_1 if 'nan' not in col]
            
            lod_2=profile_df[profile_df['feature']=='LOD2'].drop(columns='feature')
            lod_2= lod_2.values.tolist()[0]
            lod_2=[col for col in lod_2 if 'nan' not in col]

            bd_2=profile_df[profile_df['feature']=='Bulk_Density2'].drop(columns='feature')
            bd_2= bd_2.values.tolist()[0]
            bd_2=[col for col in bd_2 if 'nan' not in col]

            td_2=profile_df[profile_df['feature']=='Tapped_Density2'].drop(columns='feature')
            td_2= td_2.values.tolist()[0]
            td_2=[col for col in td_2 if 'nan' not in col]

            fines_2=profile_df[profile_df['feature']=='Fines2'].drop(columns='feature')
            fines_2= fines_2.values.tolist()[0]
            fines_2=[col for col in fines_2 if 'nan' not in col]
            
            all_possible_profiles=list(itertools.product(lod_1, bd_1, td_1, fines_1,lod_2, bd_2, td_2, fines_2))
            #print("All possible combinations ", (len(all_possible_profiles)))
            profile_df = pd.DataFrame(all_possible_profiles, columns=['lod_stn1', 'bd_stn1', 'td_stn1','fines_stn1','lod_stn2', 'bd_stn2', 'td_stn2','fines_stn2'])
            profile_df=profile_df.reset_index(drop=True).reset_index().rename(columns={'index':'profile_id'})
            #print("Profile df shape ", profile_df.shape)
            
            df[lod_COL]=df[lod_COL].round(2)
            df[td_COL]=df[td_COL].round(2)
            df[bd_COL]=df[bd_COL].round(2)
            df[fines_COL]=df[fines_COL].round(2)
            df[lod2_COL]=df[lod2_COL].round(2)
            df[td2_COL]=df[td2_COL].round(2)
            df[bd2_COL]=df[bd2_COL].round(2)
            df[fines2_COL]=df[fines2_COL].round(2)        
            
            no_of_profiles=profile_df['profile_id'].unique().tolist()        
            char_df=pd.DataFrame()
            for profile in no_of_profiles:
                temp_df=profile_df[profile_df['profile_id']==profile].reset_index(drop=True)
                temp_df[['lod_stn1_low','lod_stn1_high']]=temp_df['lod_stn1'].str.split('-', expand=True)
                temp_df[['bd_stn1_low','bd_stn1_high']]=temp_df['bd_stn1'].str.split('-', expand=True)
                temp_df[['td_stn1_low','td_stn1_high']]=temp_df['td_stn1'].str.split('-', expand=True)
                temp_df[['fines_stn1_low','fines_stn1_high']]=temp_df['fines_stn1'].str.split('-', expand=True)
                temp_df[['lod_stn2_low','lod_stn2_high']]=temp_df['lod_stn2'].str.split('-', expand=True)
                temp_df[['bd_stn2_low','bd_stn2_high']]=temp_df['bd_stn2'].str.split('-', expand=True)
                temp_df[['td_stn2_low','td_stn2_high']]=temp_df['td_stn2'].str.split('-', expand=True)
                temp_df[['fines_stn2_low','fines_stn2_high']]=temp_df['fines_stn2'].str.split('-', expand=True)
                req_df=df[(df[lod_COL]>=float(temp_df['lod_stn1_low'][0])) & (df[lod_COL]<float(temp_df['lod_stn1_high'][0]))
                        & (df[bd_COL]>=float(temp_df['bd_stn1_low'][0])) & (df[bd_COL]<float(temp_df['bd_stn1_high'][0]))
                        & (df[td_COL]>=float(temp_df['td_stn1_low'][0])) & (df[td_COL]<float(temp_df['td_stn1_high'][0]))
                        & (df[fines_COL]>=float(temp_df['fines_stn1_low'][0])) & (df[fines_COL]<float(temp_df['fines_stn1_high'][0]))       
                        & (df[lod2_COL]>=float(temp_df['lod_stn2_low'][0])) & (df[lod2_COL]<float(temp_df['lod_stn2_high'][0]))
                        & (df[bd2_COL]>=float(temp_df['bd_stn2_low'][0])) & (df[bd2_COL]<float(temp_df['bd_stn2_high'][0]))
                        & (df[td2_COL]>=float(temp_df['td_stn2_low'][0])) & (df[td2_COL]<float(temp_df['td_stn2_high'][0]))
                        & (df[fines2_COL]>=float(temp_df['fines_stn2_low'][0])) & (df[fines2_COL]<float(temp_df['fines_stn2_high'][0]))]  
                # req_df.to_excel("bin_"+str(profile)+".xlsx")
                if req_df.shape[0]>0:
                        min_range=req_df[station2_controls][req_df[station2_controls]>0].min().reset_index().set_index('index').T
                        reg_lst= min_range.values.flatten().tolist()
                        for i,j in enumerate(list(reg_lst)):
                            if j==5 and req_df[station2_controls].iloc[:,i].name.find("force MV kN_station_t") != -1:
                                min_range.iloc[:,i]=req_df[station2_controls].iloc[:,i][req_df[station2_controls].iloc[:,i]>5].min()
                        cols=[col+'_lower_bound' for col in min_range.columns.tolist()]
                        min_range.columns=cols
                        max_range=req_df[station2_controls].max().reset_index().set_index('index').T
                        reg_lst= max_range.values.flatten().tolist()
                        for i,j in enumerate(list(reg_lst)):
                            if j==5 and req_df[station2_controls].iloc[:,i].name.find("force MV kN_station_1") != -1:
                                max_range.iloc[:,i]=req_df[station2_controls].iloc[:,i][req_df[station2_controls].iloc[:,i]<5].max()

                        cols=[col+'_upper_bound' for col in max_range.columns.tolist()]
                        max_range.columns=cols
                        mode_df=req_df[station2_controls].mode().head(1)
                        cols=[col+'_mode' for col in mode_df.columns.tolist()]
                        mode_df.columns=cols
                        ranges=pd.concat([min_range,max_range,mode_df], axis=1)
                        ranges['profile_id']=[profile]
                        ranges['#_of_batches']=[req_df.shape[0]]
                        ranges['batches']=[req_df['BATCH_ID'].unique().tolist()]
                        char_df=char_df.append(ranges)
            profile_df=profile_df.merge(char_df, on=['profile_id'], how='left',validate='1:1')
            if profile_df.isnull().values.any() == True:
                nulldf.append(profile_df)
            else:
                gooddf.append(profile_df)
        Good_bin_combinations = print("In this data there are " , len(gooddf) , "possible combinations of bins without any null values" )
        Bad_bin_combinations = print("In this data there are " , len(nulldf) , "possible combinations of bins with null values" )
        

        #New Code Added ---------------------------
        str1 = "In this data there are "+  str(len(gooddf)) + "possible combinations of bins without any null values"
        str2 = "In this data there are "+  str(len(nulldf)) + "possible combinations of bins with null values"
        info_dict = {'info'+stationNo : [str1,str2]}
        info_dict_df = pd.DataFrame(info_dict)

        # print(len(nulldf))
        # print(len(gooddf))
        # try:
        #     book=dt.create_Sheet(book,'null_df'+stationNo,nulldf)
        # except Exception as error:
        #     logging.error('(compression_function.py) --> (Station1_Bin_Creator) --> Error in Creating the Sheet')
        #     traceback.print_exc()

        # try:
        #     book=dt.create_Sheet(book,'gooddf'+stationNo,gooddf)
        # except Exception as error:
        #     logging.error('(compression_function.py) --> (Station1_Bin_Creator) --> Error in Creating the Sheet')
        #     traceback.print_exc()

        # -------------------------------------------

        # return nulldf,gooddf
        return book,info_dict_df,gooddf
        
        # return nulldf,gooddf
        # return Good_bin_combinations,Bad_bin_combinations 

    def Explore_df_list(self,goodlist,book,dt,info_dict_df,stationNo):

        """
        This function will simplify the List of Dataframes obtained from the Bin Creator Functions.
        It will count the number of rows in each of the dataframe and group them accordingly and will return the list indices of those dataframes.
        Also it will compare the dataframes and select the best possible solution dataframe out of all and will return their list indices as well.

        Args: List of Dataframe obtained from Bin Creator Functions

        Usage Example:
        You can run this function in below way,
        pgs.Explore_df_list(good_stn2)

        """

        two_loc=[]
        four_loc =[]
        eight_loc =[]
        sixteen_loc = []
        for i in range (len(goodlist)):
            if (goodlist[i].shape)[0] == 4:
                four_loc.append(i)
            elif (goodlist[i].shape)[0] == 8:
                eight_loc.append(i)
            elif (goodlist[i].shape)[0] == 2:
                two_loc.append(i)
            else:
                sixteen_loc.append(i)
        two = print("Profile df with 2 rows are present at",two_loc, "locations in the given list of dataframes.\n")
        four = print("Profile df with 4 rows are present at",four_loc, "locations in the given list of dataframes.\n") 
        eight = print("Profile df with 8 rows are present at",eight_loc, "locations in the passed list of dataframes.\n")
        sixteen = print("Profile df with 16 rows are present at",sixteen_loc, "locations in the passed list of dataframes.\n")
        
        two_str = "Profile df with 2 rows are present at"+str(two_loc)+ "locations in the given list of dataframes"
        four_str = "Profile df with 4 rows are present at"+str(four_loc)+ "locations in the given list of dataframes"
        eight_str = "Profile df with 8 rows are present at"+str(eight_loc)+ "locations in the given list of dataframes"
        sixteen_str = "Profile df with 16 rows are present at"+str(sixteen_loc)+ "locations in the passed list of dataframes"
        
        b4=[]
        b2=[]
        b8=[]
        b16=[]
        
        for j in (four_loc):
            b4.append(goodlist[j]['#_of_batches'].min())
        for k in (two_loc):
            b2.append(goodlist[k]['#_of_batches'].min())
        for l in (eight_loc):
            b8.append(goodlist[l]['#_of_batches'].min())
        for m in (sixteen_loc):
            b16.append(goodlist[m]['#_of_batches'].min())
        
        
        if len(b2) == 0 :
            fb2="No solutions with 2 Rows"
        else: 
            fb2=[]
            index_list2 = [index for index in range(len(b2)) if b2[index] == max(b2)]
            for x in (index_list2):
                fb2.append(two_loc[x])
                
        if len(b4) == 0 :
            fb4="No solutions with 4 Rows"
        else:
            fb4=[]
            index_list4 = [index for index in range(len(b4)) if b4[index] == max(b4)]
            for y in (index_list4):
                fb4.append(four_loc[y])
                
        if len(b8) == 0 :
            fb8="No solutions with 8 Rows"
        else:
            fb8=[]
            index_list8 = [index for index in range(len(b8)) if b8[index] == max(b8)]
            for z in (index_list8):
                fb8.append(eight_loc[z])
        
        if len(b16) == 0 :
            fb16="No solutions with 16 Rows"
        else:
            fb16=[]
            index_list16 = [index for index in range(len(b16)) if b16[index] == max(b16)]
            for w in (index_list16):
                fb16.append(sixteen_loc[w])
                
        bsol2 = print("The best possible solution with 2 rows is present at location  : " ,fb2, "\n")
        bsol4 = print("The best possible solution with 4 rows is present at location : " ,fb4, "\n")
        bsol8 = print("The best possible solution with 8 rows is present at location : " ,fb8, "\n")
        bsol16 = print("The best possible solution with 16 rows is present at location : " ,fb16, "\n")

        bsol2 = "The best possible solution with 2 rows is present at location  : " +str(fb2)
        bsol4 = "The best possible solution with 4 rows is present at location  : " +str(fb4)
        bsol8 = "The best possible solution with 8 rows is present at location  : " +str(fb8)
        bsol16 = "The best possible solution with 16 rows is present at location  : " +str(fb16)

        info = 'info'+stationNo
        info_dict = {info : [two_str,four_str,eight_str,sixteen_str,bsol2,bsol4,bsol8,bsol16]}
        info_dict_explore_df = pd.DataFrame(info_dict)

        info_dict_df_Final = info_dict_df.append(info_dict_explore_df)

        try:
            book=dt.create_Sheet(book,info,info_dict_df_Final)
        except Exception as error:
            logging.error('(compression_function.py) --> (Explore_df_list) --> Error in Creating the Sheet')
            traceback.print_exc()

        final_list_index = []

        if type(fb2) == list:
            final_list_index = final_list_index + fb2

        if type(fb4) == list:
            final_list_index = final_list_index + fb4

        if type(fb8) == list:
            final_list_index = final_list_index + fb8

        if type(fb16) == list:
            final_list_index = final_list_index + fb16

        for i in final_list_index:
            try:
                book=dt.create_Sheet(book,'gooddf_at_index_'+str(i)+'_'+stationNo,goodlist[i])
            except Exception as error:
                logging.error('(compression_function.py) --> (Station1_Bin_Creator) --> Error in Creating the Sheet')
                traceback.print_exc()

        return book



        
        



        
        #return two,four,eight,sixteen