from ciplibrary_model.assign_variables import Variables 
from ciplibrary_model.dataframe_creation import dataframe 
from ciplibrary_model.granulation_functions import granulationFn
from ciplibrary_model.EDA import EDA
from ciplibrary_model.model_building import  ml_model
from ciplibrary_model.model_building_updated  import ml_model_updated
import traceback
import logging
import time
from ciplibrary_model.sql_logging.sqlLogger import SQL_Logger
from ciplibrary_model.coating_function import CoatingFn
from ciplibrary_model.compression_function import OEE_Compression_Model
import yaml
import pandas as pd
import numpy as np
import os
import seaborn as sns
from tqdm import tqdm
import warnings
warnings.simplefilter("ignore")
import matplotlib.dates as mdates
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
warnings.simplefilter("ignore")
from sklearn.linear_model import ElasticNet, ElasticNetCV
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error, make_scorer
from sklearn import preprocessing
from sklearn.metrics import r2_score
import re
import shap
from sklearn.model_selection import train_test_split
import itertools
from operator import mul
from functools import reduce
import statsmodels.api as sm
from matplotlib import pyplot as plt
from pdpbox import pdp, info_plots
# import pandas_profiling as pp
import matplotlib.backends.backend_pdf
from matplotlib.backends.backend_pdf import PdfPages
import colorama
from colorama import Fore
from pandas import ExcelWriter
from datetime import datetime
import xlwt 
pd.set_option('display.max_rows', 1000)
pd.set_option('display.max_columns', None)

from pyspark.sql.types import *
from ciplibrary_model.SQLConnection_DS import SQLConnection_DS
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark.sql.functions import col
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("SparkSql").getOrCreate()

def pegasus_model(yml_path,base_path):

    logging.basicConfig(filename='/dbfs/mnt/pegasusdatalake/MLOps/DS/Logging.log', 
    level=logging.INFO,  filemode='w',
    format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')  # For DataBricks

    
    logging.info('(Pegasus.py) --> (pegasus_model) --> { Inside Pegasus_model Method }')
    logging.info('(Pegasus.py) --> (pegasus_model) --> { YML Path is : %s }', yml_path)
    logging.info('(Pegasus.py) --> (pegasus_model) --> { Base Path is : %s }', base_path)

    start_time = time.time()
    logging.info('(Pegasus.py) --> (pegasus_model) --> { Start Time Of the Application is : %s}',start_time) 

    logging.info('(Pegasus.py) --> (pegasus_model) --> { Creating the DataFrame.py Object Instance }') 
    dt=dataframe()
    try:
        yaml_df= dt.Yaml_df_creation_Optimized(yml_path)
    except Exception as error:
        logging.error('(Pegasus.py) --> (pegasus_model) --> Failed to Read YML File')
        logging.exception(error)
        traceback.print_exc()
        raise Exception( f"YML is failed. Please check the log file for Details" ) 
   
    print(yaml_df)
    # yaml_df.to_csv('yaml_df.csv')
    # Creating the DataFrame For SQL Logs
    sql_df = pd.DataFrame(columns=['MACHINECODE','PRODUCTCODE','LINE','UNIT','SITE','BATCH_SIZE','PRODUCTNAME','MIN_BATCHID','MAX_BATCHID','DATETIME','USECASE','STAGE','SUBSTAGE','DS_NAME','DE_NAME','ACCURACY_TRAIN','ACCURACY_TEST','RMSE_TRAIN','RMSE_TEST','REFINED_COUNT','REFRESHED_DATE','NO_BATCHES','OUTPUT_DIR'])

    # Model run has started 
    for index, row in yaml_df.iterrows():
        logging.info('(Pegasus.py) --> (pegasus_model) --> { Iterating the Yaml DF for product : %s}' , row['product_name'])
        print("-------------------------------------OOOO----------------")
        print(row)
        logging.info('(Pegasus.py) --> (pegasus_model) --> { Creating the Object of SQL Logger}')
        sql_logs = SQL_Logger()
        # Extracting Yaml variable from dataframe to python variables
        logging.info('(Pegasus.py) --> (pegasus_model) --> { Creating the V1 Object from Data Frame}')
        v1 = dt.create_variables_optimized(row)
        # Creating model outputfile name                
        output_file_name=globals()[f'{v1.site}_'+f'{v1.unit}_'+f'{v1.product_code}_'+f'{v1.machine_code}_'+f'{v1.batch_size}_'+f'{v1.stage}_'+f'{v1.use_case}']=f'{v1.site}_'+f'{v1.unit}_'+f'{v1.product_code}_'+f'{v1.machine_code}_'+f'{v1.batch_size}_'+f'{v1.stage}_'+f'{v1.use_case}'

        sql_logs.MACHINECODE = v1.machine_code
        sql_logs.PRODUCTCODE = v1.product_code
        sql_logs.LINE = v1.line
        sql_logs.UNIT = v1.unit
        sql_logs.SITE= v1.site
        sql_logs.BATCH_SIZE = v1.batch_size
        sql_logs.PRODUCTNAME = v1.product_name
        sql_logs.DATETIME = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        sql_logs.USECASE = v1.use_case
        sql_logs.STAGE = v1.stage
        sql_logs.DS_NAME = 'Will Get From YML'
        sql_logs.DE_NAME = 'Will Get From YML'
        query = "select max(MODEL_REFINED_COUNT) from default.model_output where PRODUCTCODE = '{}' and MACHINECODE = '{}' and BATCH_SIZE = {};".format(v1.product_code,v1.product_name,v1.batch_size) 
        # sql_logs.REFINED_COUNT = v1.check_SQL_Query(query)
        site_unit=f'{v1.site} {v1.unit}'
        ## {{{Pending}}})
        v1.timeline=str('01-01') + "-" +str('01-05')

#---------------------------IMPORTING THE DATA--------------------------------------------------
        try:
            logging.info('(Pegasus.py) --> (pegasus_model) --> { Importing the Data in Application}')
            df=v1.data_import()
            df = df.drop_duplicates()
        except Exception as error:
            logging.error('(Pegasus.py) --> (pegasus_model) --> Error in Importing the Data')
            logging.exception(error)
            traceback.print_exc()
            continue
          
#------------------------------EXPORTING RAW DATA IN EXCEL--------------------------------------------------------------------

        raw_df=df.copy()
        print(df.columns)
        # creating excel file and writing output of each steps
        logging.info('(Pegasus.py) --> (pegasus_model) --> { Creating the Object Of Excel Workbook }')
        print('(Pegasus.py) --> (pegasus_model) --> { Creating the Object Of Excel Workbook }')
        book = xlwt.Workbook()
        try:
            book=dt.create_Sheet(book,'raw_data',df)
        except Exception as error:
            logging.error('(Pegasus.py) --> (pegasus_model) --> Error in Creating the Sheet')
            traceback.print_exc()
#------------------------------ EDA ::: EXPORTING THE DF NULL COUNT INFORMATION TO EXCEL--------------------------------------------------------------------
        logging.info('(Pegasus.py) --> (pegasus_model) --> { Creating the Object EDA Class }')
        eda=EDA()
        logging.info('(Pegasus.py) --> (pegasus_model) --> { Getting the Info of DataFrame }')
        df_null_count=eda.get_dataframe_info(df)
        book=dt.create_Sheet(book,'df_info',df_null_count)

#------------------------------EDA ::: DATA VALIDATION STARTED--------------------------------------------------------------------
        logging.info('(Pegasus.py) --> (pegasus_model) --> {  Step1: Data validation started: }')
        print('\033[94m' + '\033[1m'+'#######################################  Step1: Data validation started: #########################################################'+ '\033[0m')
        try:
            m1,book = eda.data_validation(df,book,v1,dt)
        except Exception as error:
            logging.error('(Pegasus.py) --> (pegasus_model) --> Error in Data Validation { ' +str(error)+ ' }')
            traceback.print_exc()
            continue
        
#-------------------------------CALCULATING THE MIN_Batch_ID and MAX_BATCH_ID and NO_Of_Batches-------------------------------------------------------------------

        unique_batches = m1[v1.batch_id].unique()
        print("UNIQUE_BATCHES********")
        logging.info("UNIQUE_BATCHES********")
        logging.info(unique_batches)
        logging.info(unique_batches.shape)
        print(unique_batches)
        unique_batches.sort()

        sql_logs.MIN_BATCHID = unique_batches[0]
        sql_logs.MAX_BATCHID = unique_batches[-1]
        sql_logs.NO_BATCHES = len(unique_batches)

#-------------------------------EDA :: DROPPING COLUMNS STARTED-------------------------------------------------------------------
    
        logging.info('(Pegasus.py) --> (pegasus_model) --> {  Step2: Dropping columns started }')
        print(" ")
        print('\033[94m' + '\033[1m'+'####################################### Step2: Dropping columns started: #########################################################'+ '\033[0m')
        try:
            m2,book = eda.dropping_columns(m1,book,v1)
            print("AFTER DROPPING COLUMNS")
            print(m2.shape)
        except Exception as error:
            logging.error('(Pegasus.py) --> (pegasus_model) --> Error in EDA Dropping Columns')
            traceback.print_exc()
            logging.exception(error)

#-------------------------------GRANULATION AND COATING STARTED-------------------------------------------------------------------

        if v1.stage.lower()=='granulation' or v1.stage.lower()=='coating' :
            logging.info('Preparing Model for %s  stage',v1.stage)
            logging.info('Preparing Model for %s  Usecase',v1.use_case)

            if v1.use_case.lower()=='oee' or v1.use_case.lower()=='yield' or v1.use_case.lower()=='all':
                logging.info('(Pegasus.py) --> (pegasus_model) --> Inside  Usecase')
                if v1.stage.lower()=='granulation':
                    granulation=granulationFn()
                    #---------------------------------FF FENERATOR 2 Stareted FOr GRANULATION --------------------------------
                    try:
                        DRYING, SPRAYING,PREWARMING =granulation.OEE_Granulation_FF_generator_2(m2,book,v1,dt)
                    except Exception as error:
                        logging.error('(Pegasus.py) --> (pegasus_model) --> Error in OEE_Granulation_FF_generator_2')
                        traceback.print_exc()
                        logging.exception(error)
                        continue
                elif v1.stage.lower()=='coating':
                    coating_func = CoatingFn()
                    #---------------------------------FF FENERATOR 2 Stareted FOr COating --------------------------------
                    try:
                        DRYING, SPRAYING,PREWARMING =coating_func.OEE_Coating_generator_2(m2,book,v1,dt)
                    except Exception as error:
                        logging.error('(Pegasus.py) --> (pegasus_model) --> Error in OEE_Coating_generator_2')
                        traceback.print_exc()
                        logging.exception(error)
                        continue

                df_names=['DRYING', 'SPRAYING','PREWARMING']
                df_list=[DRYING, SPRAYING,PREWARMING]
                
                for i, df in enumerate(df_list):
                    if df.empty:
                        print(df_names[i] + "is empty. Not Required for Modelling")
                        logging.info("DataFrame For %s is Empty",df_names[i])
                        continue;
                    else:
                        #-----------------------Imputing 0 values with NAN & Dropping columns whrer NAN > missing percentages-----------------------------------------
                        col_list1=df.columns.to_list()
                        for tag in col_list1:
                            df[tag] = df[tag].replace(to_replace=0,value=np.NaN)
                        df = df.drop(df.columns[df.isnull().mean()>float(v1.missing_value_perc)],axis=1)
                        # ---------------------------Imputing MIssing Values with means------------------------------------------------
                        for tag in col_list1:
                                df[tag] = eval('df[tag].fillna(df[tag].'+v1.impute_missing_values_by+'())')
                        
                        #-----------------------Checking the Columns with Having zero counts------------------------------------------
                        print('CHECKING NO OF ZEROS')
                        for column_name in df.columns:
                            column = df[column_name]
                            # Get the count of Zeros in column 
                            count = (column == 0).sum()
                            print('Count of zeros in column ', column_name, ' is : ', count)

                        if v1.stage.lower()=='granulation':
                            sql_logs.SUBSTAGE = df_names[i]
                            #---------------------------------FF FENERATOR 4 Stareted FOr Granulation --------------------------------
                            try:
                                df_list[i] = granulation.OEE_Granulation_FF_generator_4(df,book,v1)
                            except Exception as error:
                                logging.error('(Pegasus.py) --> (pegasus_model) --> Error in OEE_Granulation_FF_generator_4')
                                traceback.print_exc()
                                logging.exception(error)
                                continue

                        elif v1.stage.lower()=='coating':
                            sql_logs.SUBSTAGE = df_names[i]
                            #---------------------------------FF FENERATOR 4 Stareted FOr COating --------------------------------
                            try:
                                df_list[i] = coating_func.OEE_Coating_FF_generator_4(df,book,v1)
                                print('AFTER FFGENARATOR 4')
                            except Exception as error:
                                logging.error('(Pegasus.py) --> (pegasus_model) --> Error in OEE_Coating_FF_generator_3')
                                traceback.print_exc()
                                logging.exception(error)
                                continue

                print("Cleaning the dataframe")
                logging.info('(Pegasus.py) --> (pegasus_model) --> { Cleaning the dataframe1 }')
                for df_name, df in zip(df_names, df_list):
                    if df.empty:
                        print(df_name)
                        continue;
                    else:
                        exec(f'{df_name}_cleaned = df')
                
                for i,df in enumerate(df_list):
                    if df.empty:
                        logging.info('(Pegasus.py) --> (pegasus_model) --> { Df %s is Empty }',df_names[i])
                        continue;
                    else:
                        #-----------------------CREATING THE DIRECTORY STRUCTURE-----------------------------------------   
                        sub_file_name='_'+df_names[i]
                        print(v1.product_name)
                        logging.info('(Pegasus.py) --> (pegasus_model) --> { Creating Directory For %s }',df_names[i])
                        path = os.path.join(base_path,site_unit,v1.product_name,str(v1.batch_size),v1.stage,df_names[i],v1.machine_code,v1.line,v1.use_case,v1.timeline)
                        #Creating directories for raw data, input data, report data, output data and code 
                        RAW_DATA_DIR,FLAT_DIR, REPORT_DIR, OUTPUT_DIR, CODE_DIR = v1.create_directory(path)

                        sql_logs.OUTPUT_DIR = OUTPUT_DIR    

                        #-------------------------------------------------------------------------------                           
                        raw_data_name=v1.product_name+"_raw.csv"

                        try:
                            raw_df.to_csv(os.path.join(RAW_DATA_DIR,raw_data_name))
                        except Exception as error:
                            logging.error('(Pegasus.py) --> (pegasus_model) --> Error in Exporting Raw DF')
                            traceback.print_exc()
                            logging.exception(error)
                            continue

                        #-------------------------EDA: DATA CLEANING HAS BEEN STARTED---------------------------------------
                        try:
                            model_input=eda.DataCleaning(df,book,v1,dt,sub_file_name,REPORT_DIR)
                            logging.info('@@@@')
                            logging.info(model_input)
                            print(model_input)
                        except Exception as error:
                            logging.error('(Pegasus.py) --> (pegasus_model) --> Error in DataCleaning')
                            traceback.print_exc()
                            logging.exception(error)
                            continue

                        input_name=v1.product_name+"_"+sub_file_name+".csv"
                        model_input.to_csv(os.path.join(FLAT_DIR,input_name))

                        #----------------------------MODEL BULDING HAS BEEN STARTED--------------------------------------------------
                        
                        print('\033[94m' + '\033[1m'+'####################################### Step3.2: Granulation CT Model: #########################################################'+ '\033[0m')
                        ml=ml_model_updated()
                        try:
                            sql_logs = ml.model_building(model_input,v1.cv,v1.random_state,v1.niter,v1.target_column,v1.test_size,output_file_name,book,OUTPUT_DIR,sub_file_name,v1,dt,sql_logs,i)
                        except Exception as error:
                            logging.error('(Pegasus.py) --> (pegasus_model) --> Model Building Failed. Kindly Check Logs')
                            traceback.print_exc()
                            logging.exception(error)
                            continue

                        #------------------------------------------------------------------------------

        if v1.stage.lower()=='compression':
            sql_logs.SUBSTAGE = 'ALL_OPTIMIZED'
            if v1.use_case.lower()=='yield':
                sub_file_name='all_optimized'
                logging.info('(Pegasus.py) --> (pegasus_model) --> { Creating Directory For (Compression Yield) (Yield)}')
                path = os.path.join(base_path,site_unit,v1.product_name,str(v1.batch_size),v1.stage,sub_file_name,v1.machine_code,v1.line,v1.use_case,v1.timeline)
                #Creating directories for raw data, input data, report data, output data and code 
                RAW_DATA_DIR,FLAT_DIR, REPORT_DIR, OUTPUT_DIR,CODE_DIR = v1.create_directory(path)
                logging.info('-----------DIRECTORY1---------------')
                logging.info(RAW_DATA_DIR)
                logging.info(CODE_DIR)
                logging.info(OUTPUT_DIR)
                sql_logs.OUTPUT_DIR = OUTPUT_DIR
                print('\033[94m' + '\033[1m'+'####################################### Step3.1: (Compression Yield) EDA: #########################################################'+ '\033[0m')
                print('BEFORE IMPUTER')
                # print(m2.head())
                col_list1=m2.columns.to_list()
                col_list1.remove(v1.batch_id)
                # Imputing missing values by mean
                # print(df[df['DRIVE_SPEED_ACT'] == 0].shape)
                for tag in col_list1:
                    m2[tag] = m2[tag].replace(to_replace=0,value=np.NaN)
                    m2[tag] = eval('m2[tag].fillna(m2[tag].'+v1.impute_missing_values_by+'())')
                # print('ZEROS')
                # print(m2.isna().sum())
                try:
                    m2.set_index(v1.batch_id,inplace=True) # {{{ Need to be checked while Testing}}}
                    model_input=eda.DataCleaning(m2,book,v1,dt,sub_file_name,REPORT_DIR)
                except Exception as error:
                    logging.error('(Pegasus.py) --> (pegasus_model) --> Error in DataCleaning (Yield)')
                    traceback.print_exc()
                    logging.exception(error)
                    continue

                input_name=v1.product_name+".csv"
                model_input.to_csv(os.path.join(FLAT_DIR,input_name))

                print('\033[94m' + '\033[1m'+'####################################### Step3.2: (Compression Yield)  Model: #########################################################'+ '\033[0m')
                ml=ml_model()
                try:
                    sql_logs = ml.model_building(model_input,v1.cv,v1.random_state,v1.niter,v1.target_column,v1.test_size,output_file_name,book,OUTPUT_DIR,sub_file_name,v1,dt,sql_logs)
                except Exception as error:
                    logging.error('(Pegasus.py) --> (pegasus_model) --> Model Building Failed (Compression Yield). Kindly Check Logs')
                    traceback.print_exc()
                    logging.exception(error)
                    continue
            elif v1.use_case.lower()=='oee':
                print('\033[94m' + '\033[1m'+"$$$$$$$$$$$$$$$$$Next Run Will start$$$$$$"+'\033[94m' + '\033[1m')
                print("OEE Compression")
                
                sub_file_name='all_optimized'
                logging.info('(Pegasus.py) --> (pegasus_model) --> { Creating Directory For (Compression OEE) (OEE)}')
                path = os.path.join(base_path,site_unit,v1.product_name,str(v1.batch_size),v1.stage,sub_file_name,v1.machine_code,v1.line,v1.use_case,v1.timeline)
                #Creating directories for raw data, input data, report data, output data and code 
                print(path)
                RAW_DATA_DIR,FLAT_DIR, REPORT_DIR, OUTPUT_DIR,CODE_DIR = v1.create_directory(path)
                logging.info('-----------DIRECTORY2---------------')
                logging.info(RAW_DATA_DIR)
                logging.info(CODE_DIR)
                logging.info(OUTPUT_DIR)
                # sql_logs.Flat_dir = FLAT_DIR
                sql_logs.OUTPUT_DIR = OUTPUT_DIR
                # sql_logs.Reporting_dir = REPORT_DIR
                # sql_logs.Notebook_path = CODE_DIR
                # df.set_index(v1.batch_id,drop=True,inplace=True)
                col_list1=df.columns.to_list()
                col_list1.remove(v1.batch_id)
                print(col_list1)
                print(df.info())
                # Imputing missing values by mean
                # print(df[df['DRIVE_SPEED_ACT'] == 0].shape)
                for tag in col_list1:
                    df[tag] = df[tag].replace(to_replace=0,value=np.NaN)
                    df[tag] = eval('df[tag].fillna(df[tag].'+v1.impute_missing_values_by+'())')
                # print(df.info())

                OEE_Compression = OEE_Compression_Model()
                print(v1.other)
                print(v1.other['StationType'])
              #  {{{ We need to change the Name After standarization of flat file}}}
                if  v1.other['StationType'].lower() == 'singlestationsingleapqr':
                    print('Inside Station 1')
                    input_data = { 
                    'df':m2,
                    'LOD':'LOSS_ON_DRYING_STATION_1',
                    'Bulk_Density':'BULK_DENSITY_STATION_1',
                    'Tapped_Density':'TAPPED_DENSITY_STATION_1',
                    'Fines':'FINES_STATION_1',
                    'Tablet_cyl_ht_Main_Station1':'TABL_CYL_HT_MAIN_CO_MM_STATION_1',
                    'Tablet_cyl_ht_Pre_Station1' : 'TABL_CYL_HT_PRE_CO_MM_STATION_1',
                    'Main_comp_force':'MAIN_COMPR_FORCE_MV_KN_STATION_1',
                    'Pre_comp_force': 'PRE_COMPR_FORCE_MV_KN_STATION_1',
                    'Tablet_filling_depth_Station1': 'TABL_FILLING_DEPTH_MM_STATION_1',
                    'book' : book,
                    'dt' : dt
                    }
                    print(m2)
                    book,info_dict_df,gooddf = OEE_Compression.Station1_Bin_Creator(**input_data)
                    book = OEE_Compression.Explore_df_list(gooddf,book,dt,info_dict_df,'station1')

                elif v1.other['StationType'].lower() == 'doublestationsingleapqr':
                    print('INside DoubleStation Single APQR')
                    logging.info('(Pegasus.py) --> (pegasus_model) --> Inside doublestationsingleapqr')

                    input_data_station1 = { 'df':df,
                    'LOD':'LOSS_ON_DRYING_STATION_1',
                    'Bulk_Density':'BULK_DENSITY_STATION_1',
                    'Tapped_Density':'TAPPED_DENSITY_STATION_1',
                    'Fines':'FINES_STATION_1',
                    'Tablet_cyl_ht_Main_Station2' : 'TABL_CYL_HT_MAIN_CO_MM_STATION_1',
                    'Tablet_cyl_ht_Pre_Station2' : 'TABL_CYL_HT_PRE_CO_MM_STATION_1',
                    'Main_comp_force_stn2':'MAIN_COMPR_FORCE_MV_KN_STATION_1',
                    'Pre_comp_force_stn2':'PRE_COMPR_FORCE_MV_KN_STATION_1',
                    'Tablet_filling_depth_Station2':'TABL_FILLING_DEPTH_MM_STATION_1',
                    'book' : book,
                    'dt' : dt,
                    'stationNo' : 'station1'
                    }

                    book,info_dict_df,gooddf = OEE_Compression.Station2_SingleAPQR_Data_Bin_Creator(**input_data_station1)
                    book = OEE_Compression.Explore_df_list(gooddf,book,dt,info_dict_df,'station1')

                    input_data_station2 = { 'df':df,
                    'LOD':'LOSS_ON_DRYING_STATION_1',
                    'Bulk_Density':'BULK_DENSITY_STATION_1',
                    'Tapped_Density':'TAPPED_DENSITY_STATION_1',
                    'Fines':'FINES_STATION_1',
                    'Tablet_cyl_ht_Main_Station2' : 'TABL_CYL_HT_MAIN_CO_MM_STATION_2',
                    'Tablet_cyl_ht_Pre_Station2' : 'TABL_CYL_HT_PRE_CO_MM_STATION_2',
                    'Main_comp_force_stn2':'MAIN_COMPR_FORCE_MV_KN_STATION_2',
                    'Pre_comp_force_stn2':'PRE_COMPR_FORCE_MV_KN_STATION_2',
                    'Tablet_filling_depth_Station2':'TABL_FILLING_DEPTH_MM_STATION_2',
                    'book' : book,
                    'dt' : dt,
                    'stationNo' : 'station2'
                    }

                    book,info_dict_df,gooddf = OEE_Compression.Station2_SingleAPQR_Data_Bin_Creator(**input_data_station2)
                    book = OEE_Compression.Explore_df_list(gooddf,book,dt,info_dict_df,'station2')
                    
                    
                elif v1.other['StationType'].lower() == 'doublestationdoubleapqr':
                    input_data = { 
                        'df':df,
                        'LOD':'LOSS_ON_DRYING_STATION_1',
                        'Bulk_Density':'BULK_DENSITY_STATION_1',
                        'Tapped_Density':'TAPPED_DENSITY_STATION_1',
                        'Fines':'FINES_STATION_1',
                        # 'LOD2':'LOSS_ON_DRYING_STATION_2',
                        # 'Bulk_Density2':'BULK_DENSITY_STATION_2',
                        # 'Tapped_Density2':'TAPPED_DENSITY_STATION_2',
                        # 'Fines2':'FINES_STATION_2',     
                        'Tablet_cyl_ht_Main_Station1' : 'TABL_CYL_HT_MAIN_CO_MM_STATION_1',
                        'Tablet_cyl_ht_Pre_Station1' : 'TABL_CYL_HT_PRE_CO_MM_STATION_1',
                        'Main_comp_force':'MAIN_COMPR_FORCE_MV_KN_STATION_1',
                        'Pre_comp_force':'PRE_COMPR_FORCE_MV_KN_STATION_1',
                        'Tablet_filling_depth_Station1':'TABL_FILLING_DEPTH_MM_STATION_1',
                        'book' : book,
                        'dt' : dt
                        # 'stationNo' : 'station1'

                    }
                    book,info_dict_df,gooddf = OEE_Compression.Station1_Bin_Creator(**input_data)
                    book = OEE_Compression.Explore_df_list(gooddf,book,dt,info_dict_df,'station1')

                    input_data_2 = { 'df':df,
                        'LOD1':'LOSS_ON_DRYING_STATION_1',
                        'Bulk_Density1':'BULK_DENSITY_STATION_1',
                        'Tapped_Density1':'TAPPED_DENSITY_STATION_1',
                        'Fines1':'FINES_STATION_1',
                        'LOD2':'LOSS_ON_DRYING_STATION_2',
                        'Bulk_Density2':'BULK_DENSITY_STATION_2',
                        'Tapped_Density2':'TAPPED_DENSITY_STATION_2',
                        'Fines2':'FINES_STATION_2',     
                        'Tablet_cyl_ht_Main_Station2' : 'TABL_CYL_HT_MAIN_CO_MM_STATION_2',
                        'Tablet_cyl_ht_Pre_Station2' : 'TABL_CYL_HT_PRE_CO_MM_STATION_2',
                        'Main_comp_force_stn2':'MAIN_COMPR_FORCE_MV_KN_STATION_2',
                        'Pre_comp_force_stn2':'PRE_COMPR_FORCE_MV_KN_STATION_2',
                        'Tablet_filling_depth_Station2':'TABL_FILLING_DEPTH_MM_STATION_2',
                        'book' : book,
                        'dt' : dt,
                        'stationNo' : 'station2'
                    }
                    book,info_dict_df,gooddf = OEE_Compression.Station2_DL_DoubleAPQR_Data_Bin_Creator(**input_data_2)
                    book = OEE_Compression.Explore_df_list(gooddf,book,dt,info_dict_df,'station2')
                    

        book.save(OUTPUT_DIR+'\\'+output_file_name+"_"+v1.date_string+'.xls')

#--------------------------------------------------------------------------------------------------------------------
        import pyspark.sql.types as T
        import pyspark.sql.functions as F
        from pyspark.sql.functions import col
        
        from pyspark.sql import SparkSession
        sql_logs_schemas = T.StructType(
            [
            T.StructField('MACHINECODE', T.StringType(), True),
            T.StructField('PRODUCTCODE', T.StringType(), True),
            T.StructField('LINE', T.StringType(), True),
            T.StructField('UNIT', T.StringType(), True),
            T.StructField('SITE', T.StringType(), True),
            T.StructField('BATCH_SIZE', T.StringType(), True),
            T.StructField('PRODUCTNAME', T.StringType(), True),
            T.StructField('MIN_BATCHID', T.StringType(), True),
            T.StructField('MAX_BATCHID', T.StringType(), True),
            T.StructField('DATETIME', T.StringType(), True),
            T.StructField('USECASE', T.StringType(), True),
            T.StructField('STAGE', T.StringType(), True),
            T.StructField('SUBSTAGE', T.StringType(), True),
            T.StructField('DS_NAME', T.StringType(), True),
            T.StructField('DE_NAME', T.StringType(), True),
            T.StructField('ACCURACY_TRAIN', T.StringType(), True),
            T.StructField('ACCURACY_TEST', T.StringType(), True),
            T.StructField('RMSE_TRAIN', T.StringType(), True),
            T.StructField('RMSE_TEST', T.StringType(), True),
            T.StructField('REFINED_COUNT', T.StringType(), True),
            T.StructField('REFRESHED_DATE', T.StringType(), True),
            T.StructField('NO_BATCHES', T.StringType(), True),
            T.StructField('OUTPUT_DIR', T.StringType(), True),
            T.StructField('TIME_TAKEN', T.StringType(), True),
            T.StructField('MULTIOUTPUT', T.StringType(), True),
            ]
        )       
        

        sql_df=sql_logs.insert_SQL_DataFrame(sql_df)
        # sql_df['DATETIME'] = 
        logging.info(type(sql_df))
        logging.info(sql_df.shape)
        logging.info('---SQL_DF---')
        logging.info(sql_df)

        sql_df['ACCURACY_TRAIN'] = sql_df["ACCURACY_TRAIN"].astype(str)
        sql_df['ACCURACY_TEST'] = sql_df["ACCURACY_TEST"].astype(str)
        sql_df['RMSE_TRAIN'] = sql_df["RMSE_TRAIN"].astype(str)
        sql_df['RMSE_TEST'] = sql_df["RMSE_TEST"].astype(str)

        for i in sql_df.columns:
            sql_df[i] = sql_df[i].astype(str)

        # from pyspark import SparkConf
        # conf = SparkConf().setAppName("myapp")
        # conf.registerKryoClasses([SQLConnection])
        sparkdf = spark.createDataFrame(sql_df, schema=sql_logs_schemas)
        print('------SQL-----------')
        logging.info('--------SQL---------')
        logging.info(type(sparkdf))
        logging.info(sparkdf)
        #print(sparkdf)
        # logging.info(sparkdf.count(),sparkdf.columns)
        sql_connect = SQLConnection_DS()
        # sql_connect.write_spark_to_table(sparkdf,"dbo.MLOPS_PIPELINE_MODEL_OUTPUT")
    



                
