import os
import re
import time
import glob
import pdfplumber
import pandas as pd
from multiprocessing import Process




def concat_parquets(path,csvfilename):
    """
    This Function is used to combine multiple parquet files into one CSV file

    Args: 
      The input data for this function is a dictionary in below format containing the path where all the parquet files
      are located and the name of final CSV file to be created.
      
      concat_parquets_input = { 'path' : 'D:\\Goa 10 hmi data\\parquets',
                                'csvfilename' : 'test2.csv'
                              }
      Kindly make sure to provide the path separated with double backward slash '\\'

    Returns:
        It will create a CSV file in the current working directory location and will print the same.

    Usage Example:
        defs.concat_parquets(**concat_parquets_input)                  
    """
    processing_files1 = []
    writepath = os.getcwd()
    for root, dirs, files in os.walk(path):
        if files:
            processing_files1 += [root + "\\" +file for file in files]            
    data = pd.concat([pd.read_parquet(files) for files in processing_files1])
    #print(data)
    #data.to_parquet(writepath + filename ,index=False)
    data.to_csv(writepath +"\\"+csvfilename,index=False)
    return print("Concated CSV File created at --> " + writepath +"\\"+csvfilename )


def parameter_list_extraction_unit10(file):
    filepath = os.getcwd()
    print (file)
    with pdfplumber.open(file) as pdf:
        data_list = []
        pages = pdf.pages 
        parameter_no_list = []
        for page in range(len(pages)):
            extract = pages[page].extract_text()
            
            
            if not extract is None:
                if "Initial Recipe Setpoints Values" in extract:
                    equipment_id = file.split("\\")[-5]
                    try:
                        batch_id = re.findall("Batch Name: (.*)\nLot Number", extract)[0]
                        
                    except:
                        
                        continue 
                    try:
                        date_time = re.findall("Creation Date: (.*)\nCreated By", extract)[0]
                    except:
                        date_time = ""
                    try:
                        product_desc = re.findall("Recipe Name: (.*)\nRecipe Version", extract)[0]
                    except:
                        product_desc = ""
                    try:
                        operator_name = re.findall("Created By: (.*)\nComments", extract)[0]     
                    except:
                        operator_name = ""
                    for lines in extract.split("\n"):
                        lines = lines.split(" ")
                        if lines[0] in ["3007", "3009", "3015", "3016", "3017"]:
                            parameter_no_list.append(lines[0])
                            parameter_id = lines[0]
                            parameter_desc = " ".join(lines[1:-2]) + " " + lines[-1]
                            set_val = lines[-2]
                            data_list.append([equipment_id, batch_id, date_time, product_desc, operator_name, parameter_id, parameter_desc, set_val])
            if len(parameter_no_list) == 5:
                continue

    if data_list:
        source_file_split = file.split("\\")
        target_dir = '\\'.join(source_file_split[:-1]) + "\\flat_file\\"
        target_file = source_file_split[-1].replace("pdf", "parquet")
        df = pd.DataFrame(data_list)
        df.columns = ["equipment_id", "batch_id", "date_time", "product_desc", "operator_name", "parameter_id", "parameter_desc", "set_val"]
        df.to_parquet(filepath +"\\"+target_file, index = False)
#     df.to_parquet(self.inter_data_dir + '\\Losartan\\Losartan_Batches.parquet', object_encoding='json', engine='fastparquet', index = False)
        print (df)  



def process_HMI_reports_pdf_Goa_unit10(reportpath):
    """
    Note/Warning: This function will consume RAM heavaily, hence only run when your machine is IDLE else it will
                  result in Memory Overflow Error.
                  
    This function is used to extract the necessary parameters from the HMI reports generated from GOA Unit10 GEA-Machine
    Below parameters are being extracted from the PDF HMI reports:

    parameter_id                              parameter_desc  
        3007        Pre-Compression Compensator Force kN   
        3009  Final-Compression Compensator Force Top kN   
        3015                        Fill Depth Height mm   
        3016            Pre-Compression Bottom Height mm   
        3017          Final-Compression Bottom Height mm

    Args:
        The input for this function is the path where all the PDF reports are present.
        Kindly make sure to provide the path separated with double backward slash '\\'
    Returns:
        It will create a parquet file per pdf file in the Current Working Directory with all the required params

    Usage Example:
        defs.process_HMI_reports_pdf_Goa_unit10("D:\\Goa 10 hmi data\\2022 data\\remaining files")

    """
    
    if __name__ == "__main__":
        processing_files = []
        for root, dirs, files in os.walk(reportpath):
            if files:
                processing_files += [root + "\\" +file for file in files]
        print ("Files to process - " + str(len (processing_files[:10])))
    
        start_time = time.time()
        process_list = []
        for file in processing_files:
            parameter_list_extraction_unit10(file)
            process = Process(target=parameter_list_extraction_unit10, args=(file,))
            process.start()
            process.join()
            process_list.append(process)
        for processes in process_list:
            print (processes)
            processes.join()
        duration = time.time() - start_time
        print('Remote execution time: {}'.format(duration))