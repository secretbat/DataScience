import pandas as pd
import numpy as np
import os
import seaborn as sns
from tqdm import tqdm
import warnings
warnings.simplefilter("ignore")
import matplotlib.dates as mdates
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
warnings.simplefilter("ignore")
from sklearn.linear_model import ElasticNet, ElasticNetCV
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error, make_scorer
from sklearn import preprocessing
from sklearn.metrics import r2_score
import re
import shap
from sklearn.model_selection import train_test_split
import itertools
from operator import mul
from functools import reduce
import statsmodels.api as sm
from matplotlib import pyplot as plt
from pdpbox import pdp, get_dataset, info_plots
import matplotlib.backends.backend_pdf
from matplotlib.backends.backend_pdf import PdfPages
pd.set_option('display.max_rows', 1000)
pd.set_option('display.max_columns', None)

def OEE_Granulation_FF_generator_1(df,*args,**kwargs):
    
    global OEE_Gran1
    
    #print("Enter the dataframe variable name : ")
    data = df
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    # Dropping Garbage Columns
    print('\033[94m' + '\033[1m' +"Below are the columns present in the passed data frame : " + '\033[0m')
    column_list = list(data.columns)
    for j, it in enumerate(column_list):
        print(j,it)
    print('\033[94m' + '\033[1m'+"Please input the unnecessary columns indices as space separated if they are needed to be dropped : "+ '\033[0m')
    to_drop = input()
    to_drop =list(map(int, to_drop.split()))
    col_to_drop_list = [column_list[val1] for val1 in to_drop]
    if len(col_to_drop_list) != 0:
        data.drop(col_to_drop_list,axis=1,inplace=True)
    print(data.columns)    
    # Filtering the Data for Required Product
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[94m' + '\033[1m' +"Enter the Product column name : "+ '\033[0m')
    prd = input()
    print('\033[94m' + '\033[1m' +"The given dataframe contains these many products data : " + '\033[0m', data[prd].value_counts())
    prd_list = list(data[prd].unique())
    print('\033[94m' + '\033[1m' +"Below are the unique Products present here : "+ '\033[0m' )
    for i, item in enumerate(prd_list):
        print(i,item)
  
    print('\033[94m' + '\033[1m' +" Please select the index of the products for which the model needs to be prepared, input the indices separated by single space"+ '\033[0m')
    prd_index = input()
    prd_index=list(map(int, prd_index.split()))
    sliced_prd = [prd_list[val] for val in prd_index]
    df1 = data.dropna(subset=[prd])
    df1=data.loc[data[prd].isin(sliced_prd)]
    print(df1[prd].value_counts())
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    # Datatype validation
    
    print(df1.info())
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[94m' + '\033[1m' +"Is there any column for which the Datatype needs to be changed to Numeric ? "+ '\033[0m')
    print('\033[94m' + '\033[1m' +"Please enter the space separated indices of those columns : "+ '\033[0m')
    to_num = input()
    to_num=list(map(int, to_num.split()))
    col_list = list(df1.columns)
    col_to_num_list = [col_list[val1] for val1 in to_num]
    if len(col_to_num_list) != 0:
        for i in col_to_num_list:
            df1[i]=df[i].astype(float)
    print('\033[94m' + '\033[1m' +"Update datatypes of columns: ",df1.info())
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print(" ")
    print(" ")
    print('\033[94m' + '\033[1m' +"Is there any column for which the Datatype needs to be changed to Object ? "+ '\033[0m')
    print('\033[94m' + '\033[1m' +"Please enter the space separated indices of those columns : "+ '\033[0m')
    to_num = input()
    to_num=list(map(int, to_num.split()))
    col_list = list(df1.columns)
    col_to_num_list = [col_list[val1] for val1 in to_num]
    if len(col_to_num_list) != 0:
        for i in col_to_num_list:
            df1[i]=df[i].astype(object)
    print('\033[94m' + '\033[1m' +"Update datatypes of columns:  "+ '\033[0m',df1.info())   
    print(" ")
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    # Batch Column Data Cleaning
    
    print('\033[94m' + '\033[1m' +" There will be garbage entries in Batch No Column"+ '\033[0m')
    print('\033[94m' + '\033[1m' +" By Default the batches starting with LC or PC or OT will be removed in this functions"+ '\033[0m')
    print('\033[94m' + '\033[1m' +" If any other noise is to be removed , please do it manually from the Dataframe variable at the end "+ '\033[0m')
    print('\033[94m' + '\033[1m' +" Enter the Batch Number Column name : "+ '\033[0m')
    batch_col = input()
    print(df1[batch_col].value_counts())
    #df1 = global df_temp_granulation1
    df1 = df1.dropna(subset=[batch_col])
    #batch_filter = ["LC","PC","OT"]
    #for i in batch_filter:
    df1 = df1[~df1[batch_col].str.contains("LC",case=False)]
    df1 = df1[~df1[batch_col].str.contains("PC",case=False)]
    df1 = df1[~df1[batch_col].str.startswith("OT")]
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[94m' + '\033[1m' +" Batches starting with LC or PC or OT are now removed "+ '\033[0m')
    print('\033[94m' + '\033[1m' +" Current data contains below batches "+ '\033[0m')
    print(df1[batch_col].value_counts())
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')  
#     # Dropping Garbage Columns
    print('\033[94m' + '\033[1m' +"Below are the columns present in the passed data frame : "+ '\033[0m' )
    column_list2 = list(df1.columns)
    for k, ite in enumerate(column_list2):
        print(k,ite)
    print('\033[94m' + '\033[1m' +"Please input the unnecessary columns indices as space separated if they are needed to be dropped : "+ '\033[0m')
    to_drop2 = input()
    to_drop2 =list(map(int, to_drop2.split()))
    col_to_drop_list2 = [column_list2[val1] for val1 in to_drop2]
    if len(col_to_drop_list2) != 0:
        df1.drop(col_to_drop_list2,axis=1,inplace=True)
    print(df1.columns)   
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    # Saving current DataFrame to a Global Variable
    
    OEE_Gran1 = df1
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[94m' + '\033[1m' +"The DataFrame till now is saved to a variable named OEE_Gran1"+ '\033[0m')
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    


def OEE_Granulation_FF_generator_2(df,*args,**kwargs):
    
    global OEE_Gran_DRYING
    
    global OEE_Gran_SPRAYING
    
    global OEE_Gran_PREWARMING
    
    global OEE_Gran_AIRDRYING
    
    global OEE_Gran_DRYMIXING
    
    global OEE_Gran2
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[92m' + '\033[1m' + "Please make sure to pass the dataframe where the Batch Number column is cleaned and they only have valid Entries "+ '\033[0m')
    print(" ")
    print('\033[92m' + '\033[1m' + "If there are still some formating issues in Batch Number Column then please address them manually and then only continue with this function"+ '\033[0m')
    print(" ")
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    #df.reset_index(inplace=True)
    
    # Lot No Column Merging to Batches
    
    print('\033[92m' + '\033[1m' + "Below are the columns present in the passed data frame : "+ '\033[0m' )
    column_list = list(df.columns)
    for i, j in enumerate(column_list):
        print(i,j)
    print('\033[92m' + '\033[1m' + "Are there any Lots available for your product , input Y / N ? "+ '\033[0m')
    lot_conf = str(input())
    if lot_conf == "Y":
        print('\033[92m' + '\033[1m' + "Please input the LOT column index : "+ '\033[0m')
        lotcol_idx = input()
        print('\033[92m' + '\033[1m' + "Please input the Batch Number column index : "+ '\033[0m')
        batcol_idx = input()
        lotcol_list =list(map(int, lotcol_idx.split()))
        lotcol_var = [column_list[val1] for val1 in lotcol_list]
        batcol_list = list(map(int, batcol_idx.split()))
        batcol_var = [column_list[val1] for val1 in batcol_list]
        df['Batch_LOT'] = df[batcol_var[0]] + "_" + df[lotcol_var[0]]
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print(df.head())
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
       
    # Dropping Garbage Columns till this point
    
    print('\033[92m' + '\033[1m' + "Below are the columns present in the passed data frame : " + '\033[0m')
    column_list2 = list(df.columns)
    for k, ite in enumerate(column_list2):
        print(k,ite)
    print('\033[92m' + '\033[1m' + "Please input the unnecessary columns indices as space separated if they are needed to be dropped : "+ '\033[0m')
    to_drop2 = input()
    to_drop2 =list(map(int, to_drop2.split()))
    col_to_drop_list2 = [column_list2[val1] for val1 in to_drop2]
    if len(col_to_drop_list2) != 0:
        df.drop(col_to_drop_list2,axis=1,inplace=True)
    print(df.columns)
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    # Separating DataFrames Stage Wise 
    print('\033[92m' + '\033[1m' + "Below are the columns present in the passed data frame : " + '\033[0m')
    column_list = list(df.columns)
    for i, j in enumerate(column_list):
        print(i,j)
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[92m' + '\033[1m' + " Please input the index for ACTIVITY Column : "+ '\033[0m')
    actcol_idx = input()
    print('\033[92m' + '\033[1m' + "Current Data contains below Stages : "+ '\033[0m')
    print('\033[92m' + '\033[1m' + " Please select for which all Stages the Model needs to be Prepared : "+ '\033[0m')
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    actcol_list =list(map(int, actcol_idx.split()))
    actcol_var = [column_list[val2] for val2 in actcol_list]
    actcol_var=actcol_var[0]
    df = df.dropna(subset=[actcol_var])
    #print(df[actcol_var[0]].value_counts())
    act_list = list(df[actcol_var].unique())
    
    print('\033[92m' + '\033[1m' + "Below are the unique Stages present here : " + '\033[0m')
    for i, item in enumerate(act_list):
        print(i,item)
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[92m' + '\033[1m' + " This function will cover the DataFrame Splitting for common stages like DRYING,SPRAYING and PRE-WARMING"+ '\033[0m')    
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[92m' + '\033[1m' + " Please select the index DRYING stage , input the indices separated by single space"+ '\033[0m')
    dry_index = input()
    dry_index=list(map(int, dry_index.split()))
    if len(dry_index) != 0:
        sliced_dry = [act_list[val2] for val2 in dry_index]
        OEE_Gran_DRYING=df.loc[df[actcol_var].isin(sliced_dry)]
        print(OEE_Gran_DRYING[actcol_var].value_counts())
        print('\033[92m' + '\033[1m' + " DRYING STAGE dataframe is saved in the Global Variable named OEE_Gran_DRYING "+ '\033[0m')
        print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    
    
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[92m' + '\033[1m' + " Please select the index SPRAYING stage , input the indices separated by single space"+ '\033[0m')
    spray_index = input()
    spray_index=list(map(int, spray_index.split()))
    if len(spray_index) != 0:
        sliced_spray = [act_list[val3] for val3 in spray_index]
        OEE_Gran_SPRAYING=df.loc[df[actcol_var].isin(sliced_spray)]
        print(OEE_Gran_SPRAYING[actcol_var].value_counts())
        print('\033[92m' + '\033[1m' + " SPRAYING STAGE dataframe is saved in the Global Variable named OEE_Gran_SPRAYING "+ '\033[0m')
    
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')  
    print('\033[92m' + '\033[1m' + " Please select the index PRE-WARMING stage , input the indices separated by single space"+ '\033[0m')
    prewarm_index = input()
    prewarm_index=list(map(int, prewarm_index.split()))
    if len(prewarm_index) != 0:
        sliced_prewarm = [act_list[val4] for val4 in prewarm_index]
        OEE_Gran_PREWARMING=df.loc[df[actcol_var].isin(sliced_prewarm)]
        print(OEE_Gran_PREWARMING[actcol_var].value_counts())
        print('\033[92m' + '\033[1m' + " PRE-WARMING STAGE dataframe is saved in the Global Variable named OEE_Gran_PREWARMING "+ '\033[0m')
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    


def OEE_Granulation_FF_generator_3(df,*args,**kwargs):
    
#     global OEE_Gran_DRYING_FF
    
#     global OEE_Gran_SPRAYING_FF
    
#     global OEE_Gran_PREWARMING_FF
    
#     global OEE_Gran_AIRDRYING_FF
    
#     global OEE_Gran_DRYMIXING_FF
    
    
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[92m' + '\033[1m' +"This Function will create the Stage wise final Flat file with Cycle Time Column and Other Aggregated columns"+ '\033[0m')
    print(" ")
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')

    # Creating Timestamp Column
    
    print('\033[92m' + '\033[1m' +"Below are the columns present in the passed data frame : " + '\033[0m')
    column_list = list(df.columns)
    for i, j in enumerate(column_list):
        print(i,j)
    print('\033[92m' + '\033[1m' +"Please select the Date and Time Column Indices to merge them and create Timestamp Column : "+ '\033[0m')
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
 
    print('\033[92m' + '\033[1m' +"Please input the Date column index : "+ '\033[0m')
    datecol_idx = input()
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[92m' + '\033[1m' +"Please input the Time Number column index : "+ '\033[0m')
    timecol_idx = input()
    
    datecol_list =list(map(int, datecol_idx.split()))
    datecol_var = [column_list[val1] for val1 in datecol_list]
    timecol_list = list(map(int, timecol_idx.split()))
    timecol_var = [column_list[val1] for val1 in timecol_list]
    
    df['Timestamp'] = df[datecol_var[0]] + " " + df[timecol_var[0]]
    df['Timestamp'] = df['Timestamp'].apply(lambda x : x.strip())
    df['Timestamp'] = pd.to_datetime(df['Timestamp'])
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')

    print(df.head())
    
    df.reset_index(inplace=True)
         
    # Dropping Garbage Columns till this point
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[92m' + '\033[1m' +"Below are the columns present in the passed data frame : " + '\033[0m')
    column_list2 = list(df.columns)
    for k, ite in enumerate(column_list2):
        print(k,ite)
    print('\033[92m' + '\033[1m' +"Please input the unnecessary columns indices as space separated if they are needed to be dropped : "+ '\033[0m')
    to_drop2 = input()
    to_drop2 =list(map(int, to_drop2.split()))
    col_to_drop_list2 = [column_list2[val1] for val1 in to_drop2]
    if len(col_to_drop_list2) != 0:
        df.drop(col_to_drop_list2,axis=1,inplace=True)
    print(df.columns)
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    
    # Generating Cycle Time column
    
    column_list3 = list(df.columns)
    for k, ite in enumerate(column_list3):
        print(k,ite)
    print('\033[92m' + '\033[1m' +"Please input the Batch Number column index : "+ '\033[0m')
    
    batcol_idx = input()
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    
    batcol_list = list(map(int, batcol_idx.split()))

    batcol_var = [column_list3[val1] for val1 in batcol_list]
    
    scada_df = df.copy()
    scada_df.reset_index(inplace=True)
    scada_df['Timestamp'] = pd.to_datetime(scada_df['Timestamp'])
    data = pd.DataFrame()
    count = 0
    batches = scada_df[batcol_var[0]].unique()
    print(batches)
    for i in batches:
        batch = scada_df[scada_df[batcol_var[0]] == i]
        batch.sort_values('Timestamp', inplace=True)
        merge = [data, batch]
        data = pd.concat(merge)
        count = count + 1
    print(batcol_var)
    print(data.head())
    
    start_time_df=data.groupby(batcol_var[0])['Timestamp'].min().reset_index()
    start_time_df.columns=['Batch No','start_time']
    end_time_df=data.groupby(batcol_var)['Timestamp'].max().reset_index()
    end_time_df.columns=['Batch No','end_time']
    duration_df=start_time_df.merge(end_time_df, on=['Batch No'], validate='1:1')

    final_df = duration_df
    final_df['duration_in_mins']=(final_df['end_time']-final_df['start_time'])/np.timedelta64(1,'m')
    print(final_df['duration_in_mins'].describe(percentiles=[0.05,0.1,0.2,0.25,0.3,0.4,0.5,0.6,0.7,0.75,0.8,0.9,0.95,1]))
    
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    ##  Removing Long breaks (>5 Minutes) if exixts from the cycle time
    
    print('\033[92m' + '\033[1m' +" Do you want to remove the Breaks from the Cycle Time column , input Y / N  ? "+ '\033[0m')
    dur_conf = str(input())
    if dur_conf == "Y":   
        print('\033[92m' + '\033[1m' +" Input the Break Duration : "+ '\033[0m')
        dur = int(input())
        break_duration = {}
        
        for batch in tqdm(data[batcol_var[0]].unique()):
            temp_df = data[data[batcol_var[0]]==batch].sort_values('Timestamp').reset_index(drop=True)
            
            temp_df['timestamp_shifted']=temp_df['Timestamp'].shift(1)
            temp_df['break_duration']=(temp_df['Timestamp']-temp_df['timestamp_shifted'])/np.timedelta64(1,'m')
            temp_df.drop('timestamp_shifted',axis=1,inplace=True)
            duration = temp_df[temp_df['break_duration']>dur]['break_duration'].sum()
            break_duration[batch] = duration
            
        break_df=pd.DataFrame(break_duration,index=range(0,30,1)).T[0].reset_index()
        break_df.columns=['Batch No','break_5M_above']
        break_df.sort_values('Batch No').index
        final_df=final_df.merge(break_df, on='Batch No', how='inner')
        final_df['final_duration_in_mins'] = final_df['duration_in_mins']-final_df['break_5M_above']
        time = final_df
        
    else:
        time = final_df
        time['final_duration_in_mins'] = time['duration_in_mins']
    
    ## Plotting the duration line chart and calculating the modeling scope
    
    print(time['final_duration_in_mins'].describe(percentiles=[0.05,0.1,0.2,0.25,0.3,0.4,0.5,0.6,0.7,0.75,0.8,0.9,0.95,1]))

    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    plt.figure(figsize=(20,5))
    time.set_index('Batch No')['final_duration_in_mins'].plot()
    plt.show()
    ### Impact calculation
    
    time['deciles'] = pd.qcut(time.final_duration_in_mins, 10, duplicates='drop',labels=False)
    time = time.sort_values('deciles')
    target_cycle_time = time[time['deciles']==0]['final_duration_in_mins'].mean()
    avg_cycle_time = time["final_duration_in_mins"].mean()
    impact = avg_cycle_time-target_cycle_time
    print('\033[92m' + '\033[1m' +'Expected impact on cycle time in minutes:'+ '\033[0m', impact)
    print('\033[92m' + '\033[1m' +'Target cycle time:'+ '\033[0m', target_cycle_time)
    print('\033[92m' + '\033[1m' +'Avg cycle time (before intervention)'+ '\033[0m', time["final_duration_in_mins"].mean())
    
    time2= time[['Batch No','final_duration_in_mins']]
    time2.rename({'Batch No': batcol_var[0] }, axis=1, inplace=True)
    
    ## Feature Aggregations
    
    data.rename(columns={batcol_var[0]: 'batch_id'}, inplace=True)
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    print('\033[92m' + '\033[1m' +"Below are the feature columns present in the passed data frame : " + '\033[0m')
    column_list2 = list(data.columns)
    for k, ite in enumerate(column_list2):
        print(k,ite)
    print('\033[92m' + '\033[1m' +"Please input the indices of all the features which are needed for modeling : "+ '\033[0m')
    feat_sel = input()
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    feat_sel =list(map(int, feat_sel.split()))
    features = [column_list2[val1] for val1 in feat_sel]
    
    # Mean of the features
    mean_features=data.groupby('batch_id')[features].mean().reset_index()
    mean_features=mean_features.set_index('batch_id')
    mean_features.columns = [str(col) + '_mean' for col in mean_features.columns]
    
    # Mode/Median of the features
    mode_features=data.groupby('batch_id')[features].median().reset_index()
    mode_features=mode_features.set_index('batch_id')
    mode_features.columns = [str(col) + '_median' for col in mode_features.columns]
    
    # Min of the features
    min_features=data.groupby('batch_id')[features].min().reset_index()
    min_features=min_features.set_index('batch_id')
    min_features.columns = [str(col) + '_min' for col in min_features.columns]
    
    # Max of the features
    max_features=data.groupby('batch_id')[features].max().reset_index()
    max_features=max_features.set_index('batch_id')
    max_features.columns = [str(col) + '_max' for col in max_features.columns]
    
    # Feature df
    feature_df=mean_features.reset_index().merge(min_features.reset_index(), on=['batch_id'])
    feature_df=feature_df.merge(max_features.reset_index(), on=['batch_id'])
    feature_df=feature_df.merge(mode_features.reset_index(), on=['batch_id'])
    feature_df=feature_df.set_index('batch_id')
    
    features=feature_df.columns.tolist()
    print("# of features ", len(features))
    
    feature_df.reset_index(inplace=True)
    feature_df.rename(columns={'batch_id': batcol_var[0] }, inplace=True)
    
    ## Final Flat File Merging
    
    df2 = feature_df.merge(time2,on=batcol_var[0],validate='1:1')
    print('\033[92m' + '\033[1m' +" Final Data Frame for the said Stage has been created and stored in the passed variable : " + '\033[0m')
    print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
    return df2
