import pandas as pd
import numpy as np
import xlwt
from tqdm import tqdm
from IPython.display import display

import yaml
import pandas as pd
import numpy as np
import os
import seaborn as sns
from tqdm import tqdm
import warnings
warnings.simplefilter("ignore")
import matplotlib.dates as mdates
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
warnings.simplefilter("ignore")
from sklearn.linear_model import ElasticNet, ElasticNetCV
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error, make_scorer
from sklearn import preprocessing
from sklearn.metrics import r2_score
import re
import shap
from sklearn.model_selection import train_test_split
import itertools
from operator import mul
from functools import reduce
import statsmodels.api as sm
from matplotlib import pyplot as plt
from pdpbox import pdp, info_plots
# import pandas_profiling as pp
import matplotlib.backends.backend_pdf
from matplotlib.backends.backend_pdf import PdfPages
import colorama
from colorama import Fore
from pandas import ExcelWriter
from datetime import datetime
import xlwt 
import logging
import traceback

pd.set_option('display.max_rows', 1000)
pd.set_option('display.max_columns', None)

class EDA:
    def get_dataframe_info(self,df):
        """
        input
        df -> DataFrame
        output
        df_null_counts -> DataFrame Info (sorted)
        """
        logging.info('Inside (EDA.py) -> (get_dataframe_info) -> { Inside get_dataframe_info  method}')
        df_types = pd.DataFrame(df.dtypes)
        df_nulls = df.count()
        
        df_null_count = pd.concat([df_types, df_nulls], axis=1)
        df_null_count = df_null_count.reset_index()
        
        # Reassign column names
        col_names = ["features", "types", "non_null_counts"]
        df_null_count.columns = col_names
        
        # Add this to sort
        df_null_count = df_null_count.sort_values(by=["non_null_counts"], ascending=False)
        
        return df_null_count
    
    def data_validation(self, df,book,v1,dt):
        logging.info('Inside (EDA.py) -> (data_validation) -> { Indside data_validation method }')
        self.df = df
        # print('DATA VALIDATION')
        logging.info('DATA VALIDATION')
        logging.info(self.df)
        print(self.df)
        
        print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
        if v1.stage.lower() == 'granulation':
            logging.info('Inside (EDA.py) -> (data_validation) -> { Granulation Case DropNA if MaterialNO (BFG code), batchid,activity is empty  }')
            df = self.df.dropna(subset=[v1.MaterialNo,v1.batch_id,v1.activity])
        elif v1.stage.lower() == 'compression':
            logging.info('Inside (EDA.py) -> (data_validation) -> { Compression Case dropNA  if batch_id is empty }')
            df = self.df.dropna(subset=[v1.batch_id])
        elif v1.stage.lower() == 'coating':
            logging.info('Inside (EDA.py) -> (data_validation) -> { Coating Case DropNA if MaterialNO (BFG code), batchid,activity is empty  }')
            df = self.df.dropna(subset=[v1.MaterialNo,v1.batch_id,v1.activity])
        
        logging.info('Inside (EDA.py) -> (data_validation) -> { DataType Conversion OF Column Data Tag }')
        if v1.column_data_tag != ["NA"] or v1.column_data_tag !=" " or v1.column_data_tag != "NA":
            for i in v1.column_data_tag:
                if v1.column_data_tag[i]=="N":
                    try:
                        df[i]=df[i].astype(float)
                    except Exception as error :
                         logging.error("Inside EDA.py --> Data_Validation --> { Error Occuring in Changing DataType}")
                         traceback.print_exc()
                         raise Exception("Error Occured While Changing DataType Of Columns " +i)
                
                else:
                    df[i]=df[i].astype(object)
        else:
            pass;
                        
        print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
        logging.info('Inside (EDA.py) -> (data_validation) -> { Datetime feature creation }')
        print('Datetime feature creation')
        # Removing These Method Not Nescessary   
        # if  v1.date!="['NA']" and v1.time!="['NA']":  
        #     print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@") 
        #     print(v1.date , type(v1.date))
        #     print(v1.time , type(v1.time))
        #     df=v1.date_time(df)
        # else:
        #     pass;
        
        print('\033[94m' + '\033[1m' +"Updated datatypes of columns: "+ '\033[0m')
        print(" ")
        
        updated_data_info=self.get_dataframe_info(df)
        
        book=dt.create_Sheet(book,"updated_data_info",updated_data_info)
        
        # Batch Column Data Cleaning
        print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
        print('\033[94m' + '\033[1m' +" There will be garbage entries in Batch No Column"+ '\033[0m')
        print('\033[94m' + '\033[1m' +" By Default the batches starting with LC or PC or OT will be removed in this functions"+ '\033[0m')
        
        batch_col =v1.batch_id
        df[batch_col]=df[batch_col].str.strip()
        df = df.dropna(subset=[batch_col])
        
        print('\033[94m' + '\033[1m' +"Below Batches starting with LC or PC or OT are now removed "+ '\033[0m')
        logging.info('Inside (EDA.py) -> (data_validation) -> { Below Batches starting with LC or PC or OT are now removed }')
        removed_batchid=df[v1.batch_id].str.contains(v1.batch_pattern_rm, case=False, na=False)
        removed_data=df[removed_batchid]
        ########################### Incosistent batches Removed#####################################

        print("Book", book, type(book))
        book=dt.create_Sheet(book,'incosistent_batch_data',removed_data)
        
        print("Removed batches:",removed_data[v1.batch_id].value_counts())
        
        df = df[~df[batch_col].str.contains(v1.batch_pattern_rm,case=False)]
        
        df[batch_col]=df[batch_col].str.strip()
        
        print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
        
        print('\033[94m' + '\033[1m' +" Current data contains below batches "+ '\033[0m')
        print(df[batch_col].value_counts())
        print(" ")
        print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')  

        # print('\033[94m' + '\033[1m' +" Checking and creating lot columns for batches containing parts "+ '\033[0m')
        
        # batchids_contain_lots = df[df[batch_col].str.contains('Part|lot',case=False,na=False)]
        # ########################### batchids_contain_lots info#####################################
        # ### {{{ After Standarizing We need to change or remove these part }}}
        # book=dt.create_Sheet(book,'batchids_contain_lots_info',batchids_contain_lots)

        # if v1.lot_no!="['NA']" or v1.lot_no!=[]:
        
        #     df[v1.lot_no] = np.where(df[batch_col].str.contains('Part a',case=False,na=False), 'A', df[v1.lot_no])
        #     df[v1.lot_no] = np.where(df[batch_col].str.contains('Part b',case=False,na=False), 'B', df[v1.lot_no])
        #     df[v1.lot_no] = np.where(df[batch_col].str.contains('Part c',case=False,na=False), 'C', df[v1.lot_no])
        #     df[v1.lot_no] = np.where(df[batch_col].str.contains('Part d',case=False,na=False), 'D', df[v1.lot_no])
            
        #     df[batch_col] = np.where(df[batch_col].str.contains("Part",case=False,na=False), df[batch_col].str.slice(0, 7), df[batch_col])
            
        #     df[v1.lot_no] = np.where(df[batch_col].str.contains('Lot a|lot_a',case=False,na=False), 'A', df[v1.lot_no])
        #     df[v1.lot_no] = np.where(df[batch_col].str.contains('Lot b|lot_b',case=False,na=False), 'B', df[v1.lot_no])
        #     df[v1.lot_no] = np.where(df[batch_col].str.contains('Lot c|lot_c',case=False,na=False), 'C', df[v1.lot_no])
        #     df[v1.lot_no] = np.where(df[batch_col].str.contains('Lot d|lot_d',case=False,na=False), 'D', df[v1.lot_no])
        # else:
        #      pass;
        
        # df[batch_col] = np.where(df[batch_col].str.contains("lot",case=False,na=False), df[batch_col].str.slice(0, 7), df[batch_col])
        
        
        print('\033[92m' + '\033[1m' + "#########################Invalid Batch_ids are removed#########################################"+ '\033[0m')
        # df[batch_col] = df[batch_col].str.extract(pat = r'(\b[A-Za-z]{2}\d{5}\b)')
        
        df[batch_col] = df[batch_col].str.extract(pat = r'\b([A-Za-z]{2}\d{5}(?:_[A-Za-z])?)\b').dropna()
        print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')  
        print(df[batch_col].value_counts())
        print(df.shape)

        ## **{{ To revery once testing is done  }}***
        # book=dt.create_Sheet(book,'Valid_batch_data',df)
        return df,book

    def dropping_columns(self, df,book,v1):
        logging.info('Inside EDA.py --> dropping_columns() ---> {Inside dropping_columns function}')
        self.df = df
        
        print('\033[94m' + '\033[1m' +"Below are the columns present in the passed data frame : "+ '\033[0m' )
        logging.info('Inside EDA.py --> dropping_columns() ---> {Below are the columns present in the passed data frame}')
        column_list2 = list(self.df.columns)
        for k, ite in enumerate(column_list2):
            logging.info('Inside EDA.py --> dropping_columns() ---> { %s }' , ite) 
            print(k,ite)
        
        print(" ")
        print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')  
        print('\033[94m' + '\033[1m' +"Columns which are not required for the modelling"+ '\033[0m')
        logging.info('Inside EDA.py --> dropping_columns() ---> {Columns which are not required for the modelling}')
        
        if v1.columns_to_be_dropped[0]==["NA"] or v1.columns_to_be_dropped[0]==" " or v1.columns_to_be_dropped[0]=="NA" :
            v1.columns_to_be_dropped=[]
        else: 
            # print(v1.columns_to_be_dropped)
            print(" ")
            print('\033[94m' + '\033[1m' +"Columns which are empty"+ '\033[0m')
        empty_cols = [col for col in self.df.columns if self.df[col].isnull().all()]
        
        print(self.df.columns)
        print('Empty columns is :')
        print(empty_cols)
        unwanted_columns = ['PRODUCTCODE','MACHINECODE','LINE','UNIT','SITE','BATCH_SIZE','PRODUCTNAME','BATCH_START_DATE','SUBSTAGE']
        col_to_drop_list=v1.columns_to_be_dropped+empty_cols+unwanted_columns
        
        print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m') 
        print('\033[94m' + '\033[1m' +"Columns to be dropped"+ '\033[0m')
        print('Cols to drp columns is :')
        col_to_drop_list = list(set(col_to_drop_list))
        # print(col_to_drop_list)
        logging.info('Inside EDA.py --> dropping_columns() ---> {Columns to be dropped %s }' , col_to_drop_list)
        col_to_drop_list.remove('SUBSTAGE')
        print("--------------------------Col to drop list--------------")
        print(col_to_drop_list)
        if v1.nan_columns_to_be_dropped=='Y':
            # self.df.drop(col_to_drop_list,axis=1,inplace=True)
            self.df.drop(set(col_to_drop_list),axis=1,inplace=True)
        else:
            print("Please check that the below columns are blank" )
            # print(empty_cols)
        
        sheet = book.add_sheet("Empty_col_list" ,cell_overwrite_ok=True) 

        # pd.io.formats.excel.header_style = None
        header_format_general = xlwt.easyxf('font:bold on; align:horiz center')
        data_format_general=xlwt.easyxf('align:horiz center')

        #Write each dataframe to a different sheet
        sheet.write(0, 0,"Columns are empty:",header_format_general)
        for j, header in enumerate(empty_cols): 
            sheet.write(j+1, 0, header,header_format_general)
        
        print('\033[94m' + '\033[1m' +"Below are the columns remained data frame : "+ '\033[0m' )
        # for i, it in enumerate((list(self.df.columns))):
        #     print(i, it)
        
        print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
        # Saving current DataFrame to a Global Variable
        return df,book
    
    

    def DataCleaning(self,df,book,v1,dt,sub_file_name,REPORT_DIR):
                logging.info('Inside EDA.py --> DataCleaning() ---> { Inside Data CLeaning}')
                self.df=df
                col_list=self.df.columns.to_list()

                def outerlier_cleaning(df,v1,col_list):
                        # self.df=df
                        if v1.outlier_cleaning_required=='Y':
                                for tag in col_list:
                                        logging.info('Print Tag  : %s',tag)
                                        logging.info('Print DataType Tag  : %s',df[tag].dtype)
                                        iqr = df[tag].quantile(0.75) - df[tag].quantile(0.25)
                                        upper_bound = df[tag].quantile(0.75) + 1.5 * (iqr)
                                        lower_bound = df[tag].quantile(0.25) - 1.5 * (iqr)
                                        df[tag] = np.where(df[tag] < lower_bound, lower_bound, df[tag])
                                        df[tag] = np.where(df[tag] > upper_bound, upper_bound, df[tag])
                        else:
                                pass;
                        
                        """
                        This Funcitons can be used to get the Information about Null Values in any Given Data Frame
                        Args:
                        The Input for this function the DataFrame where the Null values are required to be tested.
                        Usage Example:
                        yfs.null_value_checker(df)
                        # """
                        # print("Status of Null Values in this DataFrame : ",df.isnull().values.any())
                        # print('Checking percentage of missing values')
                        # pd.set_option('display.max_rows', None)
                        # print(round(df.isnull().sum().sort_values(ascending=False).head(15) * 100 / len(self.df),2))
                        # print("Sum of Null Values in this DataFrame : ",self.df.isnull().sum().sum())
                        # print("Number of Rows having Null Values in this DataFrame : ",self.df.isnull().T.any().T.sum())
                        # #print("Below are the rows with Null Values",self.df[self.df.isnull().T.any()])
                        
                        
                        
                        # df = df.drop(df.columns[df.isnull().mean()>float(v1.missing_value_perc)],axis=1)
                        # col_list1=df.columns.to_list()
                        # # Imputing missing values by mean
                        # for tag in col_list1:
                        #         df[tag] = df[tag].replace(to_replace=0,value=np.NaN)
                        #         df[tag] = eval('df[tag].fillna(df[tag].'+v1.impute_missing_values_by+'())')
                        return df
                # -----------------
                print('\033[92m' + '\033[1m' +"Dealing with outliers : " + '\033[0m')
                logging.info('Inside EDA.py --> DataCleaning() ---> { Dealing with outliers :  }')

                df=outerlier_cleaning(self.df,v1,col_list)
                print('After OUTLIER CLEANING')
                for column_name in df.columns:
                    column = df[column_name]
                    # Get the count of Zeros in column 
                    count = (column == 0).sum()
                    print('Count of zeros in column ', column_name, ' is : ', count)

                print('################### EDA1 #################################')
                # print(self.df.info())
                
                print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
                print(" ")
                
                

                print('\033[92m' + '\033[1m' +" Dropping columns where values are same : " + '\033[0m')
                nunique = self.df.apply(pd.Series.nunique)
                cols_to_drop = nunique[nunique == 1].index
                # print(cols_to_drop)
                self.df.drop(cols_to_drop, axis = 1, inplace = True)
                sheet_name="col_deleted"+sub_file_name

                logging.info('Inside EDA.py --> DataCleaning() ---> {Dropping columns where values are same %s }' , cols_to_drop)

                print('-----------------------------',sub_file_name)
                
                sheet = book.add_sheet(sheet_name,cell_overwrite_ok=True) 

                # pd.io.formats.excel.header_style = None
                header_format_general = xlwt.easyxf('font:bold on; align:horiz center')
                data_format_general=xlwt.easyxf('align:horiz center')

                #Write each dataframe to a different sheet
                
                sheet.write(0, 0,"Below are the columns where values are same",header_format_general)
                
    
                for j, header in enumerate(cols_to_drop): 
                  sheet.write(j+1, 0, header,data_format_general)
                
                print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
                print(" ")
                
                print('\033[92m' + '\033[1m' +" Dropping the empty columns : " + '\033[0m')
                
                empty_cols = [col for col in self.df.columns if self.df[col].isnull().all()]
                
                logging.info('Inside EDA.py --> DataCleaning() ---> { Dropping the empty columns %s}', empty_cols)
                # print(empty_cols)
                self.df.drop(empty_cols, axis = 1, inplace = True)
                
                print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
                print(" ")
                
                print('\033[92m' + '\033[1m' +"Eliminating the less variable columns : " + '\033[0m')
                logging.info('Inside EDA.py --> DataCleaning() ---> { Eliminating the less variable columns : }')
                features = self.df.columns.tolist()
                variability_report_final = pd.DataFrame()
                for feature in tqdm(features):
                        variability_report = pd.DataFrame()
                        variability_report['feature'] = [feature]
                #     print(self.df[feature])
                        mode_of_feature = self.df[feature].mode()[0]
                        percent_of_mode = self.df[self.df[feature] == mode_of_feature].shape[0]/self.df.shape[0]
                        percent_of_mode = np.round(percent_of_mode*100, 2)
                        variability_report['mode'] = [mode_of_feature]
                        variability_report['mode_percent'] = [percent_of_mode]
                        variability_report_final = variability_report_final.append(variability_report)
                variability_report_final = variability_report_final.sort_values(by = ['mode_percent'], ascending = [False])  
                variability_report_final['feature_selected'] = np.where(variability_report_final['mode_percent'] < 80, 'selected', 'rejected_due_to_less_variability')
                display(variability_report_final['feature_selected'].value_counts().reset_index())
                selected_features = variability_report_final[variability_report_final['feature_selected'] == 'selected']['feature'].unique().tolist()
                rejected_features_due_to_less_variability = variability_report_final[variability_report_final['feature_selected'] == 'rejected_due_to_less_variability']['feature'].unique().tolist()
                selected_features = sorted(selected_features)
                variability_report_final.reset_index(inplace=True)
                print("---------------------(((((((((((((((((((((())))))))))))))))))))))")
                print("Rejected Features:",rejected_features_due_to_less_variability)
                print("Variability Report")
                print(variability_report_final)
                
                sheet_name="variability_report"+sub_file_name
                
                book=dt.create_Sheet(book,sheet_name,variability_report_final)
                
                
                print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
                print(" ")
                
                # print('\033[92m' + '\033[1m' +"Dealing with outliers : " + '\033[0m')
                # logging.info('Inside EDA.py --> DataCleaning() ---> { Dealing with outliers :  }')
                #result = self.df.select_dtypes(include='number')
                # print(self.df.info())
                col_list=self.df.columns.to_list()
                print("---------------------")
                print(col_list)
                #col_list = self.df.columns.tolist()
                print(v1.target_column)
                for i in v1.target_column:
                    col_list.remove(i)
                # for i in col_list:
                #         sns.boxplot(x = i, data = self.df, showmeans = True, orient = 'h')
                #         plt.show()
                ###Summary report
                print('\033[92m' + '\033[1m' + "#########################################################################################"+ '\033[0m')
                print(" ")
                
                print('\033[92m' + '\033[1m' +"Summary report creation: " + '\033[0m')
                logging.info('Inside EDA.py --> DataCleaning() ---> { Summary report creation: }')

                def summary_report(raw_data):
                        """
                        Return the language code detected
                        :param raw_data: pandas.DataFrame for which the summary will be generated
                        :return: pd.DataFrame with all distribution details
                        """
                        def _summary_report(x):
                                x = x.reset_index(drop = True).copy()
                                # print(x)
                                xmean = round(np.mean(x), 2)
                                quant = {'mean' : xmean}
                                for i in [0, 0.01, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.99, 1]:
                                        quant[str(i*100) + '% perc'] = round(x.quantile(i), 2)
                                x_null = x.isnull().sum()
                                x_fillrate = round(((len(x) - x_null)/len(x))*100, 2)
                                quant['NA_count'] = x_null
                                quant['Fill Rate'] = x_fillrate
                                # print(pd.Series(quant))
                                return(pd.Series(quant))
                        
                        print(raw_data.columns)
                        ans_data = raw_data.loc[:, ~raw_data.columns.isin([v1.batch_id])].apply(lambda x : _summary_report(x))
                        
                        # print(ans_data)
                        return(ans_data)
                        # final_data2 = final_data[]
                summary_report_dt = summary_report(self.df[col_list])
                summary_report_dt = summary_report_dt.T
                summary_report_dt["Min"] = summary_report_dt.iloc[:, 1:12].min(axis = 1)
                summary_report_dt["Max"] = summary_report_dt.iloc[:, 1:12].max(axis = 1)
                summary_report_dt["Actual Range from Flat File"] = summary_report_dt["Min"].astype("str") + " - " + summary_report_dt["Max"].astype("str")
             
                summary_report_dt.reset_index(inplace=True)
                
                sheet_name="summary_report"+sub_file_name
                        
                summary_report_dt.to_csv(os.path.join(REPORT_DIR,sheet_name+'.csv'))
                book=dt.create_Sheet(book,sheet_name,summary_report_dt)
               
            
                print('\033[92m' + '\033[1m' +'EDA has been done please check the summary report'+ '\033[0m')
                logging.info('Inside EDA.py --> DataCleaning() ---> { EDA has been done please check the summary report: }')
                data=self.df.copy()
                # def outerlier_cleaning(df,v1,col_list):
                #         # self.df=df
                #         if v1.outlier_cleaning_required=='Y':
                #                 for tag in col_list:
                #                         logging.info('Print Tag  : %s',tag)
                #                         logging.info('Print DataType Tag  : %s',df[tag].dtype)
                #                         iqr = df[tag].quantile(0.75) - df[tag].quantile(0.25)
                #                         upper_bound = df[tag].quantile(0.75) + 1.5 * (iqr)
                #                         lower_bound = df[tag].quantile(0.25) - 1.5 * (iqr)
                #                         df[tag] = np.where(df[tag] < lower_bound, lower_bound, df[tag])
                #                         df[tag] = np.where(df[tag] > upper_bound, upper_bound, df[tag])
                #         else:
                #                 pass;
                        
                #         """
                #         This Funcitons can be used to get the Information about Null Values in any Given Data Frame
                #         Args:
                #         The Input for this function the DataFrame where the Null values are required to be tested.
                #         Usage Example:
                #         yfs.null_value_checker(df)
                #         # """
                #         # print("Status of Null Values in this DataFrame : ",df.isnull().values.any())
                #         # print('Checking percentage of missing values')
                #         # pd.set_option('display.max_rows', None)
                #         # print(round(df.isnull().sum().sort_values(ascending=False).head(15) * 100 / len(self.df),2))
                #         # print("Sum of Null Values in this DataFrame : ",self.df.isnull().sum().sum())
                #         # print("Number of Rows having Null Values in this DataFrame : ",self.df.isnull().T.any().T.sum())
                #         # #print("Below are the rows with Null Values",self.df[self.df.isnull().T.any()])
                        
                        
                        
                #         df = df.drop(df.columns[df.isnull().mean()>float(v1.missing_value_perc)],axis=1)
                #         col_list1=df.columns.to_list()
                #         # Imputing missing values by mean
                #         for tag in col_list1:
                #                 df[tag] = df[tag].replace(to_replace=0,value=np.NaN)
                #                 df[tag] = eval('df[tag].fillna(df[tag].'+v1.impute_missing_values_by+'())')
                #         return df
                # df=outerlier_cleaning(data,v1,col_list)
        
                return df