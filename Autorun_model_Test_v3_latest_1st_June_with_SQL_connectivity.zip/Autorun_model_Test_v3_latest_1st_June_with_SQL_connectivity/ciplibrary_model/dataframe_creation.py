import pandas as pd
import xlwt
from datetime import datetime
import ast
from ciplibrary_model.assign_variables import Variables
import logging
import traceback
import yaml
import pandas as pd
from datetime import datetime
from ciplibrary_model import DataTypes
pd.set_option('display.max_rows', 1000)
pd.set_option('display.max_columns', None)

class dataframe:
    
    def Yaml_df_creation_Optimized(self,yml_path):
        
        ''' This function is used to 
        create dataframe from the Yaml file 
        path provided in the function call'''
        
        logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { Inside Yaml_df_creation Method  } ')
        try:
            with open(yml_path, 'r') as file:
                yml_file = yaml.load(file, Loader=yaml.FullLoader)
        except Exception as error:
            logging.error('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { Failed to Read YML File  } ')
            logging.exception(error)
            traceback.print_exc()
            raise Exception( f"YML is failed. Please check the log file for Details" )
        
        
        now = datetime.now()
        date_string = now.strftime("%d.%m.%Y")

        yml_param_df = pd.DataFrame(columns = ["site","unit","line","product_code","product_name","machine_code","batch_size","stage","use_case","years_to_be_included","column_data_tag","columns_to_be_dropped","nan_columns_to_be_dropped","batch_pattern_rm","spraying","drying","preheating","outlier_cleaning_required","missing_value_perc","impute_missing_values_by","target_column","model_names","cv","niter","test_size","metrics","random_state","var_tobe_excluded", "other"])
        
        for site in list(yml_file.keys()):
            print("SITE:", site)
            logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { Site is : ' + site +'  } ')
            for unit in list(yml_file[site].keys()):
                print('UNIT:',unit)
                logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { Unit is: %s} ',unit)
                product_codes=list(yml_file[site][unit].keys())
                for product_code in product_codes:
                    print('PRODUCT CODE:',product_code )
                    logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { PRODUCT CODE: %s  } ',product_code)
                    product_sp=yml_file[site][unit][product_code]
                    product_name=yml_file[site][unit][product_code]["product_name"]
                    print('PRODUCT NAME:',product_name)
                    logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { PRODUCT NAME : ' + product_name +'  } ')
                    logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { PRODUCT Specification Active/Inactive: ' + product_sp['active'] +'  } ')
                    print(product_sp['active'])
                # Batch size check
                    if product_sp['active']=='N':
                        print("PRODUCT IS NOT ACTIVE")
                        logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { PRODUCT IS NOT ACTIVE } ')
                        continue;
                    else:
                        print("PRODUCT IS ACTIVE")
                        logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { PRODUCT IS ACTIVE } ')
                        product_name=product_name+"_"+str(product_code)
                        for batch_size in product_sp['batch_size']:
                            print("BATCH SIZE:",batch_size)
                            logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { BATCH SIZE : %s }',batch_size )
                            stage_list=list(product_sp['stages'].keys())
                            print("STAGE LIST:",stage_list)
                            logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { STAGE LIST : %s }', stage_list)
                            for stage in stage_list: 
                                if stage.lower() == 'granulation' or stage.lower() == 'compression' or stage.lower() == 'coating':
                                    # use_cases_list=list(product_sp['stages'][stage].keys())[-2:]
                                    use_cases_list = [usecases for usecases in list(product_sp['stages'][stage].keys()) if usecases == 'OEE' or usecases == 'Yield']
                                    print("USE CASE LIST:", use_cases_list)
                                    logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { USE CASE LIST : %s }',use_cases_list)
                                    stage_sp=product_sp['stages'][stage]
                                    print("MODELLING STARTS FOR THE SATGE:",stage)
                                    logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { MODELLING STARTS FOR THE SATGE : '+ stage + ' } ')
                                    # batch_start_date=stage_sp['batch_start_date']
                                    # batch_end_date=stage_sp['batch_end_date']
                                    line=stage_sp['line']
                                    years_to_be_included=stage_sp['years_to_be_included']
                                    # timeline=str(batch_start_date) + "-" +str(batch_end_date)
                                    machine_code=str(stage_sp['machine_code'])
                                    
                                    for use_case in use_cases_list:
                                        use_case_sp=stage_sp[use_case]
                                        if use_case_sp['model_required']== 'Y' or use_case_sp['model_required']=='Yes' or use_case_sp['model_required']=='y':
                                                logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { USECASE '+ use_case + ' IS REQUIRED } ')
                                                pass;
                                        else:
                                                continue;
                                        print("Use Case List",use_cases_list)
                                        
                                        usecase_varlist=[
                                                        "columns_to_be_dropped",
                                                        "nan_columns_to_be_dropped",
                                                        "batch_pattern_rm",
                                                        "flat_file_path",
                                                        "model_required",
                                                        "other"]

                                        if stage.lower() == 'granulation' or  stage.lower() == 'coating' or stage.lower() == 'compression':                              
                                            for i in usecase_varlist:
                                                    globals()[f'{i}']=use_case_sp[i]     
                                        print("+++++++++++++++++++++++++++++++++++++++++++++")  
                                        print(flat_file_path)     
                                        data_path=flat_file_path['data_path']
                                        sql_query=flat_file_path['sql_query']
                                        
                                        
                                            
                                        activity_pat_varlist=["spraying",
                                                                "drying",
                                                                "preheating",]
                                # We need to handle the exception if only two stage is given     
                                        for i in activity_pat_varlist:
                                            if stage.lower() == 'granulation' or  stage.lower() == 'coating':
                                                j=use_case_sp['activity_pattern']
                                                globals()[f'{i}']=j[i]
                                            elif stage.lower() == 'compression':
                                                print("++++++++++========================")
                                                print(i)
                                                globals()[f'{i}']="['NA']"

                                        
                                                
                                        data_clean_varlist=["outlier_cleaning_required",
                                                            "missing_value_perc",
                                                            "impute_missing_values_by",]
                                        
                                        for i in data_clean_varlist:
                                            j=use_case_sp['data_cleaning']
                                            globals()[f'{i}']=j[i]
                                                    
                                        modelling_varlist=['var_tobe_excluded',
                                                        'target_column',
                                                        'model_names',
                                                        'cv',
                                                        'niter',
                                                        'test_size',
                                                        'metrics',
                                                        'random_state',]
                                        
                                        for i in modelling_varlist:
                                                j=use_case_sp['modelling']
                                                globals()[f'{i}']=j[i]
                                                
                                        
                                        new_row = {"site":str(site),"unit":str(unit),"line":str(line),"product_code":str(product_code),"product_name":str(product_name),"machine_code":str(machine_code),"batch_size":str(batch_size),"stage":str(stage),"use_case":str(use_case),"years_to_be_included":str(years_to_be_included),"columns_to_be_dropped":str(columns_to_be_dropped),"nan_columns_to_be_dropped":str(nan_columns_to_be_dropped),"batch_pattern_rm":str(batch_pattern_rm),"spraying":str(spraying),"drying":str(drying),"preheating":str(preheating),"outlier_cleaning_required":str(outlier_cleaning_required),"missing_value_perc":str(missing_value_perc),"impute_missing_values_by":str(impute_missing_values_by),"target_column":str(target_column),"model_names":str(model_names),"cv":str(cv),"niter":str(niter),"test_size":str(test_size),"metrics":str(metrics),"random_state":str(random_state),"var_tobe_excluded":str(var_tobe_excluded),"other":str(other)}
                                        logging.info('Inside DataFrame_Creation.py --> Yaml_df_creation()--> { Dictionary is Created From YML File  } ')
                                        interm_df = pd.DataFrame(new_row, index=[0])
                                        yml_param_df = pd.concat([yml_param_df,interm_df])

        return yml_param_df
        
    def create_Sheet(self,book,sheetName,df):
        logging.info(' Inside (dataFrame_creation.py)-> (create_sheet) -> Inside Create Sheet Mathod for SheetName ' + sheetName)
        import pandas as pd
        sheet1 = book.add_sheet(sheetName ,cell_overwrite_ok=True) 

        # pd.io.formats.excel.header_style = None
        header_format_general = xlwt.easyxf('font:bold on; align:horiz center')
        data_format_general=xlwt.easyxf('align:horiz center')

        #Write each dataframe to a different sheet
        headers =df.columns.tolist()
        df=df.reset_index(drop=True)

        for j, header in enumerate(headers): 
            sheet1.write(0, j, header,header_format_general)

        for i, row in df.iterrows(): 
            for j, val in enumerate(row): 
                sheet1.write(i+1, j, str(val),data_format_general)

        return book
    

    #----------------------------------------------------------------------------------------
    def create_variables_optimized(self,row): 
         ## List of all YML variables 
         ## THis need to be removed ???
        var_list=("site","unit","line","product_code","product_name","machine_code","batch_size","stage","use_case","years_to_be_included","column_data_tag","columns_to_be_dropped","nan_columns_to_be_dropped","batch_pattern_rm","spraying","drying","preheating","outlier_cleaning_required","missing_value_perc","impute_missing_values_by","target_column","model_names","cv","niter","test_size","metrics","random_state","var_tobe_excluded","other") 
        # Extracting Yaml variable from dataframe to python variables 
        for i,j in enumerate(var_list): 
            print(i , ' --> ', j , ' ---> ',row[i])
        for i,j in enumerate(var_list): 
            if j in ["columns_to_be_dropped","model_names","cv","niter","test_size","metrics","random_state","var_tobe_excluded","other","target_column"]: 
                print(j)
                print(row[i])
                print(row[j])
                globals()[f'{j}']=ast.literal_eval(row[i]) 
            else: 
                globals()[f'{j}']=row[i]
        # print("------column_data_tag----",column_data_tag, type(column_data_tag)) 

        if stage.lower() == 'granulation':
            print('inside  granulation --------')
            column_data_tag = DataTypes.column_data_tag_granulation
        elif stage.lower() == 'compression':
            column_data_tag = DataTypes.column_data_tag_compression
        elif stage.lower() == 'coating':
            print('inside  coating --------')
            column_data_tag = DataTypes.column_data_tag_coating
            
        lots = []
        to_drop2 = {}
        now = datetime.now()
        date_string = now.strftime("%d.%m.%Y")

        ### to remove time,'LOT_NO',lots,
        v1 = Variables(site,unit,line,product_code,product_name,machine_code,batch_size,stage,use_case,'BATCH_ID','PRODUCTCODE','LOT_NO','SUBSTAGE',years_to_be_included,column_data_tag,columns_to_be_dropped,nan_columns_to_be_dropped,batch_pattern_rm,spraying,drying,preheating,outlier_cleaning_required,missing_value_perc,impute_missing_values_by,target_column,model_names,cv,niter,test_size,metrics,random_state,var_tobe_excluded,date_string,other)
        print("-----PRODUCTNAME---------")
        print(v1.product_name)
        return v1
