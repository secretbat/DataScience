import adal
#import pyspark
from pyspark.dbutils import DBUtils
import datetime
import pandas as pd 
import numpy as np
import glob
import os
import re
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark.sql.functions import col
from pyspark.sql.types import *
from pyspark.sql import SparkSession


class SQLConnection:
    def __init__(self):
        self.spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        self.access_token = self.get_database_connection()
        self.azure_sql_url = "jdbc:sqlserver://peg-sql-db.database.windows.net"
        self.database_name = "pegasus"
        self.encrypt = "true"
        self.host_name_in_certificate = "*.database.windows.net"


    def get_database_connection(self):
        try:

            dbutils = DBUtils(self.spark)
        except ImportError:
            import IPython
            dbutils = IPython.get_ipython().user_ns["dbutils"]
        #Get service prinicpal ID and Secret from PegasusScope
        print("Database connection In Progress ")
        resource_app_id_url = "https://database.windows.net/"
        service_principal_id = dbutils.secrets.get(scope = "PegasusScope", key = "DatabricksSpnId")
        service_principal_secret = dbutils.secrets.get(scope = "PegasusScope", key = "DatabricksSpnSecret")
        tenant_id = dbutils.secrets.get(scope = "PegasusScope", key = "TenantId")
        authority = "https://login.windows.net/" + tenant_id
        #print("service_principal_id",service_principal_id)

        #Get Access Token using ID and Secret
        context = adal.AuthenticationContext(authority)
        token = context.acquire_token_with_client_credentials(resource_app_id_url, service_principal_id, service_principal_secret)
        access_token = token["accessToken"]
        #print("access_token",access_token)
        print("Database connection Done ")
        return access_token
    
    def read_table_data(self,db_table):
        #read data using Spark
        #spark = SparkSession.builder.appName("SparkSql").getOrCreate()
        print("Reading table data in progress ")
        sparkdf = self.spark.read \
                    .format("JDBC") \
                    .option("url", self.azure_sql_url) \
                    .option("dbtable", db_table) \
                    .option("databaseName", self.database_name) \
                    .option("accessToken", self.access_token) \
                    .option("encrypt", self.encrypt) \
                    .option("hostNameInCertificate", self.host_name_in_certificate) \
                    .load()

        print("Reading table data done ")
        return sparkdf.select("*").toPandas()
    
    def write_spark_to_table(self,sparkdf,db_table):

        sparkdf.write.format("jdbc") \
            .mode("append") \
            .option("url", self.azure_sql_url) \
            .option("dbtable", db_table) \
            .option("databaseName", self.database_name) \
            .option("accessToken", self.access_token) \
            .option("encrypt", self.encrypt) \
            .option("hostNameInCertificate", self.host_name_in_certificate) \
            .save()

        print("Data Pushed Successfully")