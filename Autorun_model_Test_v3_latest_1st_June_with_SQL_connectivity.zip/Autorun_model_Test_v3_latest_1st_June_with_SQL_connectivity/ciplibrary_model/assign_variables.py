import yaml
import pandas as pd
import numpy as np
import os
import seaborn as sns
from tqdm import tqdm
import warnings
warnings.simplefilter("ignore")
import matplotlib.dates as mdates
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
warnings.simplefilter("ignore")
from sklearn.linear_model import ElasticNet, ElasticNetCV
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error, make_scorer
from sklearn import preprocessing
from sklearn.metrics import r2_score
import re
import shap
from sklearn.model_selection import train_test_split
import itertools
from operator import mul
from functools import reduce
import statsmodels.api as sm
from matplotlib import pyplot as plt
from pdpbox import pdp, info_plots
# import pandas_profiling as pp
import matplotlib.backends.backend_pdf
from matplotlib.backends.backend_pdf import PdfPages
import colorama
from colorama import Fore
from pandas import ExcelWriter
from datetime import datetime
import xlwt
import os
import traceback
import logging

import pyspark
from pyspark.sql import SparkSession
pd.set_option('display.max_rows', 1000)
pd.set_option('display.max_columns', None)
   
class Variables:  # THis is to be optimized
        def __init__(self,site,unit,line,product_code,product_name,machine_code,batch_size,stage,use_case,batch_id,MaterialNo,lot_no,activity,years_to_be_included,column_data_tag,columns_to_be_dropped,nan_columns_to_be_dropped,batch_pattern_rm,spraying,drying,preheating,outlier_cleaning_required,missing_value_perc,impute_missing_values_by,target_column,model_names,cv,niter,test_size,metrics,random_state,var_tobe_excluded,date_string,other):
                self.product_code=product_code
                self.product_name=product_name
                self.batch_id=batch_id
                self.MaterialNo=MaterialNo
                self.lot_no=lot_no
                self.activity=activity
                self.years_to_be_included=years_to_be_included
                self.column_data_tag=column_data_tag
                self.columns_to_be_dropped=columns_to_be_dropped
                self.nan_columns_to_be_dropped=nan_columns_to_be_dropped
                self.batch_pattern_rm=batch_pattern_rm
                self.spraying=spraying
                self.drying=drying
                self.preheating=preheating
                self.outlier_cleaning_required=outlier_cleaning_required
                self.missing_value_perc=missing_value_perc
                self.impute_missing_values_by=impute_missing_values_by
                self.target_column=target_column
                self.model_names=model_names
                self.cv=cv
                self.niter=niter
                self.test_size=test_size
                self.metrics=metrics
                self.random_state=random_state
                self.site=site
                self.unit=unit
                self.line=line
                self.machine_code=machine_code
                self.batch_size=batch_size
                self.stage=stage
                self.use_case=use_case
                self.var_tobe_excluded=var_tobe_excluded
                self.date_string=date_string
                self.other = other
                
                
        
        def create_directory(self,path):
              print('INSIDE CREATE DIRECTORY')
              logging.info('INSIDE CREATE DIRECTORY')
              RAW_DATA_DIR  = os.path.join(path, "raw_data")
              FLAT_DIR   = os.path.join(path, "model_input")
              REPORT_DIR = os.path.join(path, "model_report")
              OUTPUT_DIR = os.path.join(path, "model_output")
              CODE_DIR   = os.path.join(path, "model_code")  

              if not os.path.exists(RAW_DATA_DIR):
                os.makedirs(RAW_DATA_DIR)
                print('RAW_DATA_DIR has been created')
                logging.info('RAW_DATA_DIR has been created')
              if not os.path.exists(FLAT_DIR):
                os.makedirs(FLAT_DIR)
                print('FLAT_DIR has been created')
                logging.info('FLAT_DIR has been created')
              if not os.path.exists(REPORT_DIR):
                os.makedirs(REPORT_DIR)
                print('REPORT_DIR has been created')
                logging.info('REPORT_DIR has been created')
              if not os.path.exists(OUTPUT_DIR):
                os.makedirs(OUTPUT_DIR)
                print('OUTPUT_DIR has been created')
                logging.info('OUTPUT_DIR has been created')
              if not os.path.exists(CODE_DIR):
                os.makedirs(CODE_DIR)
                print('CODE_DIR has been created')
                logging.info('CODE_DIR has been created')
                
              print(RAW_DATA_DIR,FLAT_DIR, REPORT_DIR, OUTPUT_DIR, CODE_DIR)

#               import hashlib as h
#               query = "SELECT Count(*) as C FROM master_database.master_folder WHERE Id ='" + str(h.md5(str(path).encode()).hexdigest())+ "'"
#               #print(query)
#               record_count = spark.sql(query)
#               #print(record_count.collect()[0][0])
#               if record_count.collect()[0][0] == 0:
#                 query = "INSERT INTO TABLE master_database.master_folder(Id,FOLDER_PATH) VALUES('"  + str(h.md5(str(path).encode()).hexdigest()) + "','" + str(path) + "')"
#                 spark.sql(query)
#               #print(query)

#               print("Use this Id in DS notebook",str(h.md5(str(path).encode()).hexdigest()))
              return RAW_DATA_DIR,FLAT_DIR, REPORT_DIR, OUTPUT_DIR, CODE_DIR
               
        
        def data_import(self,list_activity):
                logging.info('Inside (assign_variables.py) -> (data_import) -> Inside data_import method')
                import pandas as pd
                print(self.product_name)
                if self.years_to_be_included != 'ALL':
                        if self.other['part'] != 'N':
                        #        query = "(SELECT * FROM dbo.MLOPS_PIPELINE_COMPRESSION where PRODUCTCODE = 31006667) t"
                               query1 = "(SELECT c1.BATCH_ID,c1.SUBSTAGE,c1.PRODUCTCODE,c1.MACHINECODE,c1.PAN_SPEED_SET,c1.PAN_SPEED_ACT,c1.INLET_TEMP_ACT,c1.INLET_TEMP_SET,c1.SPRAY_RATE_ACT,c1.SPRAY_PUMP_RPM_ACT,c1.AIR_FLOW_CFM_ACT,c1.AIR_FLOW_INLET_M_S_ACT,c1.EXHAUST_TEMP_ACT,c1.EXHAUST_TEMP_SET,c1.EXHAUST_FLAP_SET,c1.EXHAUST_FLAP_ACT,c1.PRODUCT_TEMP_ACT,c1.PRODUCT_TEMP_SET,c1.DRIVE_SPEED_ACT,c1.DRIVE_SPEED_SET,c1.ATOMIZATION_AIR_ACT,c1.ATOMIZATION_AIR_SET,c1.AIR_FLOW_CFM_SET,c1.FINAL_DURATIONS_IN_MINS,c1.COATING_YIELD_PERCENT FROM dbo.MLOPS_PIPELINE_COATING c1 where PRODUCTCODE = 31012456) t"

                                # where_query = ' or '.join(["BATCH_START_DATE LIKE "+"'"+str(i)+"%'" for i in self.years_to_be_included.split('|')])
                                # query = "select * from dbo.MLOPS_PIPELINE_"+str(self.stage.upper())\
                                # +" WHERE PRODUCTCODE = " + str(self.product_code) + " AND MACHINECODE = '" + str(self.machine_code) + "' AND BATCH_SIZE = '" + str(self.batch_size) + "' AND PRODUCT_PART = '" + str(self.other['part']) + "' AND ("+where_query+");"       
                        else:
                        #        query = "(SELECT * FROM dbo.MLOPS_PIPELINE_COMPRESSION where PRODUCTCODE = 31006667) t"
                               query1 = "(SELECT c1.BATCH_ID,c1.SUBSTAGE,c1.PRODUCTCODE,c1.MACHINECODE,c1.PAN_SPEED_SET,c1.PAN_SPEED_ACT,c1.INLET_TEMP_ACT,c1.INLET_TEMP_SET,c1.SPRAY_RATE_ACT,c1.SPRAY_PUMP_RPM_ACT,c1.AIR_FLOW_CFM_ACT,c1.AIR_FLOW_INLET_M_S_ACT,c1.EXHAUST_TEMP_ACT,c1.EXHAUST_TEMP_SET,c1.EXHAUST_FLAP_SET,c1.EXHAUST_FLAP_ACT,c1.PRODUCT_TEMP_ACT,c1.PRODUCT_TEMP_SET,c1.DRIVE_SPEED_ACT,c1.DRIVE_SPEED_SET,c1.ATOMIZATION_AIR_ACT,c1.ATOMIZATION_AIR_SET,c1.AIR_FLOW_CFM_SET,c1.FINAL_DURATIONS_IN_MINS,c1.COATING_YIELD_PERCENT FROM dbo.MLOPS_PIPELINE_COATING c1 where PRODUCTCODE = 31012456) t"
                        #        where_query = ' or '.join(["BATCH_START_DATE LIKE "+"'"+str(i)+"%'" for i in self.years_to_be_included.split('|')])
                        #        query = "select * from dbo.MLOPS_PIPELINE_"+str(self.stage.upper())\
                        #        +" WHERE PRODUCTCODE = " + str(self.product_code) + " AND MACHINECODE = '" + str(self.machine_code) + "' AND BATCH_SIZE = '" + str(self.batch_size) + "' AND ("+where_query+");"
                elif self.years_to_be_included == 'ALL':
                        if self.other['part'] != 'N':
                        #        query = "(SELECT * FROM dbo.MLOPS_PIPELINE_COMPRESSION where PRODUCTCODE = 31006667) t"
                               query1 = "(SELECT c1.BATCH_ID,c1.SUBSTAGE,c1.PRODUCTCODE,c1.MACHINECODE,c1.PAN_SPEED_SET,c1.PAN_SPEED_ACT,c1.INLET_TEMP_ACT,c1.INLET_TEMP_SET,c1.SPRAY_RATE_ACT,c1.SPRAY_PUMP_RPM_ACT,c1.AIR_FLOW_CFM_ACT,c1.AIR_FLOW_INLET_M_S_ACT,c1.EXHAUST_TEMP_ACT,c1.EXHAUST_TEMP_SET,c1.EXHAUST_FLAP_SET,c1.EXHAUST_FLAP_ACT,c1.PRODUCT_TEMP_ACT,c1.PRODUCT_TEMP_SET,c1.DRIVE_SPEED_ACT,c1.DRIVE_SPEED_SET,c1.ATOMIZATION_AIR_ACT,c1.ATOMIZATION_AIR_SET,c1.AIR_FLOW_CFM_SET,c1.FINAL_DURATIONS_IN_MINS,c1.COATING_YIELD_PERCENT FROM dbo.MLOPS_PIPELINE_COATING c1 where PRODUCTCODE = 31012456) t"
                        #        query = "select * from dbo.MLOPS_PIPELINE_"+str(self.stage.upper())\
                        #        +" WHERE PRODUCTCODE = " + str(self.product_code) + " AND MACHINECODE = '" + str(self.machine_code) + "' AND BATCH_SIZE = '" + str(self.batch_size) + "' AND PRODUCT_PART = '" + str(self.other['part']) + "';"
                        else:
                        #        query = "(SELECT * FROM dbo.MLOPS_PIPELINE_COMPRESSION where PRODUCTCODE = 31006667) t"
                               query1 = "(SELECT c1.BATCH_ID,c1.SUBSTAGE,c1.PRODUCTCODE,c1.MACHINECODE,c1.PAN_SPEED_SET,c1.PAN_SPEED_ACT,c1.INLET_TEMP_ACT,c1.INLET_TEMP_SET,c1.SPRAY_RATE_ACT,c1.SPRAY_PUMP_RPM_ACT,c1.AIR_FLOW_CFM_ACT,c1.AIR_FLOW_INLET_M_S_ACT,c1.EXHAUST_TEMP_ACT,c1.EXHAUST_TEMP_SET,c1.EXHAUST_FLAP_SET,c1.EXHAUST_FLAP_ACT,c1.PRODUCT_TEMP_ACT,c1.PRODUCT_TEMP_SET,c1.DRIVE_SPEED_ACT,c1.DRIVE_SPEED_SET,c1.ATOMIZATION_AIR_ACT,c1.ATOMIZATION_AIR_SET,c1.AIR_FLOW_CFM_SET,c1.FINAL_DURATIONS_IN_MINS,c1.COATING_YIELD_PERCENT FROM dbo.MLOPS_PIPELINE_COATING c1 where PRODUCTCODE = 31012456) t"
                        #        query = "select * from dbo.MLOPS_PIPELINE_."+str(self.stage.upper())\
                        #        +" WHERE PRODUCTCODE = " + str(self.product_code) + " AND MACHINECODE = '" + str(self.machine_code) + "' AND BATCH_SIZE = '" + str(self.batch_size) + "';"
                
                print(query1)
                # spark = SparkSession.builder.appName("SparkSql").getOrCreate()
                #---------------------------------------------------------
                from ciplibrary_model.SQLConnection import SQLConnection
                connect = SQLConnection()
                # accessToken = connect.get_database_connection()
                df = connect.read_table_data(query1)

                #---------------------------------------
                # spark_df = spark.sql(query)
                # data = spark_df.select("*").toPandas()
                logging.info("STARTING DF--------")
                print('SQL DATA IMPORTED.........')
                # logging.info(data.head())
                # return data
                logging.info(df.head())
                print(df.head())
                return df
        
        def check_SQL_Query(self,query):
                logging.info('Inside (assign_variables.py) -> (data_import) -> Inside data_import method')
                import pandas as pd
                                
                print(query)
                spark = SparkSession.builder.appName("SparkSql").getOrCreate()
                spark_df = spark.sql(query)
                data = spark_df.select("*").toPandas()

                if data.empty == True:
                       #this is the new Product
                       return 1
                else:
                        #this product is exist in DB
                        modelRefinedcount = int(data.loc[0][0]) + 1
                        return modelRefinedcount
        
        def date_time(self,df,*args,**kwargs):
                        import pandas as pd
                        # global df
                        df[self.timestamp]=df[self.date]
                        df[self.timestamp]=pd.to_datetime(df[self.timestamp])
                        df.drop([self.date], inplace=True, axis=1)
                        return df
    
        def data_cleaning(self,df,*col_list):
                self.df=df
                if self.self.outlier_cleaning_required=='Y':
                        for tag in col_list:
                                iqr = self.df[tag].quantile(0.75) - self.df[tag].quantile(0.25)
                                upper_bound = self.df[tag].quantile(0.75) + 1.5 * (iqr)
                                lower_bound = self.df[tag].quantile(0.25) - 1.5 * (iqr)
                                self.df[tag] = np.where(self.df[tag] < lower_bound, lower_bound, self.df[tag])
                                self.df[tag] = np.where(self.df[tag] > upper_bound, upper_bound, self.df[tag])
                else:
                        pass
                def null_value_checker(self,df):
                        self.df
                        """
                        This Funcitons can be used to get the Information about Null Values in any Given Data Frame
                        Args:
                        The Input for this function the DataFrame where the Null values are required to be tested.
                        Usage Example:
                        yfs.null_value_checker(df)
                        """
                        print("Status of Null Values in this DataFrame : ",self.df.isnull().values.any())
                        print('Checking percentage of missing values')
                        pd.set_option('display.max_rows', None)
                        print(round(self.df.isnull().sum().sort_values(ascending=False).head(15) * 100 / len(self.df),2))
                        print("Sum of Null Values in this DataFrame : ",self.df.isnull().sum().sum())
                        print("Number of Rows having Null Values in this DataFrame : ",self.df.isnull().T.any().T.sum())
                        #print("Below are the rows with Null Values",self.df[self.df.isnull().T.any()])
                
                null_value_checker(self.df)
                
                self.df.drop(self.df.columns[self.df.isnull().mean()>0.40],axis=1)

                # Imputing missing values by mean
                for tag in col_list:
                        self.df[tag] = eval('self.df[tag].fillna(self.df[tag].'+impute_missing_values_by+'())')
                return df

#         def evaluate(model, test_features, test_labels):
#                 global mape,accuracy,rmse,r2
#                 predictions = model.predict(test_features)
#                 errors = abs(predictions - test_labels)
#                 mape = 100 * np.mean(errors / test_labels)
#                 accuracy = 100 - mape
#                 rmse = rmse_calc(predictions, test_labels)
#                 r2 = r2_score(test_labels, predictions)
#                 print('Model Performance')
#                 print('Average Error:',np.mean(errors))
#                 print('RMSE:', rmse)
#                 print('Accuracy:', accuracy)
#                 print('MAPE:',mape)
#                 print('r2:',r2)
#                 print('Min and Max errors: ', errors.min(), errors.max())
#                 return mape,accuracy,rmse,r2

#         def rmse_calc(predictions,test_labels):
#                 return np.sqrt(((predictions - test_labels) ** 2).mean())



# #-------------------------------------------------------------------- Model Building --------------------------------------------------------------------

#         def model_building(self,df,cv,random_state,niter,tgt,test_size,output_file_name,book,OUTPUT_DIR,sub_file_name):
#                 self.df=df
#                 global rf_random, model
                
#                 #importing libraries
                
#                 from sklearn.model_selection import KFold
#                 from sklearn.model_selection import cross_val_score
#                 from xgboost import XGBRegressor
#                 from sklearn.model_selection import GridSearchCV
#                 import pickle
#                 #import SHAP

#                 """
#                 This Function will build a Random Forest Model on the passed dataframe

#                 Args:
#                         The input data for this function is as per below, and make sure it must be passed in same order
#                         (Dataframename, Number of Cross-Validations - cv, Number of Iterations - niter , Target Column Name , Test dataset size)
#                 Returns:
#                         It will return below Items,
#                         Model Performance Metrics - Avg Error,Accuracy,MAPE,R2,Min & Max Errors
#                         Feature Importance Bar Plot
#                         Trained Model stored in Variable
#                 Usage Example:
#                         performance,feature,feature_plot,model = yfs.build_RF(data,5,250,'duration_in_mins',0.30)
#                 """
#                 if self.stage=='Compression':
#                     if self.var_tobe_excluded!=" "or self.var_tobe_excluded!="NA" or self.var_tobe_excluded!=[]: 
#                         self.df.drop(self.var_tobe_excluded, axis = 1, inplace = True)
#                     else:
#                         pass;
#                 else:
#                     pass;
#                 #Final_model_list = []
#                 Final_model_df = pd.DataFrame(columns = ["Model_Name","Test_Split_size","Crossed_validation","No_Iteraions", "Random_State", "Train_Accuracy","Test_Accuracy", "Train_rmse", "Test_rmse"])
#                 def rmse_calc(predictions,test_labels):
#                         return np.sqrt(((predictions - test_labels) ** 2).mean())
#                 def evaluate(model, test_features, test_labels):
#                         #global mape,accuracy,rmse,r2
#                         predictions = model.predict(test_features)
#                         errors = abs(predictions - test_labels)
#                         mape = 100 * np.mean(errors / test_labels)
#                         accuracy = 100 - mape
#                         rmse = rmse_calc(predictions, test_labels)
#                         r2 = r2_score(test_labels, predictions)
#                         print('Model Performance')
#                         print('Average Error:',np.mean(errors))
#                         print('RMSE:', rmse)
#                         print('Accuracy:', accuracy)
#                         print('MAPE:',mape)
#                         print('r2:',r2)
#                         print('Min and Max errors: ', errors.min(), errors.max())
#                         return mape,accuracy,rmse,r2,errors
#                 for test_size in test_size:
#                         for cv in cv:
#                                 for niter in niter:
#                                         for rs in random_state:
#                                                 train, test = train_test_split(self.df,test_size=test_size, random_state=rs)
#                                                 xtrain = train[train.columns.difference([tgt])]
#                                                 xtest = test[test.columns.difference([tgt])]
#                                                 ytrain = train[[tgt]]
#                                                 ytest = test[[tgt]]

#                                                 for model_name in self.model_names:
#                                                         if model_name=='rf':
#                                                                 n_estimators = [int(x) for x in np.linspace(start = 300, stop = 500, num = 10)]
#                                                                 max_features = ['auto', 'sqrt']
#                                                                 max_depth = [100]
#                                                                 min_samples_split = [2,3,4,5]
#                                                                 min_samples_leaf = [2, 4,5]
#                                                                 bootstrap = [True, False]
#                                                                 random_grid = {'n_estimators': n_estimators,
#                                                                         'max_features': max_features,
#                                                                         'max_depth': max_depth,
#                                                                         'min_samples_split': min_samples_split,
#                                                                         'min_samples_leaf': min_samples_leaf,
#                                                                         'bootstrap': bootstrap}
#                                                                 rf = RandomForestRegressor()
#                                                                 rf_random = RandomizedSearchCV(estimator = rf, param_distributions = random_grid, n_iter = niter, cv = cv, verbose=2, random_state=rs, n_jobs = -1)
#                                                                 rf_random.fit(xtrain,ytrain)

#                                                                 test_mape,test_accuracy,test_rmse,test_r2,test_errors= evaluate(rf_random, xtest,list(ytest[tgt]) )
                                                                
#                                                                 train_mape,train_accuracy,train_rmse,train_r2,test_errors= evaluate(rf_random, xtrain,list(ytrain[tgt]) )

#                                                                 #Dataframe creation

#                                                                 #"Model_Name","Test_Split_size","Crossed_validation","No_Iteraions", "Random_State", "Train_Accuracy","Test_Accuracy", "Train_rmse", "Test_rmse"

#                                                                 new_row = {"Model_Name":model_name,'Test_Split_size':test_size,"Crossed_validation":cv,"No_Iteraions":niter, 'Random_State':random_state, 'Train_Accuracy':train_accuracy,'Test_Accuracy':test_accuracy, 'Train_rmse':train_rmse, 'Test_rmse':test_rmse}
#                                                                 print(new_row)
#                                                                 interm_df = pd.DataFrame(new_row)
                                                                


#                                                                 #Final_model_list.append(interm_df)
#                                                                 Final_model_df = pd.concat([interm_df,Final_model_df])
#                                                                 Final_model_df = Final_model_df.sort_values(['Test_Accuracy', 'Test_rmse'],
#                                                                 ascending = [False, True])
#                                                                 print(" ")
#                                                                 print('###Finish###')

#                 # Final model with best accuracy
#                 Final_df=Final_model_df.copy()
#                 test_size = Final_df.iloc[0,1]
#                 cv=Final_df.iloc[0,2]
#                 niter=Final_df.iloc[0,3]
#                 random_state = Final_df.iloc[0,4]
                
                
                
#                 sheet_name='AA_Model_Results'+sub_file_name
                
# #                 
                
#                 book=self.create_Sheet(book,sheet_name,Final_df)
#                 #book.save(output_file_name)
#                 #writer.save()
#                 #print('\033[92m' + '\033[1m' +"AA model results have been saved in the path: "+self.output_path+ '\033[0m')
                
#                 #print(train_acc)
#                 train, test = train_test_split(self.df,test_size=test_size, random_state=rs)
#                 xtrain = train[train.columns.difference([tgt])]
#                 xtest = test[test.columns.difference([tgt])]
#                 ytrain = train[[tgt]]
#                 ytest = test[[tgt]]
#                 rf_random = RandomizedSearchCV(estimator = rf, param_distributions = random_grid, n_iter = niter, cv = cv, verbose=2, random_state=random_state, n_jobs = -1)
#                 rf_random.fit(xtrain,ytrain)
#                 a= evaluate(rf_random, xtest,list(ytest[tgt]) )
#                 features = xtrain.columns.tolist()
#                 importances = rf_random.best_estimator_.feature_importances_
#                 indices = np.argsort(importances)
#                 feature_imp = pd.DataFrame({'Features':features,'Scores':importances})
#                 feature_imp_sorted = feature_imp.sort_values('Scores', inplace = False, ascending=False)
#                 feature_imp_sorted.reset_index(inplace=True)
                
#                 print("Feature_importance_spraying:",feature_imp_sorted)
               
#                 sheet_name="Feature_importance"+sub_file_name
#                 book=self.create_Sheet(book,sheet_name,feature_imp_sorted)
#                 #writer.save()
#                 book.save(OUTPUT_DIR+'\\'+output_file_name+"_"+self.date_string+'.xls')
#                 plt.figure(figsize = (12, 16))
#                 feature_imp_sorted.set_index('Features', inplace=True)
#                 b = feature_imp_sorted.plot(kind = 'bar', figsize = (10,4))
#                 model = rf_random.best_estimator_

#                 ###SHAP to PDF Working

#                 model = model
#                 explainer = shap.TreeExplainer(model,)
#                 shap_values = explainer.shap_values(df, check_additivity=False)
#                 shap_values_df = pd.DataFrame(
#                 shap_values, columns=df.columns, index=df.index
#                 )
#                 fig1 = shap.summary_plot(
#                         shap_values, df, max_display=75, plot_type='dot', show=False)
#                 shap_values_summary = pd.DataFrame(
#                         shap_values_df.abs().mean(), columns=["abs_mean_shap"]
#                 )
#                 shap_values_summary = shap_values_summary.sort_values(
#                         by="abs_mean_shap", ascending=False
#                         )
#                 top_shap_features = shap_values_summary.index.tolist()
#                 a= plt.savefig("shap_top_75.png", bbox_inches='tight')
                
#                 shapfilename=output_file_name+'shap_plot'
#                 with PdfPages(os.path.join(OUTPUT_DIR, shapfilename)) as pdf:
#                         for feature in top_shap_features:
#                                 fig = shap.dependence_plot(
#                                         feature,
#                                         shap_values,
#                                         df,
#                                         interaction_index=None,
#                                         alpha=1,
#                                         dot_size=20,
#                                         color="purple",
#                                         show=False,
#                                                         )
#                                 plt.title(feature, fontsize=15)
#                                 plt.xlabel('')
#                                 plt.ylabel('')
#                                 plt.title(feature)
#                                 fname = feature + ".png"
#                                 plt.show()
                
                
#                 pdffilename=output_file_name+'pdp_plot'
#                 with PdfPages(os.path.join(OUTPUT_DIR, pdffilename)) as pdf:
#                         for feature in xtrain:
#                                 pdp_goals = pdp.pdp_isolate(model=model, dataset=xtrain, model_features=xtrain.columns.tolist(), feature=feature, num_grid_points=20)
#                                 a=pdp.pdp_plot(pdp_goals, feature)
#                                 pdf.savefig()           
#                                 #plt.show()
                

                
                #Power BI result preaparation
                metrics_df = pd.DataFrame(columns=['machine_id','bfg_code','phase','accuracy','avg_err','important_features'])

                powerbi = pd.DataFrame(columns=['machine_id','bfg_code','phase','inlet_temp_mean','product_temp_mean','exhaust_temp_mean','drive_speed_mean',
                                    'blower_drive_mean','air_flow_ms_mean','air_flow_cfm_mean','spray_pump_mean','spray_rate_mean'])


                #return model
        
                #Saving the model
                '''with open('D:\Reshma Cipla One Drive Data\OneDrive - Cipla Limited\Reshma Chikate\Testing\Ciplibrary Testing\model.pkl', 'wb') as f:
                        pickle.dump(object, f)
                #pickle.dump(rf_random, open(os.path.join(self.output_path,'model.pkl', 'wb')))
                        pickled_model = pickle.load(open('D:\Reshma Cipla One Drive Data\OneDrive - Cipla Limited\Reshma Chikate\Testing\Ciplibrary Testing\model.pkl', 'rb'))
                        pickled_model.predict(xtest)
                return a , feature_imp ,b , model,Final_df'''

        '''def data_import(self):
                df=spark.sql("select * from `sacada_sql_database`.`fbe_t036` where 
                product_code=self.product_code and machine_id==self.machine_code ")
                return df'''

        def PDP_Plots_to_PDF(self,df,tgt,model,test_size,pdffilename):
                """
                This function will plot the PDP plots for the passed Dataframe and the Model on which it is trained on.
                Also it will save the PDP plots into a PDF file in the Current Working Directory
                Args:
                        The Input data for this will be,
                        Dataframe , Target Variable , Trained Model Variable , Test dataset size, PDF File name
                Usage Example:
                        yfs.PDP_Plots_to_PDF(data,'duration_in_mins',model_d,0.35,'finasteride_1mg_pdp.pdf')

                """
                train,test = train_test_split(df,test_size=test_size, random_state=42)
                xtrain = train[train.columns.difference([tgt])]
                xtest = test[test.columns.difference([tgt])]
                ytrain = train[[tgt]]
                ytest = test[[tgt]]
                pdp_data = xtrain
                with PdfPages(os.path.join(self.output_path, self.pdffilename)) as pdf:
                        for feature in xtrain:
                                pdp_goals = pdp.pdp_isolate(model=model, dataset=xtrain, model_features=xtrain.columns.tolist(), feature=feature, num_grid_points=20)
                                a=pdp.pdp_plot(pdp_goals, feature)
                                pdf.savefig()           
                                #plt.show()
                                #plt.close()       
                
        def plot_SHAP_to_pdf(self,df,model):
    
                """
                This function will plot the SHAP plots for the passed Dataframe and the Model on which it is trained on.

                Usage Example:
                        yfs.plot_SHAP(df,model)

                """
                model = model
                explainer = shap.TreeExplainer(model,)
                shap_values = explainer.shap_values(df, check_additivity=False)
                shap_values_df = pd.DataFrame(
                shap_values, columns=df.columns, index=df.index
                )
                fig1 = shap.summary_plot(
                        shap_values, df, max_display=75, plot_type='dot', show=False)
                shap_values_summary = pd.DataFrame(
                        shap_values_df.abs().mean(), columns=["abs_mean_shap"]
                )
                shap_values_summary = shap_values_summary.sort_values(
                        by="abs_mean_shap", ascending=False
                        )
                top_shap_features = shap_values_summary.index.tolist()
                a= plt.savefig("shap_top_75.png", bbox_inches='tight')
                with PdfPages(os.path.join(self.output_path, self.shapfilename)) as pdf:
                        for feature in top_shap_features:
                                fig = shap.dependence_plot(
                                        feature,
                                        shap_values,
                                        df,
                                        interaction_index=None,
                                        alpha=1,
                                        dot_size=20,
                                        color="purple",
                                        show=False,
                                                        )
                                plt.title(feature, fontsize=15)
                                plt.xlabel('')
                                plt.ylabel('')
                                plt.title(feature)
                                fname = feature + ".png"
                                plt.show()

                return a , plt.show()