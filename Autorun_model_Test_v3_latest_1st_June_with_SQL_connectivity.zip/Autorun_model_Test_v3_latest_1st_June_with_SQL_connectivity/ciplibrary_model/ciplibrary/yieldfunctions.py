import pandas as pd
import numpy as np
import os
import seaborn as sns
from tqdm import tqdm
import warnings
warnings.simplefilter("ignore")
import matplotlib.dates as mdates
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
warnings.simplefilter("ignore")
from sklearn.linear_model import ElasticNet, ElasticNetCV
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error, make_scorer
from sklearn import preprocessing
from sklearn.metrics import r2_score
import re
import shap
from sklearn.model_selection import train_test_split
import itertools
from operator import mul
from functools import reduce
import statsmodels.api as sm
from matplotlib import pyplot as plt
from pdpbox import pdp, get_dataset, info_plots
import matplotlib.backends.backend_pdf
from matplotlib.backends.backend_pdf import PdfPages
pd.set_option('display.max_rows', 1000)
pd.set_option('display.max_columns', None)

def top5bottom5_plots(df):

    """
    This function will automatically divide the passed dataframe into Top5 and Bottom5 based on yield column and plot the box plots for each parameter for both the categories"
    1) The Function top5bottom5_plots will take input as a cleaned Dataframe
    2) The Batch_id | Batch_no | etc column must be set as index before passing to the function
    3) The target column must be renamed to Yield_%

    Args: The dataframe name to be passed in this fucntion as input

    Returns: It will return the Box Plots comparing all the parameters w.r.t Top5 and Bottom5 batches

    Usage Example:
      You can run this function in below way,
      
      pgs.top5bottom5_plots(df)

    """

    df.sort_values(by = ['Yield_%'], ascending = False,inplace= True)
    top5=df.head(5)
    bottom5=df.tail(5)
    frames = [top5,bottom5]
    t5b5 = pd.concat(frames)
    t5b5.loc[t5b5.index[:5], 'ranking'] = 'top_5'
    t5b5.loc[t5b5.index[-5:], 'ranking'] = 'bottom_5'
    
    
    for col in t5b5.columns:
        if col not in ['Yield','ranking']:
            plt.figure(figsize=(10,10))
            sns.boxplot(x ='ranking', y =col,data = t5b5, palette= 'gist_rainbow')
            sns.swarmplot(x ='ranking', y =col,data = t5b5,size=10,color='-0')
            plt.title(col, fontsize=17)
            plt.xticks(fontsize = 20)
            plt.yticks(fontsize = 20)
            #plt.savefig(Plots_DIR + col.strip() + '.jpg')
            plt.show()
            #plt.close()
    return t5b5[['Yield_%', 'ranking']]    
    return plt.show()

def _summary_report(x):
            x = x.reset_index(drop = True).copy()
            xmean = round(np.mean(x), 2)
            quant = {'mean':xmean}
            for i in [0,1]:
                quant[str(i*100) + '% perc'] = round(x.quantile(i),2)
            x_null = x.isnull().sum()
            x_fillrate = round(((len(x) - x_null)/len(x))*100,2)
            x_count = x.nunique()
            quant['NA_count'] = x_null
            quant['Fill Rate'] = x_fillrate
            quant['distinct_count'] = x_count
            return(pd.Series(quant))

def top5bottom5_SR_intermediate(dftemp):
    sr = dftemp.loc[:, ~dftemp.columns.isin(['Batch No.'])].apply(lambda x : _summary_report(x))
    return sr

def top5bottom5_SR_intermediate2(df):
    df.sort_values(by = ['Yield_%'], ascending = False,inplace= True)
    top5=df.head(5)
    bottom5=df.tail(5)
    frames = [top5,bottom5]
    t5b5 = pd.concat(frames)
    t5b5.loc[t5b5.index[:5], 'ranking'] = 'top_5'
    t5b5.loc[t5b5.index[-5:], 'ranking'] = 'bottom_5'
    sr_t5 = top5bottom5_SR_intermediate(top5)
    sr_t5 = sr_t5.T
    sr_b5 = top5bottom5_SR_intermediate(bottom5)
    sr_b5 = sr_b5.T
    
    return sr_t5 , sr_b5

def top5bottom5_SR_intermediate3(df):
    temp_t5 , temp_b5 = top5bottom5_SR_intermediate2(df)
    temp_t5['0% perc'] = temp_t5['0% perc'].astype(str)
    temp_t5['100% perc'] = temp_t5['100% perc'].astype(str)
    temp_t5['Top_5_Range'] = temp_t5['0% perc'] + " "+"-"+" "+temp_t5['100% perc']
    temp_b5['0% perc'] = temp_b5['0% perc'].astype(str)
    temp_b5['100% perc'] = temp_b5['100% perc'].astype(str)
    temp_b5['Bottom_5_Range'] = temp_b5['0% perc'] + " "+"-"+" "+temp_b5['100% perc']
    temp_t5 = temp_t5['Top_5_Range']
    temp_b5 = temp_b5['Bottom_5_Range']
    return temp_t5,temp_b5
    

def top5bottom5_SR(df):

    """
    This function will automatically divide the passed dataframe into Top5 and Bottom5 based on yield column and create a separate dataframe with ranges of all the parameters w.r.t both the categories"
    
    Args: The Function top5bottom5_SR will take input as a cleaned Dataframe"
          The Batch_id | Batch_no | etc column must be set as index before passing to the function"
          The target column must be renamed to Yield_%"

    Returns: It will divide the df in two categories based on yield and return a dataframe comparing the ranges of all the parameters present in the passed dataframe.

    Usage Example:
      You can run this function in below way,
      
      pgs.top5bottom5_SR(df)

    """

    temp_t5 , temp_b5 = top5bottom5_SR_intermediate3(df)
    temp_t5.reset_index()
    temp_b5.reset_index()
    final_sr = temp_t5.to_frame().merge(temp_b5.to_frame(),left_index=True,right_index=True)
    return final_sr

def evaluate(model, test_features, test_labels):
    predictions = model.predict(test_features)
    errors = abs(predictions - test_labels)
    mape = 100 * np.mean(errors / test_labels)
    accuracy = 100 - mape
    rmse = rmse_calc(predictions, test_labels)
    r2 = r2_score(test_labels, predictions)
    print('Model Performance')
    print('Average Error:',np.mean(errors))
    print('RMSE:', rmse)
    print('Accuracy:', accuracy)
    print('MAPE:',mape)
    print('r2:',r2)
    print('Min and Max errors: ', errors.min(), errors.max())

def rmse_calc(predictions,test_labels):
    return np.sqrt(((predictions - test_labels) ** 2).mean())

def build_RF(df,cv,niter,tgt,test_size):

    """
    This Function will build a Random Forest Model on the passed dataframe

    Args:
        The input data for this function is as per below, and make sure it must be passed in same order
        (Dataframename, Number of Cross-Validations - cv, Number of Iterations - niter , Target Column Name , Test dataset size)
    Returns:
        It will return below Items,
        Model Performance Metrics - Avg Error,Accuracy,MAPE,R2,Min & Max Errors
        Feature Importance Bar Plot
        Trained Model stored in Variable
    Usage Example:
        performance,feature,feature_plot,model = yfs.build_RF(data,5,250,'duration_in_mins',0.30)
    """
    train, test = train_test_split(df,test_size=test_size, random_state=42)
    xtrain = train[train.columns.difference([tgt])]
    xtest = test[test.columns.difference([tgt])]
    ytrain = train[[tgt]]
    ytest = test[[tgt]]
    n_estimators = [int(x) for x in np.linspace(start = 300, stop = 500, num = 10)]
    max_features = ['auto', 'sqrt']
    max_depth = [100]
    min_samples_split = [2,3,4,5]
    min_samples_leaf = [2, 4,5]
    bootstrap = [True, False]
    random_grid = {'n_estimators': n_estimators,
               'max_features': max_features,
               'max_depth': max_depth,
               'min_samples_split': min_samples_split,
               'min_samples_leaf': min_samples_leaf,
               'bootstrap': bootstrap}
    rf = RandomForestRegressor()
    rf_random = RandomizedSearchCV(estimator = rf, param_distributions = random_grid, n_iter = niter, cv = cv, verbose=2, random_state=42, n_jobs = -1)
    rf_random.fit(xtrain,ytrain)
    a= evaluate(rf_random, xtest,list(ytest[tgt]) )
    features = xtrain.columns.tolist()
    importances = rf_random.best_estimator_.feature_importances_
    indices = np.argsort(importances)
    feature_imp = pd.DataFrame({'Features':features,'Scores':importances})
    feature_imp_sorted = feature_imp.sort_values('Scores', inplace = False, ascending=False)
    plt.figure(figsize = (12, 16))
    feature_imp_sorted.set_index('Features', inplace=True)
    b = feature_imp_sorted.plot(kind = 'bar', figsize = (10,4))
    model = rf_random.best_estimator_
    return a , feature_imp ,b , model

def plot_SHAP(df,model):
    
    """
    This function will plot the SHAP plots for the passed Dataframe and the Model on which it is trained on.

    Usage Example:
        yfs.plot_SHAP(df,model)

    """
    model = model
    explainer = shap.TreeExplainer(model,)
    shap_values = explainer.shap_values(df, check_additivity=False)
    shap_values_df = pd.DataFrame(
    shap_values, columns=df.columns, index=df.index
    )
    fig1 = shap.summary_plot(
            shap_values, df, max_display=75, plot_type='dot', show=False)
    shap_values_summary = pd.DataFrame(
            shap_values_df.abs().mean(), columns=["abs_mean_shap"]
    )
    shap_values_summary = shap_values_summary.sort_values(
            by="abs_mean_shap", ascending=False
        )
    top_shap_features = shap_values_summary.index.tolist()
    a= plt.savefig("shap_top_75.png", bbox_inches='tight')
    
    for feature in top_shap_features:
        fig = shap.dependence_plot(
            feature,
            shap_values,
            df,
            interaction_index=None,
            alpha=1,
            dot_size=20,
            color="purple",
            show=False,
                                )
        plt.title(feature, fontsize=15)
        plt.xlabel('')
        plt.ylabel('')
        plt.title(feature)
        fname = feature + ".png"
        plt.show()
    
    return a , plt.show()

def shap_plot_featureIMP(df,tgt,model,test_size):
    """
    This function will plot the SHAP plots for the passed Dataframe and the Model on which it is trained on.
    Also it will provide the Feature Importance Table based on the SHAP feature values

    Args:
        The Input data for this will be,
        Dataframe , Target Variable , Trained Model Variable , Test dataset size
    Usage Example:
        yfs.shap_plot_featureIMP(data,'duration_in_mins',model_s,0.35)

    """
    
    train, test = train_test_split(df,test_size=test_size, random_state=42)
    xtrain = train[train.columns.difference([tgt])]
    xtest = test[test.columns.difference([tgt])]
    ytrain = train[[tgt]]
    ytest = test[[tgt]]
    explainer = shap.Explainer(model.predict, xtest)
    shap_values = explainer(xtest)
    feature_names = shap_values.feature_names
    shap_df = pd.DataFrame(shap_values.values, columns=feature_names)
    vals = np.abs(shap_df.values).mean(0)
    shap_importance = pd.DataFrame(list(zip(feature_names, vals)), columns=['col_name', 'feature_importance_vals'])
    shap_importance.sort_values(by=['feature_importance_vals'], ascending=False, inplace=True)
    
    return shap_importance , plot_SHAP(xtrain,model)

def PDP_Plots(df,tgt,model,test_size):
    """
    This function will plot the PDP plots for the passed Dataframe and the Model on which it is trained on.
    
    Args:
        The Input data for this will be,
        Dataframe , Target Variable , Trained Model Variable , Test dataset size
    Usage Example:
        yfs.PDP_Plots(data,'duration_in_mins',model_s,0.35)

    """
    
    train, test = train_test_split(df,test_size=test_size, random_state=42)
    xtrain = train[train.columns.difference([tgt])]
    xtest = test[test.columns.difference([tgt])]
    ytrain = train[[tgt]]
    ytest = test[[tgt]]
    pdp_data = xtrain
    for feature in xtrain:
        pdp_goals = pdp.pdp_isolate(model=model, dataset=xtrain, model_features=xtrain.columns.tolist(), feature=feature, num_grid_points=20)
        # plot it
        pdp.pdp_plot(pdp_goals, feature)
    #   plt.savefig(results_folder+'_'+feature+'ice.png',bbox_inches='tight')
        #pdf.savefig()            
        plt.show()
        plt.close()
    

def PDP_Plots_to_PDF(df,tgt,model,test_size,pdffilename):
    """
    This function will plot the PDP plots for the passed Dataframe and the Model on which it is trained on.
    Also it will save the PDP plots into a PDF file in the Current Working Directory
    Args:
        The Input data for this will be,
        Dataframe , Target Variable , Trained Model Variable , Test dataset size, PDF File name
    Usage Example:
        yfs.PDP_Plots_to_PDF(data,'duration_in_mins',model_d,0.35,'finasteride_1mg_pdp.pdf')

    """
    train,test = train_test_split(df,test_size=test_size, random_state=42)
    xtrain = train[train.columns.difference([tgt])]
    xtest = test[test.columns.difference([tgt])]
    ytrain = train[[tgt]]
    ytest = test[[tgt]]
    pdp_data = xtrain
    with PdfPages(pdffilename) as pdf:
        for feature in xtrain:
            pdp_goals = pdp.pdp_isolate(model=model, dataset=xtrain, model_features=xtrain.columns.tolist(), feature=feature, num_grid_points=20)
            a=pdp.pdp_plot(pdp_goals, feature)
            pdf.savefig()           
            #plt.show()
            #plt.close()


def outlier_remover_upper(df,col,q):
    """
    This Function can be used to remove the Upper/Higher side outliers in any given dataframe
    Args:
        The Input for this funciton is the DataFrame, the Column in which we have outliers and the Quartile value
    Usage Example:
        df = yfs.outlier_remover_upper(df,'final_duration_in_mins',0.95)

    """
    a = df[col].quantile(q)
    df_filtered = df[df[col] < a]
    return df_filtered

def outlier_remover_lower(df,col,q):
    """
    This Function can be used to remove the Lower side outliers in any given dataframe
    Args:
        The Input for this funciton is the DataFrame, the Column in which we have outliers and the Quartile value
    Usage Example:
        df = yfs.outlier_remover_lower(df,'final_duration_in_mins',0.05)
        
    """
    a = df[col].quantile(q)
    df_filtered = df[df[col] > a]
    return df_filtered

def null_value_checker(df):
    """
    This Funcitons can be used to get the Information about Null Values in any Given Data Frame
    Args:
        The Input for this function the DataFrame where the Null values are required to be tested.
    Usage Example:
        yfs.null_value_checker(df)
    """
    print("Status of Null Values in this DataFrame : ",df.isnull().values.any())
    print("Sum of Null Values in this DataFrame : ",df.isnull().sum().sum())
    print("Number of Rows having Null Values in this DataFrame : ",df.isnull().T.any().T.sum())
    #print("Below are the rows with Null Values",df[df.isnull().T.any()])

def help_top5bottom5_plots():
    About= "This function will automatically divide the passed dataframe into Top5 and Bottom5 based on yield column and plot the box plots for each parameter for both the categories"
    P1 = "1) The Function top5bottom5_plots will take input as a cleaned Dataframe"
    P2 = "2) The Batch_id | Batch_no | etc column must be set as index before passing to the function"
    P3 = "3) The target column must be renamed to Yield_%"
    X = print(About,P1,P2,P3,sep='\n')
    return X


def help_top5bottom5_SR():
    About= "This function will automatically divide the passed dataframe into Top5 and Bottom5 based on yield column and create a separate dataframe with ranges of all the parameters w.r.t both the categories"
    P1 = "1) The Function top5bottom5_SR will take input as a cleaned Dataframe"
    P2 = "2) The Batch_id | Batch_no | etc column must be set as index before passing to the function"
    P3 = "3) The target column must be renamed to Yield_%"
    X = print(About,P1,P2,P3,sep='\n')
    return X
