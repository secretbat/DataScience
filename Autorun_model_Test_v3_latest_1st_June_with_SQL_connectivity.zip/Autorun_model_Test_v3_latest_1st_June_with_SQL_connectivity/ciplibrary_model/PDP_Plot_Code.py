from sklearn.inspection import partial_dependence  # plot_partial_dependence ,
import pandas as pd
import logging

class PDP_Plot_Ranges:
    def __init__(self):
        pass
    
    def plot_pdp_yield(self,model, X, feature, target = False, return_pd = False, y_pct = True, figsize = (4,4), norm_hist = True, dec = 0.5):
        # Getting values from the partial dependence plot
        print("Inside plot_pdp")
        list2 = []
        list4 = []
        pardep = partial_dependence(model, X, [feature])
        j = feature
        logging.info('PLOT_PDP')
        logging.info(j)
        print(j)
        list2.append(pardep.get("average")[0])
        list4.append(pardep.get("values")[0])

    # Creating new columns
        df1 = pd.DataFrame(list2)
        df5 = df1.T
        df5.rename(columns = {0: 'yield'}, inplace = True)

        df3 = pd.DataFrame(list4)
        df6 = df3.T
        df6.rename(columns = {0: 'X-Axis'}, inplace = True)

        df2 = pd.concat([df5, df6], axis = 1)

        df2["shift Y"] = df2['yield'].shift(periods = 1)
        df2['difference'] = df2['yield'] - df2['shift Y']    

        df2.reset_index(inplace = True)
        df2.drop('index', axis = 1, inplace = True)

        df10 = pd.DataFrame()
        df4 = pd.DataFrame()
        list3 = []
        for k in range(len(df2)):
            if df2["difference"][k] > 0:
                max1 = df2['difference'].idxmax()
                maxid1 = df2[df2.index==int(max1-1)]['yield']

                if df2[df2.index == int(max1)]['yield'].iloc[-1] > df2[df2.index == int(max1-1)]['yield'].iloc[-1]:
                    a = "Above " + str(df2[df2.index == int(max1)]['X-Axis'].iloc[-1])
                    a1 = float(df2[df2.index == int(max1)]['yield'].iloc[-1])
                    list3.append(a)
                    list3.append(a1)
                    a2 = float(df2[df2.index == int(max1)]['X-Axis'].iloc[-1])
                    list3.append(a2)
                    a3 = float(df2[df2.index == int(max1+1)]['X-Axis'].iloc[-1])
                    list3.append(a3)

                    df4 = pd.DataFrame(list3, columns = [j])
                else:
                    a = "Below " + str(df2[df2.index == int(max1-1)]['X-Axis'].iloc[-1])
                    a1 = float(df2[df2.index == int(max1-1)]['yield'].iloc[-1])
                    list3.append(a)
                    list3.append(a1)
                    a2 = float(df2[df2.index == int(max1-1)]['X-Axis'].iloc[-1])
                    list3.append(a2)
                    a3 = float(df2[df2.index == int(max1-2)]['X-Axis'].iloc[-1])
                    list3.append(a3)

                    df4 = pd.DataFrame(list3, columns = [j])

        # Difference less than 0
            elif df2["difference"][k] < 0:

                min1 = df2['difference'].idxmin()
                minid1 = df2[df2.index==int(min1-1)]['yield']

                if df2[df2.index == int(min1)]['yield'].iloc[-1] > df2[df2.index == int(min1-1)]['yield'].iloc[-1]:
                    b = "Above " + str(df2[df2.index == int(min1)]['X-Axis'].iloc[-1])
                    list3.append(b)
                    b1 = float(df2[df2.index == int(min1)]['yield'].iloc[-1])
                    list3.append(b1)
                    b2 = float(df2[df2.index == int(min1)]['X-Axis'].iloc[-1])
                    list3.append(b2)
                    b3 = float(df2[df2.index == int(min1+1)]['X-Axis'].iloc[-1])
                    list3.append(b3)

                    df4 = pd.DataFrame(list3, columns = [j])
                else:
                    b = "Below " + str(df2[df2.index == int(min1-1)]['X-Axis'].iloc[-1])
                    list3.append(b)
                    b1 = float(df2[df2.index == int(min1-1)]['yield'].iloc[-1])
                    list3.append(b1)
                    b2 = float(df2[df2.index == int(min1-1)]['X-Axis'].iloc[-1])
                    list3.append(b2)
                    b3 = float(df2[df2.index == int(min1-2)]['X-Axis'].iloc[-1])
                    list3.append(b3)

                    df4 = pd.DataFrame(list3, columns = [j])


        df10 = df10.join(df4, how = "outer", lsuffix = '_')

    # Removing the duplicates from the ranges
        list11 = []
        final_ranges_yield = pd.DataFrame()
        for i in df10.columns:
            ranges = df10[i].drop_duplicates(keep = 'first').reset_index(drop = True)
            list11.append(ranges)
            final_ranges_yield = pd.DataFrame(list11)

        return final_ranges_yield
    

    def plot_pdp_OEE(model, X, feature, target = False, return_pd = False, y_pct = True, figsize = (4,4), norm_hist = True, dec = 0.5):

        # Getting values from the partial dependence plot
            list2 = []
            list4 = []
            pardep = partial_dependence(model, X, [feature])
            j = feature
            list2.append(pardep.get("average")[0])
            list4.append(pardep.get("values")[0])

        # Creating new columns
            df1 = pd.DataFrame(list2)
            df5 = df1.T
            df5.rename(columns = {0: "ct"}, inplace = True)

            df3 = pd.DataFrame(list4)
            df6 = df3.T
            df6.rename(columns = {0: 'X-Axis'}, inplace = True)

            df2 = pd.concat([df5, df6], axis = 1)

            df2["shift Y"] = df2["ct"].shift(periods = 1)
            df2['difference'] = df2["ct"] - df2['shift Y']    

            df2.reset_index(inplace = True)
            df2.drop('index', axis = 1, inplace = True)

            df10 = pd.DataFrame()
            df4 = pd.DataFrame()
            list3 = []
            for k in range(len(df2)):

                # Difference greater than 0
                if df2["difference"][k] > 0:

                    max1 = df2['difference'].idxmax()
                    maxid1 = df2[df2.index==int(max1-1)]['ct']

                    if df2[df2.index == int(max1)]['ct'].iloc[-1] > df2[df2.index == int(max1-1)]['ct'].iloc[-1]:
                        a = "Below " + str(df2[df2.index == int(max1-1)]['X-Axis'].iloc[-1])
                        a1 = float(df2[df2.index == int(max1-1)]['ct'].iloc[-1])
                        list3.append(a)
                        list3.append(a1)
                        a2 = float(df2[df2.index == int(max1-1)]['X-Axis'].iloc[-1])
                        list3.append(a2)
                        a3 = float(df2[df2.index == int(max1-2)]['X-Axis'].iloc[-1])
                        list3.append(a3)
                        df4 = pd.DataFrame(list3, columns = [j])
                    else:
                        a = "Below " + str(df2[df2.index == int(max1)]['X-Axis'].iloc[-1])
                        a1 = float(df2[df2.index == int(max1)]['ct'].iloc[-1])
                        list3.append(a)
                        list3.append(a1)
                        a2 = float(df2[df2.index == int(max1)]['X-Axis'].iloc[-1])
                        list3.append(a2)
                        a3 = float(df2[df2.index == int(max1-1)]['X-Axis'].iloc[-1])
                        list3.append(a3)
                        df4 = pd.DataFrame(list3, columns = [j])

        # Difference less than 0
                elif df2["difference"][k] < 0:

                    min1 = df2['difference'].idxmin()
                    minid1 = df2[df2.index==int(min1-1)]['ct']

                    if df2[df2.index == int(min1)]['ct'].iloc[-1] > df2[df2.index == int(min1-1)]['ct'].iloc[-1]:
                        b = "Below " + str(df2[df2.index == int(min1-1)]['X-Axis'].iloc[-1])
                        list3.append(b)
                        b1 = float(df2[df2.index == int(min1-1)]['ct'].iloc[-1])
                        list3.append(b1)
                        b2 = float(df2[df2.index == int(min1-1)]['X-Axis'].iloc[-1])
                        list3.append(b2)
                        b3 = float(df2[df2.index == int(min1-2)]['X-Axis'].iloc[-1])
                        list3.append(b3)

                        df4 = pd.DataFrame(list3, columns = [j])
                    else:
                        b = "Below " + str(df2[df2.index == int(min1)]['X-Axis'].iloc[-1])
                        list3.append(b)
                        b1 = float(df2[df2.index == int(min1)]['ct'].iloc[-1])
                        list3.append(b1)
                        b2 = float(df2[df2.index == int(min1)]['X-Axis'].iloc[-1])
                        list3.append(b2)
                        b3 = float(df2[df2.index == int(min1-1)]['X-Axis'].iloc[-1])
                        list3.append(b3)
                        df4 = pd.DataFrame(list3, columns = [j])

            df10 = df10.join(df4, how = "outer", lsuffix = '_')
        
        # Removing the duplicates from the ranges
            list11 = []
            final_ranges_ct = pd.DataFrame()
            for i in df10.columns:
                ranges = df10[i].drop_duplicates(keep = 'first').reset_index(drop = True)
                list11.append(ranges)
                final_ranges_ct = pd.DataFrame(list11)

            return final_ranges_ct


    def Get_PDP_Ranges_optimized(self,feature_imp_sorted1,rf_random,usecase,df):
        if usecase.lower().__contains__("ield"):
            feature_list = df.columns.tolist()

            final_features = []
            for i in df[feature_list]:
                if len(df[feature_list][i].unique()) > 5:
                    final_features.append(i)
            df11 = pd.DataFrame()
            list14 = []
            for j in feature_imp_sorted1["FEATURES"][feature_imp_sorted1["FEATURES"].isin(final_features)]:
                list14.append(self.plot_pdp_yield(rf_random, df[feature_list], feature = j))
                df11 = df11.append(self.plot_pdp_yield(rf_random, df[feature_list], feature = j))
            df11.rename(columns = {0:"Range_1", 1:"Y1", 2:"X1", 3:"H1", 4:"Range_2", 5:"Y2", 6:"X2", 7:"H2"}, inplace = True)
            

            # Calculating one point before and after X1
            if "H2" in df11.columns:
                df11["H2 - H1"] = (df11["H2"] - df11["H1"])
                df11["X2 - X1"] = (df11["X2"] - df11["X1"])

                # Checking if the curve is concave or convex
                try:
                    df11["Graph"] = 0
                    for i in range(df11.shape[0]):
                        if (df11["H2 - H1"][i] > df11["X2 - X1"][i]):
                            df11["Graph"].iloc[i] = "Convex"
                        elif (df11["H2 - H1"][i] < df11["X2 - X1"][i]):
                            df11["Graph"].iloc[i] = "Concave"
                        else:
                            df11["Graph"].iloc[i] = "NA"
                except:
                    print("Convex/Concave graphs not present")

                try:
                    for i in range(df11.shape[0]):
                        if df11["Graph"].iloc[i]=="Convex":
                            if df11["Y2"].iloc[i] > df11["Y1"].iloc[i]:
                                df11["Range_1"].iloc[i] = df11["Range_2"].iloc[i]
                        else:
                            if df11["Y2"].iloc[i] < df11["Y1"].iloc[i]:
                                df11["Range_1"].iloc[i] = df11["Range_2"].iloc[i]
                except:
                    print("Cannot get optimal ranges")
                df12 = df11.rename(columns = {"Range_1": "MODEL_SUGGESTED_RANGES"})
                
                # Merging optimal ranges with feature_imp_sorted list
                optimal_ranges_yield = feature_imp_sorted1.merge(df12.iloc[:, 0:1], left_on = "FEATURES", 
                                                                right_on = df12.index, how = "outer")
                print(optimal_ranges_yield.head())
                return optimal_ranges_yield

            else:
                df12 = df11.rename(columns = {"Range_1": "MODEL_SUGGESTED_RANGES"})
                    
                # Merging optimal ranges with feature_imp_sorted list
                optimal_ranges_yield = feature_imp_sorted1.merge(df12.iloc[:, 0:1], left_on = "FEATURES", 
                                                                right_on = df12.index, how = "outer")
                
                print(optimal_ranges_yield.head())
                return optimal_ranges_yield       
                # optimal_ranges_yield.to_excel("")

    #----------------------------------- CT -----------------------------------
        elif usecase.lower().__contains__("oee"):
            print("Cycle Time Ranges")
            feature_list = df.columns.tolist()
            final_features = []
            for i in df[feature_list]:
                if len(df[feature_list][i].unique()) > 5: # {{{ Earlier it was 5 }}}
                    final_features.append(i)
            df21 = pd.DataFrame()
            list15 = []
            for j in feature_imp_sorted1["FEATURES"][feature_imp_sorted1["FEATURES"].isin(final_features)]:
                list15.append(self.plot_pdp_OEE(rf_random, df[feature_list], feature = j))
                df21 = df21.append(self.plot_pdp_OEE(rf_random, df[feature_list], feature = j))
            df21.rename (columns = {0:"Range_1", 1:"Y1", 2:"X1", 3:"H1", 4:"Range_2", 5:"Y2", 6:"X2", 7:"H2"}, inplace = True)

            # Calculating one point before and after X1
            if "H2" in df21.columns:
                df21["H2 - H1"] = (df21["H2"] - df21["H1"])
                df21["X2 - X1"] = (df21["X2"] - df21["X1"])

            # Checking if the curve is concave or convex
                try:
                    df21["Graph"] = 0
                    for i in range(df11.shape[0]):
                        if (df21["H2 - H1"][i] > df21["X2 - X1"][i]):
                            df21["Graph"].iloc[i] = "Convex"
                        elif (df21["H2 - H1"][i] < df21["X2 - X1"][i]):
                            df21["Graph"].iloc[i] = "Concave"
                        else:
                            df21["Graph"].iloc[i] = "NA"
                except:
                    print("Convex / Concave graphs not present")

                try:
                    for i in range(df21.shape[0]):
                        if df21["Graph"].iloc[i]=="Convex":
                            if df21["Y2"].iloc[i] > df21["Y1"].iloc[i]:
                                df21["Range_1"].iloc[i] = df21["Range_2"].iloc[i]
                        else:
                            if df21["Y2"].iloc[i] < df21["Y1"].iloc[i]:
                                df21["Range_1"].iloc[i] = df21["Range_2"].iloc[i]
                except:
                    print("Cannot get optimal ranges")
                df22 = df21.rename(columns = {"Range_1": "MODEL_SUGGESTED_RANGES"})

                # Merging optimal ranges with feature_imp_sorted list
                optimal_ranges_CT = feature_imp_sorted1.merge(df22.iloc[:, 0:1], left_on = "FEATURES", 
                                                            right_on = df22.index, how = "outer")
                print(optimal_ranges_CT.head())

            else:
                df22 = df21.rename(columns = {"Range_1": "MODEL_SUGGESTED_RANGES"})

                # Merging optimal ranges with feature_imp_sorted list
                optimal_ranges_CT = feature_imp_sorted1.merge(df22.iloc[:, 0:1], left_on = "FEATURES", 
                                                            right_on = df22.index, how = "outer")
                print(optimal_ranges_CT.head())


    
    def No_of_Batches2(self,df,ranges_df):
        copy_new_df = ranges_df.copy()
        copy_new_df['BATCHES_IN_ACTUAL_DATA_FROM_SUGGESTED_RANGE'] = 0
        copy_new_df['ACTUAL_RANGES_IN_WHICH_BATCHES_RUN'] = 'NA'
        for index, row in ranges_df.iterrows():
            featurename = row['FEATURES']
            minbatchinraw = df[featurename].min()
            maxbatchinraw = df[featurename].max()
            logging.info('INSIDE_NO_OF_BATCHES')
            logging.info(row['MODEL_SUGGESTED_RANGES_y'])
            print(row['MODEL_SUGGESTED_RANGES_y'])
            if 'Above' in str(row['MODEL_SUGGESTED_RANGES_y']):
                minvalue = float(str(row['MODEL_SUGGESTED_RANGES_y']).split()[1])
                maxvalue = maxbatchinraw
            elif 'Below' in str(row['MODEL_SUGGESTED_RANGES_y']):
                maxvalue = float(str(row['MODEL_SUGGESTED_RANGES_y']).split()[1])
                minvalue = minbatchinraw
            elif '-' in str(row['MODEL_SUGGESTED_RANGES_y']): 
                minvalue = float(str(row['MODEL_SUGGESTED_RANGES_y']).split('-')[0])   
                maxvalue = float(str(row['MODEL_SUGGESTED_RANGES_y']).split('-')[1])
            elif 'nan' in str(row['MODEL_SUGGESTED_RANGES_y']): 
                continue
            
            actualRangeinBatch = str(round(minbatchinraw,3))+' to '+str(round(maxbatchinraw,3))
        #     print('actualRangeinBatch is : ',actualRangeinBatch)
            count = 0
            for index1,row1 in df.iterrows():
                if (float(row1[featurename]) >= minvalue and float(row1[featurename] <= maxvalue)):
                    count = count+1
            
            copy_new_df.at[index,'BATCHES_IN_ACTUAL_DATA_FROM_SUGGESTED_RANGE'] = count
            copy_new_df.at[index,'ACTUAL_RANGES_IN_WHICH_BATCHES_RUN'] = actualRangeinBatch

        copy_new_df['BATCHES_IN_ACTUAL_DATA_FROM_SUGGESTED_RANGE_PERCENT'] = (copy_new_df['BATCHES_IN_ACTUAL_DATA_FROM_SUGGESTED_RANGE']/df.shape[0])*100

        return copy_new_df
    
    def calculate_Actual_Ranges_From_RAWDATA(self,df,feature_imp_sorted):
        copy_new_df = feature_imp_sorted.copy()
        copy_new_df['ACTUAL_RANGES_IN_WHICH_BATCHES_RUN'] = 'NA'
        for index, row in feature_imp_sorted.iterrows():
            featurename = row['FEATURES']
            minbatchinraw = df[featurename].min()
            maxbatchinraw = df[featurename].max()
            actualRangeinBatch = str(round(minbatchinraw,3))+' to '+str(round(maxbatchinraw,3))
            copy_new_df.at[index,'ACTUAL_RANGES_IN_WHICH_BATCHES_RUN'] = actualRangeinBatch
        return copy_new_df
    

    