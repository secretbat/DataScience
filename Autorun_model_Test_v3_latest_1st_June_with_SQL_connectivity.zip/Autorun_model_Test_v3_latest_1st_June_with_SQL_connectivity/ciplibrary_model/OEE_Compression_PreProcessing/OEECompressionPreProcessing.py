import numpy as np
import pandas as pd
import re
import os
from IPython.display import display
from tabulate import tabulate
# import functions
import openpyxl
from openpyxl import load_workbook
from OEE_Compression_PreProcessing.HMIFlatFile import  HMI_FLAT_FILE
from OEE_Compression_PreProcessing.APQRFlatFile import APQR_FLAT_FILE

def DataPreprocessingOE(file_name ,product_name,parameter_no,APQR_FILE_PATH,Merged_File,hmi_output_file,apqr_output_file,final_output_file):
    
    hmi = HMI_FLAT_FILE()
    df = hmi.read_file(file_name,'product_desc','AMLO BESY 5 MG AND TELMI 40 MG BILAYERED TABLETS')
    df = hmi.to_numeric(df,"parameter_no")
    df = hmi.parameter(df,"parameter_no",parameter_no)
    print(df.shape)

    # df = to_numeric("parameter_no")
    df = hmi.to_numeric(df,"station_1_reading_set")
    df = hmi.to_numeric(df,"station_2_reading_set")
    name = ['batch_id', 'parameter_desc']
    df = hmi.group_by(df,name,['station_1_reading_set','station_2_reading_set'])
    values=['station_1_reading_set','station_2_reading_set']
    index=['batch_id']
    columns=['parameter_desc']
    df=hmi.pivot_table(df,values,index,columns)
    df = hmi.clean_up(df)
    
    df = hmi_df.reset_index()
    
    apqr = APQR_FLAT_FILE()

    apqr_df = apqr.apqr_flat_file(APQR_FILE_PATH,apqr_output_file)

    df = apqr.merge(hmi_df,apqr_df)
    
    return df