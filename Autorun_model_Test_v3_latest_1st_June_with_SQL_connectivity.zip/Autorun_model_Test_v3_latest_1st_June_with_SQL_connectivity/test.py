import logging
import traceback
import time

logging.basicConfig(filename='/dbfs/mnt/pegasusdatalake/historical_pipeline_data/Test/YAML_File/Logging.log', 
level=logging.DEBUG,  filemode='w',
format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')  # For DataBricks

# logging.basicConfig(filename='Logging_File.log', 
# level=logging.DEBUG,  filemode='w',
# format='%(asctime)s | %(name)s | %(levelname)s | %(message)s')


class RootFilter(logging.Filter):
    def filter(self, record):
        return record.name == 'root'
# Set up a handler that uses the filter
handler = logging.StreamHandler()
handler.addFilter(RootFilter())
# Set up the logger with the handler
logger = logging.getLogger('my_logger')
logger.addHandler(handler)

start_time = time.time()
from ciplibrary_model.pegasus import pegasus_model
from ciplibrary_model.pegasus import push_RangesDF_To_SQL
ymlpath = '/dbfs/mnt/pegasusdatalake/historical_pipeline_data/Test/YAML_File/Yml_file.yml'
basepath = '/dbfs/mnt/pegasusdatalake/historical_pipeline_data/Test/CipLibrary'

# ymlpath = 'Yml_file_sample.yml'
# basepath = '/'
pegasus_model(ymlpath ,basepath)
# push_RangesDF_To_SQL('NA')
end_time = time.time()
print("Duration is : " , end_time - start_time)
timetaken = end_time - start_time
logging.info('(Pegasus.py) --> (pegasus_model) --> { TimeTaken By the Library is : %s }',timetaken)
# historical_pipeline_data/Test/YAML_File/Yml_file.yml
print("Done !!!")
print("")

    


